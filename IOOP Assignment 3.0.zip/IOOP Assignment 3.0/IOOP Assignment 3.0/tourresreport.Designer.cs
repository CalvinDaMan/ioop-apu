﻿namespace IOOP_Assignment_3._0
{
    partial class tourresreport
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.mainmenubutton = new System.Windows.Forms.Button();
            this.displaybutton = new System.Windows.Forms.Button();
            this.tourres = new System.Windows.Forms.DataGridView();
            this.backbutton = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.tourres)).BeginInit();
            this.SuspendLayout();
            // 
            // mainmenubutton
            // 
            this.mainmenubutton.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.mainmenubutton.Location = new System.Drawing.Point(428, 319);
            this.mainmenubutton.Name = "mainmenubutton";
            this.mainmenubutton.Size = new System.Drawing.Size(75, 23);
            this.mainmenubutton.TabIndex = 1;
            this.mainmenubutton.Text = "Main Menu";
            this.mainmenubutton.UseVisualStyleBackColor = true;
            this.mainmenubutton.Click += new System.EventHandler(this.mainmenubutton_Click);
            // 
            // displaybutton
            // 
            this.displaybutton.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.displaybutton.Location = new System.Drawing.Point(232, 319);
            this.displaybutton.Name = "displaybutton";
            this.displaybutton.Size = new System.Drawing.Size(75, 23);
            this.displaybutton.TabIndex = 4;
            this.displaybutton.Text = "Display";
            this.displaybutton.UseVisualStyleBackColor = true;
            this.displaybutton.Click += new System.EventHandler(this.displaybutton_Click);
            // 
            // tourres
            // 
            this.tourres.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.tourres.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.tourres.Location = new System.Drawing.Point(1, 1);
            this.tourres.Name = "tourres";
            this.tourres.Size = new System.Drawing.Size(718, 292);
            this.tourres.TabIndex = 5;
            // 
            // backbutton
            // 
            this.backbutton.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.backbutton.Location = new System.Drawing.Point(336, 319);
            this.backbutton.Name = "backbutton";
            this.backbutton.Size = new System.Drawing.Size(75, 23);
            this.backbutton.TabIndex = 6;
            this.backbutton.Text = "Back";
            this.backbutton.UseVisualStyleBackColor = true;
            this.backbutton.Click += new System.EventHandler(this.backbutton_Click);
            // 
            // tourresreport
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(720, 354);
            this.Controls.Add(this.backbutton);
            this.Controls.Add(this.tourres);
            this.Controls.Add(this.displaybutton);
            this.Controls.Add(this.mainmenubutton);
            this.Name = "tourresreport";
            this.Text = "Tour Reservation Report";
            ((System.ComponentModel.ISupportInitialize)(this.tourres)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button mainmenubutton;
        private System.Windows.Forms.Button displaybutton;
        private System.Windows.Forms.DataGridView tourres;
        private System.Windows.Forms.Button backbutton;
    }
}