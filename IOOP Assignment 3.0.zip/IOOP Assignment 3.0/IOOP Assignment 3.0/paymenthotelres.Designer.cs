﻿namespace IOOP_Assignment_3._0
{
    partial class paymenthotelres
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.mainmenubutton = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.hotelpaymentidtextBox = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.depositamounttextBox = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.remainingamounttextBox = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.hotelreservationidtextBox = new System.Windows.Forms.TextBox();
            this.confirmbutton = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.addchargescomboBox = new System.Windows.Forms.ComboBox();
            this.addchargesstatuscomboBox = new System.Windows.Forms.ComboBox();
            this.remainamountstatuscomboBox = new System.Windows.Forms.ComboBox();
            this.depositstatuscomboBox = new System.Windows.Forms.ComboBox();
            this.hotelresdataGridView = new System.Windows.Forms.DataGridView();
            this.button1 = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.cusidtextBox = new System.Windows.Forms.TextBox();
            this.backbutton = new System.Windows.Forms.Button();
            this.updatebutton = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.hotelresdataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // mainmenubutton
            // 
            this.mainmenubutton.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.mainmenubutton.Location = new System.Drawing.Point(318, 503);
            this.mainmenubutton.Name = "mainmenubutton";
            this.mainmenubutton.Size = new System.Drawing.Size(75, 23);
            this.mainmenubutton.TabIndex = 1;
            this.mainmenubutton.Text = "Main Menu";
            this.mainmenubutton.UseVisualStyleBackColor = true;
            this.mainmenubutton.Click += new System.EventHandler(this.mainmenubutton_Click);
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(19, 79);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(100, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "* Hotel Payment ID:";
            // 
            // hotelpaymentidtextBox
            // 
            this.hotelpaymentidtextBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.hotelpaymentidtextBox.Location = new System.Drawing.Point(231, 76);
            this.hotelpaymentidtextBox.Name = "hotelpaymentidtextBox";
            this.hotelpaymentidtextBox.Size = new System.Drawing.Size(184, 20);
            this.hotelpaymentidtextBox.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(19, 205);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(82, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Deposit Amount";
            // 
            // depositamounttextBox
            // 
            this.depositamounttextBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.depositamounttextBox.Location = new System.Drawing.Point(231, 202);
            this.depositamounttextBox.Name = "depositamounttextBox";
            this.depositamounttextBox.Size = new System.Drawing.Size(184, 20);
            this.depositamounttextBox.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(19, 249);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(80, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "*Deposit Status";
            // 
            // label4
            // 
            this.label4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(19, 293);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(99, 13);
            this.label4.TabIndex = 2;
            this.label4.Text = "Remaining Amount:";
            // 
            // remainingamounttextBox
            // 
            this.remainingamounttextBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.remainingamounttextBox.Location = new System.Drawing.Point(231, 290);
            this.remainingamounttextBox.Name = "remainingamounttextBox";
            this.remainingamounttextBox.Size = new System.Drawing.Size(184, 20);
            this.remainingamounttextBox.TabIndex = 3;
            // 
            // label5
            // 
            this.label5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(19, 338);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(136, 13);
            this.label5.TabIndex = 2;
            this.label5.Text = "*Remaining Amount Status:";
            // 
            // label6
            // 
            this.label6.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(19, 385);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(99, 13);
            this.label6.TabIndex = 2;
            this.label6.Text = "*Additional Charges";
            // 
            // label7
            // 
            this.label7.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(19, 428);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(135, 13);
            this.label7.TabIndex = 2;
            this.label7.Text = "*Additional Charges Status ";
            // 
            // label8
            // 
            this.label8.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(19, 163);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(109, 13);
            this.label8.TabIndex = 2;
            this.label8.Text = "Hotel Reservation ID:";
            // 
            // hotelreservationidtextBox
            // 
            this.hotelreservationidtextBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.hotelreservationidtextBox.Location = new System.Drawing.Point(231, 160);
            this.hotelreservationidtextBox.Name = "hotelreservationidtextBox";
            this.hotelreservationidtextBox.Size = new System.Drawing.Size(184, 20);
            this.hotelreservationidtextBox.TabIndex = 3;
            // 
            // confirmbutton
            // 
            this.confirmbutton.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.confirmbutton.Location = new System.Drawing.Point(125, 503);
            this.confirmbutton.Name = "confirmbutton";
            this.confirmbutton.Size = new System.Drawing.Size(75, 23);
            this.confirmbutton.TabIndex = 4;
            this.confirmbutton.Text = "Insert";
            this.confirmbutton.UseVisualStyleBackColor = true;
            this.confirmbutton.Click += new System.EventHandler(this.confirmbutton_Click);
            // 
            // label9
            // 
            this.label9.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Modern No. 20", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(48, 11);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(829, 17);
            this.label9.TabIndex = 5;
            this.label9.Text = "This Interface is to insert or update HOTEL payment information of Customers. Ple" +
    "ase ensure all fields are entered.";
            // 
            // addchargescomboBox
            // 
            this.addchargescomboBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.addchargescomboBox.FormattingEnabled = true;
            this.addchargescomboBox.Items.AddRange(new object[] {
            "0.00",
            "50.00"});
            this.addchargescomboBox.Location = new System.Drawing.Point(231, 382);
            this.addchargescomboBox.Name = "addchargescomboBox";
            this.addchargescomboBox.Size = new System.Drawing.Size(184, 21);
            this.addchargescomboBox.TabIndex = 7;
            // 
            // addchargesstatuscomboBox
            // 
            this.addchargesstatuscomboBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.addchargesstatuscomboBox.FormattingEnabled = true;
            this.addchargesstatuscomboBox.Items.AddRange(new object[] {
            "Paid",
            "Unpaid",
            "None"});
            this.addchargesstatuscomboBox.Location = new System.Drawing.Point(231, 425);
            this.addchargesstatuscomboBox.Name = "addchargesstatuscomboBox";
            this.addchargesstatuscomboBox.Size = new System.Drawing.Size(184, 21);
            this.addchargesstatuscomboBox.TabIndex = 7;
            // 
            // remainamountstatuscomboBox
            // 
            this.remainamountstatuscomboBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.remainamountstatuscomboBox.FormattingEnabled = true;
            this.remainamountstatuscomboBox.Items.AddRange(new object[] {
            "Paid",
            "Unpaid",
            "Cancelled"});
            this.remainamountstatuscomboBox.Location = new System.Drawing.Point(231, 335);
            this.remainamountstatuscomboBox.Name = "remainamountstatuscomboBox";
            this.remainamountstatuscomboBox.Size = new System.Drawing.Size(184, 21);
            this.remainamountstatuscomboBox.TabIndex = 7;
            // 
            // depositstatuscomboBox
            // 
            this.depositstatuscomboBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.depositstatuscomboBox.FormattingEnabled = true;
            this.depositstatuscomboBox.Items.AddRange(new object[] {
            "Paid",
            "Unpaid",
            "Forfeited"});
            this.depositstatuscomboBox.Location = new System.Drawing.Point(231, 246);
            this.depositstatuscomboBox.Name = "depositstatuscomboBox";
            this.depositstatuscomboBox.Size = new System.Drawing.Size(184, 21);
            this.depositstatuscomboBox.TabIndex = 7;
            // 
            // hotelresdataGridView
            // 
            this.hotelresdataGridView.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.hotelresdataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.hotelresdataGridView.Location = new System.Drawing.Point(434, 57);
            this.hotelresdataGridView.Name = "hotelresdataGridView";
            this.hotelresdataGridView.Size = new System.Drawing.Size(555, 427);
            this.hotelresdataGridView.TabIndex = 8;
            // 
            // button1
            // 
            this.button1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button1.Location = new System.Drawing.Point(667, 492);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(144, 45);
            this.button1.TabIndex = 9;
            this.button1.Text = "Display Table of Hotel Payment Reservation";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label10
            // 
            this.label10.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(19, 125);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(68, 13);
            this.label10.TabIndex = 10;
            this.label10.Text = "Customer ID:";
            // 
            // cusidtextBox
            // 
            this.cusidtextBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.cusidtextBox.Location = new System.Drawing.Point(231, 122);
            this.cusidtextBox.Name = "cusidtextBox";
            this.cusidtextBox.Size = new System.Drawing.Size(184, 20);
            this.cusidtextBox.TabIndex = 11;
            // 
            // backbutton
            // 
            this.backbutton.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.backbutton.Location = new System.Drawing.Point(217, 503);
            this.backbutton.Name = "backbutton";
            this.backbutton.Size = new System.Drawing.Size(75, 23);
            this.backbutton.TabIndex = 12;
            this.backbutton.Text = "Back";
            this.backbutton.UseVisualStyleBackColor = true;
            this.backbutton.Click += new System.EventHandler(this.backbutton_Click);
            // 
            // updatebutton
            // 
            this.updatebutton.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.updatebutton.Location = new System.Drawing.Point(33, 503);
            this.updatebutton.Name = "updatebutton";
            this.updatebutton.Size = new System.Drawing.Size(75, 23);
            this.updatebutton.TabIndex = 13;
            this.updatebutton.Text = "Update";
            this.updatebutton.UseVisualStyleBackColor = true;
            this.updatebutton.Click += new System.EventHandler(this.updatebutton_Click_1);
            // 
            // paymenthotelres
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1001, 546);
            this.Controls.Add(this.updatebutton);
            this.Controls.Add(this.backbutton);
            this.Controls.Add(this.cusidtextBox);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.hotelresdataGridView);
            this.Controls.Add(this.depositstatuscomboBox);
            this.Controls.Add(this.remainamountstatuscomboBox);
            this.Controls.Add(this.addchargesstatuscomboBox);
            this.Controls.Add(this.addchargescomboBox);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.confirmbutton);
            this.Controls.Add(this.hotelreservationidtextBox);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.remainingamounttextBox);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.depositamounttextBox);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.hotelpaymentidtextBox);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.mainmenubutton);
            this.Name = "paymenthotelres";
            this.Text = "Payment Hotel Reservation";
            this.Load += new System.EventHandler(this.paymenthotelres_Load);
            ((System.ComponentModel.ISupportInitialize)(this.hotelresdataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button mainmenubutton;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox hotelpaymentidtextBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox depositamounttextBox;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox remainingamounttextBox;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox hotelreservationidtextBox;
        private System.Windows.Forms.Button confirmbutton;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ComboBox addchargescomboBox;
        private System.Windows.Forms.ComboBox addchargesstatuscomboBox;
        private System.Windows.Forms.ComboBox remainamountstatuscomboBox;
        private System.Windows.Forms.ComboBox depositstatuscomboBox;
        private System.Windows.Forms.DataGridView hotelresdataGridView;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox cusidtextBox;
        private System.Windows.Forms.Button backbutton;
        private System.Windows.Forms.Button updatebutton;
    }
}