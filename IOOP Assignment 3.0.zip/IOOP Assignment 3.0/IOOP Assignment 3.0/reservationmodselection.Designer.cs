﻿namespace IOOP_Assignment_3._0
{
    partial class reservationmodselection
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.proceedbutton = new System.Windows.Forms.Button();
            this.holidayresradioButton = new System.Windows.Forms.RadioButton();
            this.tourresradioButton = new System.Windows.Forms.RadioButton();
            this.hotelresradioButton = new System.Windows.Forms.RadioButton();
            this.rescancmainmenubutton = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.proceedbutton);
            this.groupBox1.Controls.Add(this.holidayresradioButton);
            this.groupBox1.Controls.Add(this.tourresradioButton);
            this.groupBox1.Controls.Add(this.hotelresradioButton);
            this.groupBox1.Location = new System.Drawing.Point(102, 66);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(360, 195);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Choose the type";
            // 
            // proceedbutton
            // 
            this.proceedbutton.Location = new System.Drawing.Point(135, 155);
            this.proceedbutton.Name = "proceedbutton";
            this.proceedbutton.Size = new System.Drawing.Size(75, 23);
            this.proceedbutton.TabIndex = 4;
            this.proceedbutton.Text = "Proceed";
            this.proceedbutton.UseVisualStyleBackColor = true;
            this.proceedbutton.Click += new System.EventHandler(this.proceedbutton_Click);
            // 
            // holidayresradioButton
            // 
            this.holidayresradioButton.AutoSize = true;
            this.holidayresradioButton.Location = new System.Drawing.Point(119, 114);
            this.holidayresradioButton.Name = "holidayresradioButton";
            this.holidayresradioButton.Size = new System.Drawing.Size(120, 17);
            this.holidayresradioButton.TabIndex = 0;
            this.holidayresradioButton.TabStop = true;
            this.holidayresradioButton.Text = "Holiday Reservation";
            this.holidayresradioButton.UseVisualStyleBackColor = true;
            // 
            // tourresradioButton
            // 
            this.tourresradioButton.AutoSize = true;
            this.tourresradioButton.Location = new System.Drawing.Point(119, 81);
            this.tourresradioButton.Name = "tourresradioButton";
            this.tourresradioButton.Size = new System.Drawing.Size(107, 17);
            this.tourresradioButton.TabIndex = 0;
            this.tourresradioButton.TabStop = true;
            this.tourresradioButton.Text = "Tour Reservation";
            this.tourresradioButton.UseVisualStyleBackColor = true;
            // 
            // hotelresradioButton
            // 
            this.hotelresradioButton.AutoSize = true;
            this.hotelresradioButton.Location = new System.Drawing.Point(119, 47);
            this.hotelresradioButton.Name = "hotelresradioButton";
            this.hotelresradioButton.Size = new System.Drawing.Size(110, 17);
            this.hotelresradioButton.TabIndex = 0;
            this.hotelresradioButton.TabStop = true;
            this.hotelresradioButton.Text = "Hotel Reservation";
            this.hotelresradioButton.UseVisualStyleBackColor = true;
            // 
            // rescancmainmenubutton
            // 
            this.rescancmainmenubutton.Location = new System.Drawing.Point(203, 305);
            this.rescancmainmenubutton.Name = "rescancmainmenubutton";
            this.rescancmainmenubutton.Size = new System.Drawing.Size(122, 23);
            this.rescancmainmenubutton.TabIndex = 3;
            this.rescancmainmenubutton.Text = "Back to main menu";
            this.rescancmainmenubutton.UseVisualStyleBackColor = true;
            this.rescancmainmenubutton.Click += new System.EventHandler(this.rescancmainmenubutton_Click);
            // 
            // reservationmodselection
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(574, 354);
            this.Controls.Add(this.rescancmainmenubutton);
            this.Controls.Add(this.groupBox1);
            this.Name = "reservationmodselection";
            this.Text = "Modification Selection";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton holidayresradioButton;
        private System.Windows.Forms.RadioButton tourresradioButton;
        private System.Windows.Forms.RadioButton hotelresradioButton;
        private System.Windows.Forms.Button rescancmainmenubutton;
        private System.Windows.Forms.Button proceedbutton;
    }
}