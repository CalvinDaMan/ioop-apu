﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace IOOP_Assignment_3._0
{
    public partial class viewchangetour : Form
    {        
        public viewchangetour()
        {
            InitializeComponent();
        }

        private void viewchangetour_Load(object sender, EventArgs e)
        {
            string connectionString = "Provider =Microsoft.ACE.OLEDB.12.0; Data Source =IOOPDb.accdb";
            string sql = "SELECT * FROM tourres";
            OleDbConnection connection = new OleDbConnection(connectionString);
            OleDbDataAdapter dataadapter = new OleDbDataAdapter(sql, connection);
            DataSet ds = new DataSet();
            connection.Open();
            dataadapter.Fill(ds, "tourres_table");
            connection.Close();
            tourchangedataGridView.DataSource = ds;
            tourchangedataGridView.DataMember = "tourres_table";
        }
    }
}
