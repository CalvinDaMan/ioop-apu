﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace IOOP_Assignment_3._0
{
    public partial class CusInfo_holir : Form
    {
        OleDbConnection cnnOLEDB = new OleDbConnection();
        OleDbCommand cmdInsert = new OleDbCommand();
        OleDbCommand cmdDelete = new OleDbCommand();
        OleDbCommand cmdUpdate = new OleDbCommand();
        OleDbCommand cmdSearch = new OleDbCommand();
        public CusInfo_holir()
        {
            InitializeComponent();
        }

        private void backtoresbutton_hotelr_Click(object sender, EventArgs e)
        {
            const string message = "Do you want to go to RESERVATION?";
            const string caption = "RESERVATION";
            var result = MessageBox.Show(message, caption, MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes)
            {
                Reservation newForm = new Reservation();
                newForm.Show();
                this.Hide();
            }
        }

        private void mainmenubutton_hotelr_Click(object sender, EventArgs e)
        {
            const string message = "Do you want to go to MAIN MENU?";
            const string caption = "MAIN MENU";
            var result = MessageBox.Show(message, caption, MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes)
            {
                MainMenu newForm = new MainMenu();
                newForm.Show();
                this.Hide();
            }
        }

        private void confirmbutton_hotelr_Click(object sender, EventArgs e)
        {
            

                DateTime bookingdateholir = DateTime.Parse(cusinfoholresdateTimePicker.Text);
                using (OleDbConnection conn = new OleDbConnection())
                {

                    conn.ConnectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=IOOPDb.accdb";
                    string sql = string.Format("INSERT INTO cusinfoholidayr(customerID, customername, address, email, contact, bookingdate) VALUES('{0}','{1}','{2}','{3}','{4}','{5}')", cusidtextBox_holidayr .Text, cusnametextBox_holidayr .Text, cusaddresstextBox_holidayr .Text, emailtextBox_holidayr .Text, cuscontacttextBox_holidayr.Text, bookingdateholir);

                    using (OleDbCommand cmd = new OleDbCommand(sql, conn))
                    {
                        conn.Open();
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Insertion successful.");
                        HolidayRes  newForm = new HolidayRes();
                        newForm.Show();
                        this.Hide();

                    }

                }
            
            
        }

        private void CusInfo_holir_Load(object sender, EventArgs e)
        {
            cnnOLEDB.ConnectionString = "Provider =Microsoft.ACE.OLEDB.12.0; Data Source =IOOPDb.accdb";
            cnnOLEDB.Open();
        }
    }
}
