﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace IOOP_Assignment_3._0
{
    public partial class touridlabel : Form
    {
        OleDbConnection cnnOLEDB = new OleDbConnection();
        OleDbCommand cmdInsert = new OleDbCommand();
        OleDbCommand cmdDelete = new OleDbCommand();
        OleDbCommand cmdUpdate = new OleDbCommand();
        OleDbCommand cmdSearch = new OleDbCommand();
        double totalprice;
        double amount;
        public touridlabel()
        {
            InitializeComponent();
        }

        private void tourresmainmenubutton_Click(object sender, EventArgs e)
        {
            const string message = "Do you want to go to MAIN MENU?";
            const string caption = "MAIN MENU";
            var result = MessageBox.Show(message, caption, MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes)
            {
                MainMenu newForm = new MainMenu();
                newForm.Show();
                this.Hide();
            }
        }

        private void backtoresbutton_tourres_Click(object sender, EventArgs e)
        {
            const string message = "Do you want to go to RESERVATION?";
            const string caption = "RESERVATION";
            var result = MessageBox.Show(message, caption, MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes)
            {
                Reservation newForm = new Reservation();
                newForm.Show();
                this.Hide();
            }
        }

        private void touridlabel_Load(object sender, EventArgs e)
        {
            cnnOLEDB.ConnectionString = "Provider =Microsoft.ACE.OLEDB.12.0; Data Source =IOOPDb.accdb";
            cnnOLEDB.Open();
            tourrestournamecomboBox.SelectedIndex = 0;
        }

        private void tourrestournamecomboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            double[] tourprice = new double[] { 960.00, 640.00, 800.00 };//array for price of tours
            amount = amountrescomboBox.SelectedIndex;
            totalprice = amount * tourprice[tourrestournamecomboBox.SelectedIndex];
            tourrespricetextBox.Text = totalprice.ToString();
            DateTime tourresdate = DateTime.Parse(tourresdateTimePicker.Text);
            DateTime tourresdateend = DateTime.Parse(touresenddateTimePicker.Text);
            if (tourresdateend >tourresdate)
            {//pls change thissssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssss
                if (tourrestournamecomboBox .SelectedIndex ==0 )
                {
                    DateTime startdate = DateTime.Parse(tourresdateTimePicker.Text);
                    DateTime enddate = startdate.AddDays(4);
                    touresenddateTimePicker.Text = enddate.ToLongDateString();
                }
                else if(tourrestournamecomboBox.SelectedIndex == 1 )
                {
                    DateTime startdate = DateTime.Parse(tourresdateTimePicker.Text);
                    DateTime enddate = startdate.AddDays(3);
                    touresenddateTimePicker.Text = enddate.ToLongDateString();
                }
                else if (tourrestournamecomboBox.SelectedIndex == 2)
                {
                    DateTime startdate = DateTime.Parse(tourresdateTimePicker.Text);
                    DateTime enddate = startdate.AddDays(5);
                    touresenddateTimePicker.Text = enddate.ToLongDateString();
                }                
            }
        }

        private void tourresconfirmbutton_Click(object sender, EventArgs e)
        {
            DateTime tourresdate = DateTime.Parse(tourresdateTimePicker.Text);
            DateTime tourresdateend = DateTime.Parse(touresenddateTimePicker.Text);
            DateTime todaydate = DateTime.Today;
                        
            if(tourrestouridtextBox .Text !="" && tourrescusidtextBox .Text !="" && amountrescomboBox.SelectedIndex>-1)//make sure the textboxes r not empty 
            {                                                                                                          //before running the code below
                if (tourresdate >= todaydate)
                {
                    using (OleDbConnection conn = new OleDbConnection())
                    {
                        DateTime reserveddatetour = DateTime.Parse(tourresdateTimePicker.Text);                        
                        conn.ConnectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=IOOPDb.accdb";
                        string sql = string.Format("INSERT INTO tourres(tourreservationID, tourID, tourname, tourprice, datereservedstart,datereservedend, amounttour, customerID) VALUES('{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}')", tourrestextBox.Text, tourrestouridtextBox.Text, tourrestournamecomboBox.SelectedItem, tourrespricetextBox.Text, tourresdate,tourresdateend, amountrescomboBox.SelectedItem ,tourrescusidtextBox.Text);

                        using (OleDbCommand cmd = new OleDbCommand(sql, conn))
                        {
                            conn.Open();
                            cmd.ExecuteNonQuery();
                            MessageBox.Show("Insertion successful.");
                            touridlabel newForm = new touridlabel();
                            newForm.Show();
                            this.Hide();
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Insertion unsuccessful. You cannot reserve a date before today's date.");
                }
            }
            else
            {
                MessageBox.Show("Insertion unsuccessful. Please ensure all fields are not empty.");
            }
        }

        private void tourresdateTimePicker_ValueChanged(object sender, EventArgs e)
        {
            DateTime tourresdate = DateTime.Parse(tourresdateTimePicker.Text);
            DateTime todaydate = DateTime.Today;// get current date
            if (tourresdate >= todaydate)//run only if start date is today or after
            {
                if (tourrestournamecomboBox.SelectedIndex == 0)//selecteditem is langkawi tour (4d3n)
                {
                    DateTime tourresend = tourresdate.AddDays(4);
                    touresenddateTimePicker.Text = tourresend.ToLongDateString();
                }
                else if (tourrestournamecomboBox.SelectedIndex == 1)//selecteditem is cameron tour (3d2n)
                {
                    DateTime tourresend = tourresdate.AddDays(3);
                    touresenddateTimePicker.Text = tourresend.ToLongDateString();
                }
                else if (tourrestournamecomboBox.SelectedIndex == 2)//selecteditem is tioman tour (5d4n)
                {
                    DateTime tourresend = tourresdate.AddDays(5);
                    touresenddateTimePicker.Text = tourresend.ToLongDateString();
                }
            }
            else
            {
                MessageBox.Show("You cannot reserve a date before today. Date will be resetted to current date.");
                tourresdateTimePicker.ResetText();//reset start date
            }
        }

        private void touresenddateTimePicker_ValueChanged(object sender, EventArgs e)
        {
            DateTime tourresdateend = DateTime.Parse(touresenddateTimePicker.Text);
            DateTime todaydate = DateTime.Today;// get current date
            if (tourresdateend >=todaydate)
            {            
                if (tourrestournamecomboBox.SelectedIndex == 0)//selecteditem is langkawi tour (4d3n)
                {
                    DateTime tourresstart = tourresdateend.AddDays(-4);// enddate minus days to get startdate
                    tourresdateTimePicker.Text = tourresstart.ToLongDateString();
                }
                else if (tourrestournamecomboBox.SelectedIndex == 1)//selecteditem is cameron tour (3d2n)
                {
                    DateTime tourresstart = tourresdateend.AddDays(-3);// enddate minus days to get startdate
                    tourresdateTimePicker.Text = tourresstart.ToLongDateString();
                }
                else if (tourrestournamecomboBox.SelectedIndex == 2)//selecteditem is tioman tour (5d4n)
                {
                    DateTime tourresstart = tourresdateend.AddDays(-5);// enddate minus days to get startdate
                    tourresdateTimePicker.Text = tourresstart.ToLongDateString();
                }
            }
            else
            {
                MessageBox.Show("You cannot reserve a date before today. Date will be resetted to current date.");
                touresenddateTimePicker.ResetText();
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            DateTime tourresdateend = DateTime.Parse(touresenddateTimePicker.Text);
            DateTime todaydate = DateTime.Today;// get current date
            if (tourresdateend >=todaydate)
            {
                if (tourrestournamecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 0) //Langkawi Tour amount =1
                {
                    //pls implement class for this
                    amount = 1;
                    double[] tourprice = new double[] { 960.00, 640.00, 800.00 };
                    totalprice = amount * tourprice[tourrestournamecomboBox.SelectedIndex];
                    tourrespricetextBox.Text = totalprice.ToString();
                }
                else if (tourrestournamecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 1)// Langkawi Tour amount =2
                {
                    amount = 2;
                    double[] tourprice = new double[] { 960.00, 640.00, 800.00 };
                    totalprice = amount * tourprice[tourrestournamecomboBox.SelectedIndex];
                    tourrespricetextBox.Text = totalprice.ToString();
                }
                else if (tourrestournamecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 2)// Langkawi Tour amount =3
                {
                    amount = 3;
                    double[] tourprice = new double[] { 960.00, 640.00, 800.00 };
                    totalprice = amount * tourprice[tourrestournamecomboBox.SelectedIndex];
                    tourrespricetextBox.Text = totalprice.ToString();
                }
                else if (tourrestournamecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 3)// Langkawi Tour amount =4
                {
                    amount = 4;
                    double[] tourprice = new double[] { 960.00, 640.00, 800.00 };
                    totalprice = amount * tourprice[tourrestournamecomboBox.SelectedIndex];
                    tourrespricetextBox.Text = totalprice.ToString();
                }
                else if (tourrestournamecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 4)// Langkawi Tour amount =5
                {
                    amount = 5;
                    double[] tourprice = new double[] { 960.00, 640.00, 800.00 };
                    totalprice = amount * tourprice[tourrestournamecomboBox.SelectedIndex];
                    tourrespricetextBox.Text = totalprice.ToString();
                }
                else if (tourrestournamecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 5)// Langkawi Tour amount =6
                {
                    amount = 6;
                    double[] tourprice = new double[] { 960.00, 640.00, 800.00 };
                    totalprice = amount * tourprice[tourrestournamecomboBox.SelectedIndex];
                    tourrespricetextBox.Text = totalprice.ToString();
                }
                else if (tourrestournamecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 6)// Langkawi Tour amount =7
                {
                    amount = 7;
                    double[] tourprice = new double[] { 960.00, 640.00, 800.00 };
                    totalprice = amount * tourprice[tourrestournamecomboBox.SelectedIndex];
                    tourrespricetextBox.Text = totalprice.ToString();
                }
                else if (tourrestournamecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 7)// Langkawi Tour amount =8
                {
                    amount = 8;
                    double[] tourprice = new double[] { 960.00, 640.00, 800.00 };
                    totalprice = amount * tourprice[tourrestournamecomboBox.SelectedIndex];
                    tourrespricetextBox.Text = totalprice.ToString();
                }
                else if (tourrestournamecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 8)// Langkawi Tour amount =9
                {
                    amount = 9;
                    double[] tourprice = new double[] { 960.00, 640.00, 800.00 };
                    totalprice = amount * tourprice[tourrestournamecomboBox.SelectedIndex];
                    tourrespricetextBox.Text = totalprice.ToString();
                }
                else if (tourrestournamecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 9)// Langkawi Tour amount =10
                {
                    amount = 10;
                    double[] tourprice = new double[] { 960.00, 640.00, 800.00 };
                    totalprice = amount * tourprice[tourrestournamecomboBox.SelectedIndex];
                    tourrespricetextBox.Text = totalprice.ToString();
                }
                else if (tourrestournamecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 0)// Cameron Tour amount =1
                {
                    amount = 1;
                    double[] tourprice = new double[] { 960.00, 640.00, 800.00 };
                    totalprice = amount * tourprice[tourrestournamecomboBox.SelectedIndex];
                    tourrespricetextBox.Text = totalprice.ToString();
                }
                else if (tourrestournamecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 1)// Cameron Tour amount =2
                {
                    amount = 2;
                    double[] tourprice = new double[] { 960.00, 640.00, 800.00 };
                    totalprice = amount * tourprice[tourrestournamecomboBox.SelectedIndex];
                    tourrespricetextBox.Text = totalprice.ToString();
                }
                else if (tourrestournamecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 2)// Cameron Tour amount =3
                {
                    amount = 3;
                    double[] tourprice = new double[] { 960.00, 640.00, 800.00 };
                    totalprice = amount * tourprice[tourrestournamecomboBox.SelectedIndex];
                    tourrespricetextBox.Text = totalprice.ToString();
                }
                else if (tourrestournamecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 3)// Cameron Tour amount =4
                {
                    amount = 4;
                    double[] tourprice = new double[] { 960.00, 640.00, 800.00 };
                    totalprice = amount * tourprice[tourrestournamecomboBox.SelectedIndex];
                    tourrespricetextBox.Text = totalprice.ToString();
                }
                else if (tourrestournamecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 4)// Cameron Tour amount =5
                {
                    amount = 5;
                    double[] tourprice = new double[] { 960.00, 640.00, 800.00 };
                    totalprice = amount * tourprice[tourrestournamecomboBox.SelectedIndex];
                    tourrespricetextBox.Text = totalprice.ToString();
                }
                else if (tourrestournamecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 5)// Cameron Tour amount =6
                {
                    amount = 6;
                    double[] tourprice = new double[] { 960.00, 640.00, 800.00 };
                    totalprice = amount * tourprice[tourrestournamecomboBox.SelectedIndex];
                    tourrespricetextBox.Text = totalprice.ToString();
                }
                else if (tourrestournamecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 6)// Cameron Tour amount =7
                {
                    amount = 7;
                    double[] tourprice = new double[] { 960.00, 640.00, 800.00 };
                    totalprice = amount * tourprice[tourrestournamecomboBox.SelectedIndex];
                    tourrespricetextBox.Text = totalprice.ToString();
                }
                else if (tourrestournamecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 7)// Cameron Tour amount =8
                {
                    amount = 8;
                    double[] tourprice = new double[] { 960.00, 640.00, 800.00 };
                    totalprice = amount * tourprice[tourrestournamecomboBox.SelectedIndex];
                    tourrespricetextBox.Text = totalprice.ToString();
                }
                else if (tourrestournamecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 8)// Cameron Tour amount =9
                {
                    amount = 9;
                    double[] tourprice = new double[] { 960.00, 640.00, 800.00 };
                    totalprice = amount * tourprice[tourrestournamecomboBox.SelectedIndex];
                    tourrespricetextBox.Text = totalprice.ToString();
                }
                else if (tourrestournamecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 9)// Cameron Tour amount =10
                {
                    amount = 10;
                    double[] tourprice = new double[] { 960.00, 640.00, 800.00 };
                    totalprice = amount * tourprice[tourrestournamecomboBox.SelectedIndex];
                    tourrespricetextBox.Text = totalprice.ToString();
                }
                else if (tourrestournamecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 0)// Tioman Tour amount =1
                {
                    amount = 1;
                    double[] tourprice = new double[] { 960.00, 640.00, 800.00 };
                    totalprice = amount * tourprice[tourrestournamecomboBox.SelectedIndex];
                    tourrespricetextBox.Text = totalprice.ToString();
                }
                else if (tourrestournamecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 1)// Tioman Tour amount =2
                {
                    amount = 2;
                    double[] tourprice = new double[] { 960.00, 640.00, 800.00 };
                    totalprice = amount * tourprice[tourrestournamecomboBox.SelectedIndex];
                    tourrespricetextBox.Text = totalprice.ToString();
                }
                else if (tourrestournamecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 2)// Tioman Tour amount =3
                {
                    amount = 3;
                    double[] tourprice = new double[] { 960.00, 640.00, 800.00 };
                    totalprice = amount * tourprice[tourrestournamecomboBox.SelectedIndex];
                    tourrespricetextBox.Text = totalprice.ToString();
                }
                else if (tourrestournamecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 3)// Tioman Tour amount =4
                {
                    amount = 4;
                    double[] tourprice = new double[] { 960.00, 640.00, 800.00 };
                    totalprice = amount * tourprice[tourrestournamecomboBox.SelectedIndex];
                    tourrespricetextBox.Text = totalprice.ToString();
                }
                else if (tourrestournamecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 4)// Tioman Tour amount =5
                {
                    amount = 5;
                    double[] tourprice = new double[] { 960.00, 640.00, 800.00 };
                    totalprice = amount * tourprice[tourrestournamecomboBox.SelectedIndex];
                    tourrespricetextBox.Text = totalprice.ToString();
                }
                else if (tourrestournamecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 5)// Tioman Tour amount =6
                {
                    amount = 6;
                    double[] tourprice = new double[] { 960.00, 640.00, 800.00 };
                    totalprice = amount * tourprice[tourrestournamecomboBox.SelectedIndex];
                    tourrespricetextBox.Text = totalprice.ToString();
                }
                else if (tourrestournamecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 6)// Tioman Tour amount =7
                {
                    amount = 7;
                    double[] tourprice = new double[] { 960.00, 640.00, 800.00 };
                    totalprice = amount * tourprice[tourrestournamecomboBox.SelectedIndex];
                    tourrespricetextBox.Text = totalprice.ToString();
                }
                else if (tourrestournamecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 7)// Tioman Tour amount =8
                {
                    amount = 8;
                    double[] tourprice = new double[] { 960.00, 640.00, 800.00 };
                    totalprice = amount * tourprice[tourrestournamecomboBox.SelectedIndex];
                    tourrespricetextBox.Text = totalprice.ToString();
                }
                else if (tourrestournamecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 8)// Tioman Tour amount =9
                {
                    amount = 9;
                    double[] tourprice = new double[] { 960.00, 640.00, 800.00 };
                    totalprice = amount * tourprice[tourrestournamecomboBox.SelectedIndex];
                    tourrespricetextBox.Text = totalprice.ToString();
                }
                else if (tourrestournamecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 9)// Tioman Tour amount =10
                {
                    amount = 10;
                    double[] tourprice = new double[] { 960.00, 640.00, 800.00 };
                    totalprice = amount * tourprice[tourrestournamecomboBox.SelectedIndex];
                    tourrespricetextBox.Text = totalprice.ToString();
                }
            }
            else
            {
                MessageBox.Show("You cannot reserve a date before today. Date will be resetted to current date.");
                tourresdateTimePicker.ResetText();//reset start date
                touresenddateTimePicker.ResetText();//reset end date
            }
        }
    }
}
