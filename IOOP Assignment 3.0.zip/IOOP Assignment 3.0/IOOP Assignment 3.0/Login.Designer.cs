﻿namespace IOOP_Assignment_3._0
{
    partial class Login
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.usernamelabel = new System.Windows.Forms.Label();
            this.passwordlabel = new System.Windows.Forms.Label();
            this.usernametextBox = new System.Windows.Forms.TextBox();
            this.passwordtextBox = new System.Windows.Forms.TextBox();
            this.loginbutton = new System.Windows.Forms.Button();
            this.exitbutton = new System.Windows.Forms.Button();
            this.viewcheckBox = new System.Windows.Forms.CheckBox();
            this.reportgenbutton = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // usernamelabel
            // 
            this.usernamelabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.usernamelabel.AutoSize = true;
            this.usernamelabel.Location = new System.Drawing.Point(36, 51);
            this.usernamelabel.Name = "usernamelabel";
            this.usernamelabel.Size = new System.Drawing.Size(55, 13);
            this.usernamelabel.TabIndex = 0;
            this.usernamelabel.Text = "Username";
            // 
            // passwordlabel
            // 
            this.passwordlabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.passwordlabel.AutoSize = true;
            this.passwordlabel.Location = new System.Drawing.Point(36, 94);
            this.passwordlabel.Name = "passwordlabel";
            this.passwordlabel.Size = new System.Drawing.Size(53, 13);
            this.passwordlabel.TabIndex = 1;
            this.passwordlabel.Text = "Password";
            // 
            // usernametextBox
            // 
            this.usernametextBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.usernametextBox.Location = new System.Drawing.Point(122, 48);
            this.usernametextBox.Name = "usernametextBox";
            this.usernametextBox.Size = new System.Drawing.Size(193, 20);
            this.usernametextBox.TabIndex = 2;
            // 
            // passwordtextBox
            // 
            this.passwordtextBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.passwordtextBox.Location = new System.Drawing.Point(122, 91);
            this.passwordtextBox.Name = "passwordtextBox";
            this.passwordtextBox.Size = new System.Drawing.Size(193, 20);
            this.passwordtextBox.TabIndex = 3;
            this.passwordtextBox.UseSystemPasswordChar = true;
            // 
            // loginbutton
            // 
            this.loginbutton.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.loginbutton.Location = new System.Drawing.Point(42, 186);
            this.loginbutton.Name = "loginbutton";
            this.loginbutton.Size = new System.Drawing.Size(75, 23);
            this.loginbutton.TabIndex = 4;
            this.loginbutton.Text = "Login";
            this.loginbutton.UseVisualStyleBackColor = true;
            this.loginbutton.Click += new System.EventHandler(this.button1_Click);
            // 
            // exitbutton
            // 
            this.exitbutton.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.exitbutton.Location = new System.Drawing.Point(156, 186);
            this.exitbutton.Name = "exitbutton";
            this.exitbutton.Size = new System.Drawing.Size(75, 23);
            this.exitbutton.TabIndex = 4;
            this.exitbutton.Text = "Exit";
            this.exitbutton.UseVisualStyleBackColor = true;
            this.exitbutton.Click += new System.EventHandler(this.exitbutton_Click);
            // 
            // viewcheckBox
            // 
            this.viewcheckBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.viewcheckBox.AutoSize = true;
            this.viewcheckBox.Location = new System.Drawing.Point(156, 130);
            this.viewcheckBox.Name = "viewcheckBox";
            this.viewcheckBox.Size = new System.Drawing.Size(98, 17);
            this.viewcheckBox.TabIndex = 5;
            this.viewcheckBox.Text = "View Password";
            this.viewcheckBox.UseVisualStyleBackColor = true;
            this.viewcheckBox.CheckedChanged += new System.EventHandler(this.viewcheckBox_CheckedChanged);
            // 
            // reportgenbutton
            // 
            this.reportgenbutton.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.reportgenbutton.Location = new System.Drawing.Point(271, 179);
            this.reportgenbutton.Name = "reportgenbutton";
            this.reportgenbutton.Size = new System.Drawing.Size(75, 36);
            this.reportgenbutton.TabIndex = 6;
            this.reportgenbutton.Text = "Report Generation";
            this.reportgenbutton.UseVisualStyleBackColor = true;
            this.reportgenbutton.Click += new System.EventHandler(this.reportgenbutton_Click);
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(39, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(97, 13);
            this.label1.TabIndex = 7;
            this.label1.Text = "Login For Workers:";
            // 
            // Login
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(385, 227);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.reportgenbutton);
            this.Controls.Add(this.viewcheckBox);
            this.Controls.Add(this.exitbutton);
            this.Controls.Add(this.loginbutton);
            this.Controls.Add(this.passwordtextBox);
            this.Controls.Add(this.usernametextBox);
            this.Controls.Add(this.passwordlabel);
            this.Controls.Add(this.usernamelabel);
            this.Name = "Login";
            this.Text = "Login Interface";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label usernamelabel;
        private System.Windows.Forms.Label passwordlabel;
        private System.Windows.Forms.TextBox usernametextBox;
        private System.Windows.Forms.TextBox passwordtextBox;
        private System.Windows.Forms.Button loginbutton;
        private System.Windows.Forms.Button exitbutton;
        private System.Windows.Forms.CheckBox viewcheckBox;
        private System.Windows.Forms.Button reportgenbutton;
        private System.Windows.Forms.Label label1;
    }
}