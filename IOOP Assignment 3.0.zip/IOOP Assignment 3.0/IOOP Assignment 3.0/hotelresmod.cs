﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace IOOP_Assignment_3._0
{
    public partial class hotelresmod : Form
    {
        public hotelresmod()
        {
            InitializeComponent();
        }
        string hoteln;
        string roomt;
        double roomp;
        double dayr;
        double totalprice;

        private void resmodmainmenubutton_Click(object sender, EventArgs e)
        {
            const string message = "Do you want to go to MAIN MENU?";
            const string caption = "MAIN MENU";
            var result = MessageBox.Show(message, caption, MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes) //if user click on "yes", the program would be closed, 
                                            //if not message box would be close
            {
                MainMenu newForm = new MainMenu();
                newForm.Show();
                this.Hide();
            }
        }

        private void backbutton_Click(object sender, EventArgs e)
        {
            reservationmodselection newForm = new reservationmodselection();
            newForm.Show();
            this.Hide();
        }

        private void displayholiresbutton_Click(object sender, EventArgs e)
        {
            string connectionString = "Provider =Microsoft.ACE.OLEDB.12.0; Data Source =IOOPDb.accdb";
            string sql = "SELECT * FROM hotelres";
            OleDbConnection connection = new OleDbConnection(connectionString);
            OleDbDataAdapter dataadapter = new OleDbDataAdapter(sql, connection);
            DataSet ds = new DataSet();
            connection.Open();
            dataadapter.Fill(ds, "hotelres_table");
            connection.Close();
            hotelresdataGridView.DataSource = ds;
            hotelresdataGridView.DataMember = "hotelres_table";
        }

        private void hotelresstartdateTimePicker_ValueChanged(object sender, EventArgs e)
        {
            DateTime startreserveddatehotelres = DateTime.Parse(hotelresstartdateTimePicker.Text);
            DateTime endreserveddatehotelres = DateTime.Parse(hotelresenddateTimePicker.Text);
            DateTime todaydate = DateTime.Today;
            if (startreserveddatehotelres < todaydate)
            {
                MessageBox.Show("You cannot reserve a date before today. The date will be resetted to current date.");
                hotelresstartdateTimePicker.ResetText();
            }
            else if (startreserveddatehotelres>=todaydate && startreserveddatehotelres<endreserveddatehotelres)
            {
                double dayr = (endreserveddatehotelres - startreserveddatehotelres).TotalDays;
                if (startreserveddatehotelres < endreserveddatehotelres)//prevent price calculation and display when startdate and end date are equal.
                {
                    if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 0)//CHR Single 1
                    {
                        roomp = 144;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 1 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 1)//CHR Single 2
                    {
                        roomp = 144;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 2 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 2)//CHR Single 3
                    {
                        roomp = 144;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 3 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 3)//CHR Single 4
                    {
                        roomp = 144;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 4 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 4)//CHR Single 5
                    {
                        roomp = 144;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 5 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 5)//CHR Single 6
                    {
                        roomp = 144;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 6 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 6)//CHR Single 7
                    {
                        roomp = 144;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 7 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 7)//CHR Single 8
                    {
                        roomp = 144;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 8 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 8)//CHR Single 9
                    {
                        roomp = 144;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 9 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 9)//CHR Single 10
                    {
                        roomp = 144;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 10 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 0)//CHR Double 1
                    {
                        roomp = 280;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 1 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 1)//CHR Double 2
                    {
                        roomp = 280;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 2 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 2)//CHR Double 3
                    {
                        roomp = 280;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 3 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 3)//CHR Double 4
                    {
                        roomp = 280;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 4 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 4)//CHR Double 5
                    {
                        roomp = 280;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 5 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 5)//CHR Double 6
                    {
                        roomp = 280;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 6 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 6)//CHR Double 7
                    {
                        roomp = 280;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 7 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 7)//CHR Double 8
                    {
                        roomp = 280;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 8 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 8)//CHR Double 9
                    {
                        roomp = 280;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 9 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 9)//CHR Double 10
                    {
                        roomp = 280;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 10 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 0)//CHR Family Suite 1
                    {
                        roomp = 400;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 1 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 1)//CHR Family Suite 2
                    {
                        roomp = 400;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 2 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 2)//CHR Family Suite 3
                    {
                        roomp = 400;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 3 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 3)//CHR Family Suite 4
                    {
                        roomp = 400;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 4 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 4)//CHR Family Suite 5
                    {
                        roomp = 400;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 5 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 5)//CHR Family Suite 6
                    {
                        roomp = 400;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 6 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 6)//CHR Family Suite 7
                    {
                        roomp = 400;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 7 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 7)//CHR Family Suite 8
                    {
                        roomp = 400;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 8 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 8)//CHR Family Suite 9
                    {
                        roomp = 400;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 9 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 9)//CHR Family Suite 10
                    {
                        roomp = 400;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 10 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 1 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 0)//CP Single 1
                    {
                        roomp = 160;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 1 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 1 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 1)//CP Single 2
                    {
                        roomp = 160;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 2 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 1 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 2)//CP Single 3
                    {
                        roomp = 160;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 3 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 1 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 3)//CP Single 4
                    {
                        roomp = 160;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 4 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 1 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 4)//CP Single 5
                    {
                        roomp = 160;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 5 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 1 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 5)//CP Single 6
                    {
                        roomp = 160;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 6 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 1 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 6)//CP Single 7
                    {
                        roomp = 160;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 7 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 1 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 7)//CP Single 8
                    {
                        roomp = 160;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 8 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 1 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 8)//CP Single 9
                    {
                        roomp = 160;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 9 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 1 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 9)//CP Single 10
                    {
                        roomp = 160;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 10 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 1 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 0)//CP Double 1
                    {
                        roomp = 288;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 1 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 1 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 1)//CP Double 2
                    {
                        roomp = 288;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 2 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 1 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 2)//CP Double 3
                    {
                        roomp = 288;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 3 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 1 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 3)//CP Double 4
                    {
                        roomp = 288;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 4 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 1 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 4)//CP Double 5
                    {
                        roomp = 288;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 5 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 1 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 5)//CP Double 6
                    {
                        roomp = 288;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 6 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 1 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 6)//CP Double 7
                    {
                        roomp = 288;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 7 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 1 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 7)//CP Double 8
                    {
                        roomp = 288;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 8 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 1 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 8)//CP Double 9
                    {
                        roomp = 288;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 9 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 1 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 9)//CP Double 10
                    {
                        roomp = 288;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 10 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 1 && hotelresroomtypecomboBox.SelectedIndex == 2)//CP Family Suite (Not available)
                    {
                        hotelrespricetextBox.Text = "Unavailable.";
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 0)// LB Single 1
                    {
                        roomp = 160;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 1 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 1)// LB Single 2
                    {
                        roomp = 160;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 2 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 2)// LB Single 3
                    {
                        roomp = 160;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 3 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 3)// LB Single 4
                    {
                        roomp = 160;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 4 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 4)// LB Single 5
                    {
                        roomp = 160;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 5 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 5)// LB Single 6
                    {
                        roomp = 160;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 6 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 6)// LB Single 7
                    {
                        roomp = 160;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 7 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 7)// LB Single 8
                    {
                        roomp = 160;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 8 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 8)// LB Single 9
                    {
                        roomp = 160;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 9 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 9)// LB Single 10
                    {
                        roomp = 160;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 10 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 0)// LB Double 1
                    {
                        roomp = 304;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 1 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 1)// LB Double 2
                    {
                        roomp = 304;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 2 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 2)// LB Double 3
                    {
                        roomp = 304;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 3 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 3)// LB Double 4
                    {
                        roomp = 304;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 4 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 4)// LB Double 5
                    {
                        roomp = 304;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 5 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 5)// LB Double 6
                    {
                        roomp = 304;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 6 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 6)// LB Double 7
                    {
                        roomp = 304;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 7 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 7)// LB Double 8
                    {
                        roomp = 304;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 8 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 8)// LB Double 9
                    {
                        roomp = 304;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 9 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 9)// LB Double 10
                    {
                        roomp = 304;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 10 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 0)// LB Family Suite 1
                    {
                        roomp = 480;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 1 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 1)// LB Family Suite 2
                    {
                        roomp = 480;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 2 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 2)// LB Family Suite 3
                    {
                        roomp = 480;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 3 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 3)// LB Family Suite 4
                    {
                        roomp = 480;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 4 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 4)// LB Family Suite 5
                    {
                        roomp = 480;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 5 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 5)// LB Family Suite 6
                    {
                        roomp = 480;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 6 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 6)// LB Family Suite 7
                    {
                        roomp = 480;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 7 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 7)// LB Family Suite 8
                    {
                        roomp = 480;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 8 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 8)// LB Family Suite 9
                    {
                        roomp = 480;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 9 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 9)// LB Family Suite 10
                    {
                        roomp = 480;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 10 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 0)// LA Single 1
                    {
                        roomp = 144;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 1 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 1)// LA Single 2
                    {
                        roomp = 144;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 2 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 2)// LA Single 3
                    {
                        roomp = 144;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 3 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 3)// LA Single 4
                    {
                        roomp = 144;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 4 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 4)// LA Single 5
                    {
                        roomp = 144;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 5 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 5)// LA Single 6
                    {
                        roomp = 144;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 6 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 6)// LA Single 7
                    {
                        roomp = 144;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 7 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 7)// LA Single 8
                    {
                        roomp = 144;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 8 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 8)// LA Single 9
                    {
                        roomp = 144;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 9 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 9)// LA Single 10
                    {
                        roomp = 144;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 10 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 0)// LA Double 1
                    {
                        roomp = 192;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 1 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 1)// LA Double 2
                    {
                        roomp = 192;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 2 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 2)// LA Double 3
                    {
                        roomp = 192;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 3 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 3)// LA Double 4
                    {
                        roomp = 192;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 4 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 4)// LA Double 5
                    {
                        roomp = 192;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 5 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 5)// LA Double 6
                    {
                        roomp = 192;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 6 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 6)// LA Double 7
                    {
                        roomp = 192;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 7 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 7)// LA Double 8
                    {
                        roomp = 192;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 8 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 8)// LA Double 9
                    {
                        roomp = 192;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 9 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 9)// LA Double 10
                    {
                        roomp = 192;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 10 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 0)// LA Family Suite 1
                    {
                        roomp = 320;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 1 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 1)// LA Family Suite 2
                    {
                        roomp = 320;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 2 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 2)// LA Family Suite 3
                    {
                        roomp = 320;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 3 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 3)// LA Family Suite 4
                    {
                        roomp = 320;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 4 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 4)// LA Family Suite 5
                    {
                        roomp = 320;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 5 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 5)// LA Family Suite 6
                    {
                        roomp = 320;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 6 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 6)// LA Family Suite 7
                    {
                        roomp = 320;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 7 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 7)// LA Family Suite 8
                    {
                        roomp = 320;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 8 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 8)// LA Family Suite 9
                    {
                        roomp = 320;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 9 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 9)// LA Family Suite 10
                    {
                        roomp = 320;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 10 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 0)// TT Single 1
                    {
                        roomp = 176;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 1 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 1)// TT Single 2
                    {
                        roomp = 176;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 2 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 2)// TT Single 3
                    {
                        roomp = 176;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 3 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 3)// TT Single 4
                    {
                        roomp = 176;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 4 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 4)// TT Single 5
                    {
                        roomp = 176;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 5 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 5)// TT Single 6
                    {
                        roomp = 176;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 6 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 6)// TT Single 7
                    {
                        roomp = 176;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 7 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 7)// TT Single 8
                    {
                        roomp = 176;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 8 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 8)// TT Single 9
                    {
                        roomp = 176;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 9 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 9)// TT Single 10
                    {
                        roomp = 176;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 10 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 0)// TT Double 1
                    {
                        roomp = 280;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 1 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 1)// TT Double 2
                    {
                        roomp = 280;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 2 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 2)// TT Double 3
                    {
                        roomp = 280;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 3 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 3)// TT Double 4
                    {
                        roomp = 280;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 4 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 4)// TT Double 5
                    {
                        roomp = 280;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 5 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 5)// TT Double 6
                    {
                        roomp = 280;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 6 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 6)// TT Double 7
                    {
                        roomp = 280;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 7 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 7)// TT Double 8
                    {
                        roomp = 280;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 8 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 8)// TT Double 9
                    {
                        roomp = 280;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 9 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 9)// TT Double 10
                    {
                        roomp = 280;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 10 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 0)// TT Family Suite 1
                    {
                        roomp = 384;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 1 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 1)// TT Family Suite 2
                    {
                        roomp = 384;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 2 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 2)// TT Family Suite 3
                    {
                        roomp = 384;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 3 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 3)// TT Family Suite 4
                    {
                        roomp = 384;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 4 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 4)// TT Family Suite 5
                    {
                        roomp = 384;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 5 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 5)// TT Family Suite 6
                    {
                        roomp = 384;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 6 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 6)// TT Family Suite 7
                    {
                        roomp = 384;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 7 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 7)// TT Family Suite 8
                    {
                        roomp = 384;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 8 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 8)// TT Family Suite 9
                    {
                        roomp = 384;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 9 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 9)// TT Family Suite 10
                    {
                        roomp = 384;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 10 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 0)// TB Single 1
                    {
                        roomp = 200;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 1 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 1)// TB Single 2
                    {
                        roomp = 200;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 2 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 2)// TB Single 3
                    {
                        roomp = 200;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 3 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 3)// TB Single 4
                    {
                        roomp = 200;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 4 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 4)// TB Single 5
                    {
                        roomp = 200;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 5 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 5)// TB Single 6
                    {
                        roomp = 200;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 6 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 6)// TB Single 7
                    {
                        roomp = 200;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 7 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 7)// TB Single 8
                    {
                        roomp = 200;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 8 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 8)// TB Single 9
                    {
                        roomp = 200;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 9 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 9)// TB Single 10
                    {
                        roomp = 200;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 10 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 0)// TB Double 1
                    {
                        roomp = 304;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 1 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 1)// TB Double 2
                    {
                        roomp = 304;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 2 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 2)// TB Double 3
                    {
                        roomp = 304;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 3 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 3)// TB Double 4
                    {
                        roomp = 304;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 4 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 4)// TB Double 5
                    {
                        roomp = 304;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 5 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 5)// TB Double 6
                    {
                        roomp = 304;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 5 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 6)// TB Double 7
                    {
                        roomp = 304;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 6 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 7)// TB Double 8
                    {
                        roomp = 304;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 8 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 8)// TB Double 9
                    {
                        roomp = 304;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 9 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 9)// TB Double 10
                    {
                        roomp = 304;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 10 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 0)// TB Family Suite 1
                    {
                        roomp = 410;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 1 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 1)// TB Family Suite 2
                    {
                        roomp = 410;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 2 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 2)// TB Family Suite 3
                    {
                        roomp = 410;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 3 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 3)// TB Family Suite 4
                    {
                        roomp = 410;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 4 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 4)// TB Family Suite 5
                    {
                        roomp = 410;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 5 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 5)// TB Family Suite 6
                    {
                        roomp = 410;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 6 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 6)// TB Family Suite 7
                    {
                        roomp = 410;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 7 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 7)// TB Family Suite 8
                    {
                        roomp = 410;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 8 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 8)// TB Family Suite 9
                    {
                        roomp = 410;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 9 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 9)// TB Family Suite 10
                    {
                        roomp = 410;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 10 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }

                }
            }
        }

        private void hotelresenddateTimePicker_ValueChanged(object sender, EventArgs e)
        {
            DateTime todaydate = DateTime.Today;     //so that end reserved date is not before today's date
            DateTime startreserveddatehotelres = DateTime.Parse(hotelresstartdateTimePicker.Text);
            DateTime endreserveddatehotelres = DateTime.Parse(hotelresenddateTimePicker.Text);
            if (endreserveddatehotelres < todaydate)
            {
                MessageBox.Show("You cannot reserve a date before today. Date will be resetted to current date.");
                hotelresenddateTimePicker.ResetText();//reset to current date
            }

            else if (endreserveddatehotelres < startreserveddatehotelres)
            {
                MessageBox.Show("Please ensure the dates are correct. Date will be resetted to current date.");
                hotelresstartdateTimePicker.ResetText();//reset to current date, order matters reset startdate first before enddate
                hotelresenddateTimePicker.ResetText();
            }
            else
            {
                double dayr = (endreserveddatehotelres - startreserveddatehotelres).TotalDays;
                if (startreserveddatehotelres < endreserveddatehotelres)//prevent price calculation and display when startdate and end date are equal.
                {
                    if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 0)//CHR Single 1
                    {
                        roomp = 144;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 1 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 1)//CHR Single 2
                    {
                        roomp = 144;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 2 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 2)//CHR Single 3
                    {
                        roomp = 144;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 3 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 3)//CHR Single 4
                    {
                        roomp = 144;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 4 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 4)//CHR Single 5
                    {
                        roomp = 144;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 5 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 5)//CHR Single 6
                    {
                        roomp = 144;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 6 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 6)//CHR Single 7
                    {
                        roomp = 144;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 7 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 7)//CHR Single 8
                    {
                        roomp = 144;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 8 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 8)//CHR Single 9
                    {
                        roomp = 144;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 9 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 9)//CHR Single 10
                    {
                        roomp = 144;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 10 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 0)//CHR Double 1
                    {
                        roomp = 280;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 1 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 1)//CHR Double 2
                    {
                        roomp = 280;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 2 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 2)//CHR Double 3
                    {
                        roomp = 280;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 3 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 3)//CHR Double 4
                    {
                        roomp = 280;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 4 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 4)//CHR Double 5
                    {
                        roomp = 280;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 5 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 5)//CHR Double 6
                    {
                        roomp = 280;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 6 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 6)//CHR Double 7
                    {
                        roomp = 280;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 7 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 7)//CHR Double 8
                    {
                        roomp = 280;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 8 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 8)//CHR Double 9
                    {
                        roomp = 280;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 9 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 9)//CHR Double 10
                    {
                        roomp = 280;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 10 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 0)//CHR Family Suite 1
                    {
                        roomp = 400;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 1 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 1)//CHR Family Suite 2
                    {
                        roomp = 400;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 2 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 2)//CHR Family Suite 3
                    {
                        roomp = 400;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 3 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 3)//CHR Family Suite 4
                    {
                        roomp = 400;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 4 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 4)//CHR Family Suite 5
                    {
                        roomp = 400;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 5 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 5)//CHR Family Suite 6
                    {
                        roomp = 400;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 6 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 6)//CHR Family Suite 7
                    {
                        roomp = 400;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 7 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 7)//CHR Family Suite 8
                    {
                        roomp = 400;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 8 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 8)//CHR Family Suite 9
                    {
                        roomp = 400;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 9 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 9)//CHR Family Suite 10
                    {
                        roomp = 400;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 10 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 1 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 0)//CP Single 1
                    {
                        roomp = 160;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 1 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 1 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 1)//CP Single 2
                    {
                        roomp = 160;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 2 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 1 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 2)//CP Single 3
                    {
                        roomp = 160;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 3 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 1 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 3)//CP Single 4
                    {
                        roomp = 160;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 4 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 1 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 4)//CP Single 5
                    {
                        roomp = 160;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 5 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 1 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 5)//CP Single 6
                    {
                        roomp = 160;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 6 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 1 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 6)//CP Single 7
                    {
                        roomp = 160;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 7 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 1 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 7)//CP Single 8
                    {
                        roomp = 160;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 8 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 1 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 8)//CP Single 9
                    {
                        roomp = 160;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 9 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 1 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 9)//CP Single 10
                    {
                        roomp = 160;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 10 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 1 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 0)//CP Double 1
                    {
                        roomp = 288;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 1 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 1 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 1)//CP Double 2
                    {
                        roomp = 288;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 2 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 1 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 2)//CP Double 3
                    {
                        roomp = 288;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 3 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 1 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 3)//CP Double 4
                    {
                        roomp = 288;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 4 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 1 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 4)//CP Double 5
                    {
                        roomp = 288;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 5 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 1 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 5)//CP Double 6
                    {
                        roomp = 288;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 6 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 1 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 6)//CP Double 7
                    {
                        roomp = 288;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 7 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 1 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 7)//CP Double 8
                    {
                        roomp = 288;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 8 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 1 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 8)//CP Double 9
                    {
                        roomp = 288;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 9 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 1 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 9)//CP Double 10
                    {
                        roomp = 288;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 10 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 1 && hotelresroomtypecomboBox.SelectedIndex == 2)//CP Family Suite (Not available)
                    {
                        hotelrespricetextBox.Text = "Unavailable.";
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 0)// LB Single 1
                    {
                        roomp = 160;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 1 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 1)// LB Single 2
                    {
                        roomp = 160;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 2 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 2)// LB Single 3
                    {
                        roomp = 160;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 3 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 3)// LB Single 4
                    {
                        roomp = 160;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 4 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 4)// LB Single 5
                    {
                        roomp = 160;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 5 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 5)// LB Single 6
                    {
                        roomp = 160;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 6 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 6)// LB Single 7
                    {
                        roomp = 160;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 7 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 7)// LB Single 8
                    {
                        roomp = 160;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 8 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 8)// LB Single 9
                    {
                        roomp = 160;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 9 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 9)// LB Single 10
                    {
                        roomp = 160;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 10 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 0)// LB Double 1
                    {
                        roomp = 304;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 1 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 1)// LB Double 2
                    {
                        roomp = 304;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 2 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 2)// LB Double 3
                    {
                        roomp = 304;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 3 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 3)// LB Double 4
                    {
                        roomp = 304;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 4 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 4)// LB Double 5
                    {
                        roomp = 304;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 5 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 5)// LB Double 6
                    {
                        roomp = 304;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 6 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 6)// LB Double 7
                    {
                        roomp = 304;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 7 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 7)// LB Double 8
                    {
                        roomp = 304;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 8 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 8)// LB Double 9
                    {
                        roomp = 304;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 9 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 9)// LB Double 10
                    {
                        roomp = 304;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 10 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 0)// LB Family Suite 1
                    {
                        roomp = 480;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 1 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 1)// LB Family Suite 2
                    {
                        roomp = 480;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 2 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 2)// LB Family Suite 3
                    {
                        roomp = 480;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 3 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 3)// LB Family Suite 4
                    {
                        roomp = 480;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 4 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 4)// LB Family Suite 5
                    {
                        roomp = 480;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 5 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 5)// LB Family Suite 6
                    {
                        roomp = 480;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 6 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 6)// LB Family Suite 7
                    {
                        roomp = 480;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 7 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 7)// LB Family Suite 8
                    {
                        roomp = 480;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 8 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 8)// LB Family Suite 9
                    {
                        roomp = 480;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 9 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 9)// LB Family Suite 10
                    {
                        roomp = 480;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 10 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 0)// LA Single 1
                    {
                        roomp = 144;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 1 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 1)// LA Single 2
                    {
                        roomp = 144;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 2 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 2)// LA Single 3
                    {
                        roomp = 144;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 3 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 3)// LA Single 4
                    {
                        roomp = 144;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 4 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 4)// LA Single 5
                    {
                        roomp = 144;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 5 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 5)// LA Single 6
                    {
                        roomp = 144;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 6 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 6)// LA Single 7
                    {
                        roomp = 144;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 7 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 7)// LA Single 8
                    {
                        roomp = 144;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 8 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 8)// LA Single 9
                    {
                        roomp = 144;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 9 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 9)// LA Single 10
                    {
                        roomp = 144;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 10 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 0)// LA Double 1
                    {
                        roomp = 192;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 1 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 1)// LA Double 2
                    {
                        roomp = 192;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 2 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 2)// LA Double 3
                    {
                        roomp = 192;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 3 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 3)// LA Double 4
                    {
                        roomp = 192;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 4 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 4)// LA Double 5
                    {
                        roomp = 192;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 5 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 5)// LA Double 6
                    {
                        roomp = 192;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 6 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 6)// LA Double 7
                    {
                        roomp = 192;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 7 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 7)// LA Double 8
                    {
                        roomp = 192;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 8 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 8)// LA Double 9
                    {
                        roomp = 192;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 9 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 9)// LA Double 10
                    {
                        roomp = 192;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 10 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 0)// LA Family Suite 1
                    {
                        roomp = 320;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 1 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 1)// LA Family Suite 2
                    {
                        roomp = 320;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 2 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 2)// LA Family Suite 3
                    {
                        roomp = 320;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 3 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 3)// LA Family Suite 4
                    {
                        roomp = 320;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 4 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 4)// LA Family Suite 5
                    {
                        roomp = 320;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 5 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 5)// LA Family Suite 6
                    {
                        roomp = 320;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 6 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 6)// LA Family Suite 7
                    {
                        roomp = 320;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 7 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 7)// LA Family Suite 8
                    {
                        roomp = 320;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 8 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 8)// LA Family Suite 9
                    {
                        roomp = 320;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 9 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 9)// LA Family Suite 10
                    {
                        roomp = 320;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 10 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 0)// TT Single 1
                    {
                        roomp = 176;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 1 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 1)// TT Single 2
                    {
                        roomp = 176;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 2 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 2)// TT Single 3
                    {
                        roomp = 176;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 3 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 3)// TT Single 4
                    {
                        roomp = 176;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 4 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 4)// TT Single 5
                    {
                        roomp = 176;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 5 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 5)// TT Single 6
                    {
                        roomp = 176;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 6 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 6)// TT Single 7
                    {
                        roomp = 176;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 7 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 7)// TT Single 8
                    {
                        roomp = 176;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 8 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 8)// TT Single 9
                    {
                        roomp = 176;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 9 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 9)// TT Single 10
                    {
                        roomp = 176;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 10 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 0)// TT Double 1
                    {
                        roomp = 280;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 1 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 1)// TT Double 2
                    {
                        roomp = 280;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 2 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 2)// TT Double 3
                    {
                        roomp = 280;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 3 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 3)// TT Double 4
                    {
                        roomp = 280;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 4 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 4)// TT Double 5
                    {
                        roomp = 280;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 5 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 5)// TT Double 6
                    {
                        roomp = 280;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 6 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 6)// TT Double 7
                    {
                        roomp = 280;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 7 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 7)// TT Double 8
                    {
                        roomp = 280;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 8 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 8)// TT Double 9
                    {
                        roomp = 280;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 9 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 9)// TT Double 10
                    {
                        roomp = 280;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 10 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 0)// TT Family Suite 1
                    {
                        roomp = 384;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 1 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 1)// TT Family Suite 2
                    {
                        roomp = 384;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 2 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 2)// TT Family Suite 3
                    {
                        roomp = 384;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 3 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 3)// TT Family Suite 4
                    {
                        roomp = 384;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 4 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 4)// TT Family Suite 5
                    {
                        roomp = 384;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 5 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 5)// TT Family Suite 6
                    {
                        roomp = 384;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 6 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 6)// TT Family Suite 7
                    {
                        roomp = 384;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 7 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 7)// TT Family Suite 8
                    {
                        roomp = 384;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 8 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 8)// TT Family Suite 9
                    {
                        roomp = 384;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 9 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 9)// TT Family Suite 10
                    {
                        roomp = 384;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 10 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 0)// TB Single 1
                    {
                        roomp = 200;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 1 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 1)// TB Single 2
                    {
                        roomp = 200;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 2 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 2)// TB Single 3
                    {
                        roomp = 200;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 3 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 3)// TB Single 4
                    {
                        roomp = 200;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 4 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 4)// TB Single 5
                    {
                        roomp = 200;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 5 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 5)// TB Single 6
                    {
                        roomp = 200;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 6 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 6)// TB Single 7
                    {
                        roomp = 200;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 7 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 7)// TB Single 8
                    {
                        roomp = 200;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 8 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 8)// TB Single 9
                    {
                        roomp = 200;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 9 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 9)// TB Single 10
                    {
                        roomp = 200;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 10 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 0)// TB Double 1
                    {
                        roomp = 304;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 1 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 1)// TB Double 2
                    {
                        roomp = 304;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 2 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 2)// TB Double 3
                    {
                        roomp = 304;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 3 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 3)// TB Double 4
                    {
                        roomp = 304;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 4 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 4)// TB Double 5
                    {
                        roomp = 304;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 5 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 5)// TB Double 6
                    {
                        roomp = 304;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 5 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 6)// TB Double 7
                    {
                        roomp = 304;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 6 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 7)// TB Double 8
                    {
                        roomp = 304;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 8 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 8)// TB Double 9
                    {
                        roomp = 304;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 9 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 9)// TB Double 10
                    {
                        roomp = 304;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 10 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 0)// TB Family Suite 1
                    {
                        roomp = 410;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 1 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 1)// TB Family Suite 2
                    {
                        roomp = 410;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 2 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 2)// TB Family Suite 3
                    {
                        roomp = 410;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 3 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 3)// TB Family Suite 4
                    {
                        roomp = 410;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 4 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 4)// TB Family Suite 5
                    {
                        roomp = 410;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 5 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 5)// TB Family Suite 6
                    {
                        roomp = 410;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 6 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 6)// TB Family Suite 7
                    {
                        roomp = 410;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 7 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 7)// TB Family Suite 8
                    {
                        roomp = 410;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 8 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 8)// TB Family Suite 9
                    {
                        roomp = 410;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 9 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                    else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 9)// TB Family Suite 10
                    {
                        roomp = 410;
                        hotel h = new hotel(hoteln, roomt, roomp, dayr);
                        totalprice = 10 * h.price(dayr, roomp);
                        hotelrespricetextBox.Text = totalprice.ToString();
                    }
                }
            }
        }

        private void hotelreshotelnamecomboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            DateTime startreserveddatehotelres = DateTime.Parse(hotelresstartdateTimePicker.Text);
            DateTime endreserveddatehotelres = DateTime.Parse(hotelresenddateTimePicker.Text);
            dayr = (endreserveddatehotelres - startreserveddatehotelres).TotalDays;
            if (startreserveddatehotelres < endreserveddatehotelres)//prevent price calculation and display when startdate and end date are equal.
            {
                if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 0)//CHR Single 1
                {
                    roomp = 144;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 1 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 1)//CHR Single 2
                {
                    roomp = 144;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 2 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 2)//CHR Single 3
                {
                    roomp = 144;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 3 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 3)//CHR Single 4
                {
                    roomp = 144;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 4 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 4)//CHR Single 5
                {
                    roomp = 144;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 5 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 5)//CHR Single 6
                {
                    roomp = 144;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 6 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 6)//CHR Single 7
                {
                    roomp = 144;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 7 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 7)//CHR Single 8
                {
                    roomp = 144;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 8 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 8)//CHR Single 9
                {
                    roomp = 144;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 9 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 9)//CHR Single 10
                {
                    roomp = 144;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 10 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 0)//CHR Double 1
                {
                    roomp = 280;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 1 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 1)//CHR Double 2
                {
                    roomp = 280;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 2 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 2)//CHR Double 3
                {
                    roomp = 280;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 3 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 3)//CHR Double 4
                {
                    roomp = 280;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 4 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 4)//CHR Double 5
                {
                    roomp = 280;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 5 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 5)//CHR Double 6
                {
                    roomp = 280;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 6 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 6)//CHR Double 7
                {
                    roomp = 280;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 7 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 7)//CHR Double 8
                {
                    roomp = 280;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 8 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 8)//CHR Double 9
                {
                    roomp = 280;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 9 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 9)//CHR Double 10
                {
                    roomp = 280;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 10 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 0)//CHR Family Suite 1
                {
                    roomp = 400;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 1 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 1)//CHR Family Suite 2
                {
                    roomp = 400;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 2 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 2)//CHR Family Suite 3
                {
                    roomp = 400;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 3 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 3)//CHR Family Suite 4
                {
                    roomp = 400;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 4 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 4)//CHR Family Suite 5
                {
                    roomp = 400;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 5 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 5)//CHR Family Suite 6
                {
                    roomp = 400;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 6 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 6)//CHR Family Suite 7
                {
                    roomp = 400;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 7 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 7)//CHR Family Suite 8
                {
                    roomp = 400;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 8 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 8)//CHR Family Suite 9
                {
                    roomp = 400;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 9 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 9)//CHR Family Suite 10
                {
                    roomp = 400;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 10 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 1 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 0)//CP Single 1
                {
                    roomp = 160;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 1 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 1 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 1)//CP Single 2
                {
                    roomp = 160;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 2 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 1 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 2)//CP Single 3
                {
                    roomp = 160;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 3 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 1 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 3)//CP Single 4
                {
                    roomp = 160;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 4 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 1 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 4)//CP Single 5
                {
                    roomp = 160;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 5 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 1 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 5)//CP Single 6
                {
                    roomp = 160;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 6 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 1 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 6)//CP Single 7
                {
                    roomp = 160;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 7 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 1 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 7)//CP Single 8
                {
                    roomp = 160;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 8 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 1 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 8)//CP Single 9
                {
                    roomp = 160;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 9 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 1 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 9)//CP Single 10
                {
                    roomp = 160;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 10 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 1 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 0)//CP Double 1
                {
                    roomp = 288;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 1 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 1 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 1)//CP Double 2
                {
                    roomp = 288;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 2 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 1 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 2)//CP Double 3
                {
                    roomp = 288;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 3 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 1 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 3)//CP Double 4
                {
                    roomp = 288;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 4 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 1 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 4)//CP Double 5
                {
                    roomp = 288;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 5 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 1 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 5)//CP Double 6
                {
                    roomp = 288;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 6 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 1 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 6)//CP Double 7
                {
                    roomp = 288;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 7 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 1 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 7)//CP Double 8
                {
                    roomp = 288;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 8 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 1 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 8)//CP Double 9
                {
                    roomp = 288;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 9 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 1 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 9)//CP Double 10
                {
                    roomp = 288;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 10 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 1 && hotelresroomtypecomboBox.SelectedIndex == 2)//CP Family Suite (Not available)
                {
                    hotelrespricetextBox.Text = "Unavailable.";
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 0)// LB Single 1
                {
                    roomp = 160;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 1 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 1)// LB Single 2
                {
                    roomp = 160;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 2 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 2)// LB Single 3
                {
                    roomp = 160;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 3 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 3)// LB Single 4
                {
                    roomp = 160;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 4 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 4)// LB Single 5
                {
                    roomp = 160;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 5 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 5)// LB Single 6
                {
                    roomp = 160;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 6 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 6)// LB Single 7
                {
                    roomp = 160;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 7 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 7)// LB Single 8
                {
                    roomp = 160;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 8 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 8)// LB Single 9
                {
                    roomp = 160;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 9 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 9)// LB Single 10
                {
                    roomp = 160;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 10 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 0)// LB Double 1
                {
                    roomp = 304;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 1 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 1)// LB Double 2
                {
                    roomp = 304;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 2 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 2)// LB Double 3
                {
                    roomp = 304;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 3 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 3)// LB Double 4
                {
                    roomp = 304;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 4 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 4)// LB Double 5
                {
                    roomp = 304;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 5 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 5)// LB Double 6
                {
                    roomp = 304;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 6 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 6)// LB Double 7
                {
                    roomp = 304;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 7 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 7)// LB Double 8
                {
                    roomp = 304;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 8 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 8)// LB Double 9
                {
                    roomp = 304;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 9 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 9)// LB Double 10
                {
                    roomp = 304;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 10 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 0)// LB Family Suite 1
                {
                    roomp = 480;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 1 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 1)// LB Family Suite 2
                {
                    roomp = 480;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 2 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 2)// LB Family Suite 3
                {
                    roomp = 480;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 3 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 3)// LB Family Suite 4
                {
                    roomp = 480;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 4 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 4)// LB Family Suite 5
                {
                    roomp = 480;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 5 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 5)// LB Family Suite 6
                {
                    roomp = 480;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 6 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 6)// LB Family Suite 7
                {
                    roomp = 480;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 7 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 7)// LB Family Suite 8
                {
                    roomp = 480;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 8 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 8)// LB Family Suite 9
                {
                    roomp = 480;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 9 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 9)// LB Family Suite 10
                {
                    roomp = 480;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 10 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 0)// LA Single 1
                {
                    roomp = 144;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 1 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 1)// LA Single 2
                {
                    roomp = 144;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 2 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 2)// LA Single 3
                {
                    roomp = 144;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 3 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 3)// LA Single 4
                {
                    roomp = 144;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 4 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 4)// LA Single 5
                {
                    roomp = 144;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 5 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 5)// LA Single 6
                {
                    roomp = 144;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 6 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 6)// LA Single 7
                {
                    roomp = 144;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 7 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 7)// LA Single 8
                {
                    roomp = 144;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 8 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 8)// LA Single 9
                {
                    roomp = 144;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 9 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 9)// LA Single 10
                {
                    roomp = 144;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 10 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 0)// LA Double 1
                {
                    roomp = 192;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 1 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 1)// LA Double 2
                {
                    roomp = 192;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 2 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 2)// LA Double 3
                {
                    roomp = 192;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 3 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 3)// LA Double 4
                {
                    roomp = 192;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 4 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 4)// LA Double 5
                {
                    roomp = 192;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 5 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 5)// LA Double 6
                {
                    roomp = 192;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 6 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 6)// LA Double 7
                {
                    roomp = 192;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 7 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 7)// LA Double 8
                {
                    roomp = 192;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 8 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 8)// LA Double 9
                {
                    roomp = 192;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 9 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 9)// LA Double 10
                {
                    roomp = 192;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 10 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 0)// LA Family Suite 1
                {
                    roomp = 320;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 1 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 1)// LA Family Suite 2
                {
                    roomp = 320;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 2 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 2)// LA Family Suite 3
                {
                    roomp = 320;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 3 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 3)// LA Family Suite 4
                {
                    roomp = 320;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 4 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 4)// LA Family Suite 5
                {
                    roomp = 320;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 5 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 5)// LA Family Suite 6
                {
                    roomp = 320;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 6 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 6)// LA Family Suite 7
                {
                    roomp = 320;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 7 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 7)// LA Family Suite 8
                {
                    roomp = 320;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 8 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 8)// LA Family Suite 9
                {
                    roomp = 320;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 9 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 9)// LA Family Suite 10
                {
                    roomp = 320;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 10 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 0)// TT Single 1
                {
                    roomp = 176;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 1 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 1)// TT Single 2
                {
                    roomp = 176;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 2 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 2)// TT Single 3
                {
                    roomp = 176;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 3 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 3)// TT Single 4
                {
                    roomp = 176;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 4 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 4)// TT Single 5
                {
                    roomp = 176;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 5 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 5)// TT Single 6
                {
                    roomp = 176;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 6 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 6)// TT Single 7
                {
                    roomp = 176;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 7 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 7)// TT Single 8
                {
                    roomp = 176;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 8 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 8)// TT Single 9
                {
                    roomp = 176;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 9 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 9)// TT Single 10
                {
                    roomp = 176;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 10 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 0)// TT Double 1
                {
                    roomp = 280;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 1 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 1)// TT Double 2
                {
                    roomp = 280;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 2 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 2)// TT Double 3
                {
                    roomp = 280;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 3 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 3)// TT Double 4
                {
                    roomp = 280;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 4 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 4)// TT Double 5
                {
                    roomp = 280;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 5 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 5)// TT Double 6
                {
                    roomp = 280;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 6 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 6)// TT Double 7
                {
                    roomp = 280;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 7 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 7)// TT Double 8
                {
                    roomp = 280;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 8 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 8)// TT Double 9
                {
                    roomp = 280;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 9 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 9)// TT Double 10
                {
                    roomp = 280;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 10 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 0)// TT Family Suite 1
                {
                    roomp = 384;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 1 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 1)// TT Family Suite 2
                {
                    roomp = 384;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 2 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 2)// TT Family Suite 3
                {
                    roomp = 384;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 3 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 3)// TT Family Suite 4
                {
                    roomp = 384;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 4 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 4)// TT Family Suite 5
                {
                    roomp = 384;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 5 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 5)// TT Family Suite 6
                {
                    roomp = 384;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 6 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 6)// TT Family Suite 7
                {
                    roomp = 384;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 7 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 7)// TT Family Suite 8
                {
                    roomp = 384;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 8 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 8)// TT Family Suite 9
                {
                    roomp = 384;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 9 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 9)// TT Family Suite 10
                {
                    roomp = 384;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 10 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 0)// TB Single 1
                {
                    roomp = 200;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 1 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 1)// TB Single 2
                {
                    roomp = 200;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 2 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 2)// TB Single 3
                {
                    roomp = 200;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 3 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 3)// TB Single 4
                {
                    roomp = 200;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 4 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 4)// TB Single 5
                {
                    roomp = 200;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 5 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 5)// TB Single 6
                {
                    roomp = 200;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 6 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 6)// TB Single 7
                {
                    roomp = 200;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 7 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 7)// TB Single 8
                {
                    roomp = 200;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 8 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 8)// TB Single 9
                {
                    roomp = 200;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 9 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 9)// TB Single 10
                {
                    roomp = 200;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 10 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 0)// TB Double 1
                {
                    roomp = 304;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 1 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 1)// TB Double 2
                {
                    roomp = 304;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 2 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 2)// TB Double 3
                {
                    roomp = 304;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 3 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 3)// TB Double 4
                {
                    roomp = 304;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 4 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 4)// TB Double 5
                {
                    roomp = 304;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 5 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 5)// TB Double 6
                {
                    roomp = 304;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 5 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 6)// TB Double 7
                {
                    roomp = 304;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 6 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 7)// TB Double 8
                {
                    roomp = 304;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 8 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 8)// TB Double 9
                {
                    roomp = 304;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 9 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 9)// TB Double 10
                {
                    roomp = 304;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 10 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 0)// TB Family Suite 1
                {
                    roomp = 410;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 1 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 1)// TB Family Suite 2
                {
                    roomp = 410;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 2 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 2)// TB Family Suite 3
                {
                    roomp = 410;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 3 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 3)// TB Family Suite 4
                {
                    roomp = 410;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 4 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 4)// TB Family Suite 5
                {
                    roomp = 410;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 5 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 5)// TB Family Suite 6
                {
                    roomp = 410;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 6 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 6)// TB Family Suite 7
                {
                    roomp = 410;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 7 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 7)// TB Family Suite 8
                {
                    roomp = 410;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 8 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 8)// TB Family Suite 9
                {
                    roomp = 410;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 9 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 9)// TB Family Suite 10
                {
                    roomp = 410;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 10 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
            }
        }

        private void hotelresroomtypecomboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            DateTime startreserveddatehotelres = DateTime.Parse(hotelresstartdateTimePicker.Text);
            DateTime endreserveddatehotelres = DateTime.Parse(hotelresenddateTimePicker.Text);
            dayr = (endreserveddatehotelres - startreserveddatehotelres).TotalDays;
            if (startreserveddatehotelres < endreserveddatehotelres)//prevent price calculation and display when startdate and end date are equal.
            {
                if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 0)//CHR Single 1
                {
                    roomp = 144;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 1 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 1)//CHR Single 2
                {
                    roomp = 144;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 2 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 2)//CHR Single 3
                {
                    roomp = 144;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 3 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 3)//CHR Single 4
                {
                    roomp = 144;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 4 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 4)//CHR Single 5
                {
                    roomp = 144;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 5 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 5)//CHR Single 6
                {
                    roomp = 144;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 6 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 6)//CHR Single 7
                {
                    roomp = 144;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 7 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 7)//CHR Single 8
                {
                    roomp = 144;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 8 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 8)//CHR Single 9
                {
                    roomp = 144;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 9 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 9)//CHR Single 10
                {
                    roomp = 144;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 10 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 0)//CHR Double 1
                {
                    roomp = 280;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 1 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 1)//CHR Double 2
                {
                    roomp = 280;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 2 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 2)//CHR Double 3
                {
                    roomp = 280;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 3 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 3)//CHR Double 4
                {
                    roomp = 280;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 4 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 4)//CHR Double 5
                {
                    roomp = 280;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 5 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 5)//CHR Double 6
                {
                    roomp = 280;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 6 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 6)//CHR Double 7
                {
                    roomp = 280;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 7 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 7)//CHR Double 8
                {
                    roomp = 280;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 8 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 8)//CHR Double 9
                {
                    roomp = 280;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 9 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 9)//CHR Double 10
                {
                    roomp = 280;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 10 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 0)//CHR Family Suite 1
                {
                    roomp = 400;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 1 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 1)//CHR Family Suite 2
                {
                    roomp = 400;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 2 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 2)//CHR Family Suite 3
                {
                    roomp = 400;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 3 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 3)//CHR Family Suite 4
                {
                    roomp = 400;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 4 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 4)//CHR Family Suite 5
                {
                    roomp = 400;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 5 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 5)//CHR Family Suite 6
                {
                    roomp = 400;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 6 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 6)//CHR Family Suite 7
                {
                    roomp = 400;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 7 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 7)//CHR Family Suite 8
                {
                    roomp = 400;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 8 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 8)//CHR Family Suite 9
                {
                    roomp = 400;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 9 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 9)//CHR Family Suite 10
                {
                    roomp = 400;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 10 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 1 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 0)//CP Single 1
                {
                    roomp = 160;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 1 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 1 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 1)//CP Single 2
                {
                    roomp = 160;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 2 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 1 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 2)//CP Single 3
                {
                    roomp = 160;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 3 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 1 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 3)//CP Single 4
                {
                    roomp = 160;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 4 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 1 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 4)//CP Single 5
                {
                    roomp = 160;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 5 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 1 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 5)//CP Single 6
                {
                    roomp = 160;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 6 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 1 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 6)//CP Single 7
                {
                    roomp = 160;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 7 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 1 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 7)//CP Single 8
                {
                    roomp = 160;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 8 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 1 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 8)//CP Single 9
                {
                    roomp = 160;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 9 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 1 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 9)//CP Single 10
                {
                    roomp = 160;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 10 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 1 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 0)//CP Double 1
                {
                    roomp = 288;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 1 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 1 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 1)//CP Double 2
                {
                    roomp = 288;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 2 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 1 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 2)//CP Double 3
                {
                    roomp = 288;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 3 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 1 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 3)//CP Double 4
                {
                    roomp = 288;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 4 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 1 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 4)//CP Double 5
                {
                    roomp = 288;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 5 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 1 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 5)//CP Double 6
                {
                    roomp = 288;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 6 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 1 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 6)//CP Double 7
                {
                    roomp = 288;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 7 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 1 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 7)//CP Double 8
                {
                    roomp = 288;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 8 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 1 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 8)//CP Double 9
                {
                    roomp = 288;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 9 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 1 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 9)//CP Double 10
                {
                    roomp = 288;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 10 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 1 && hotelresroomtypecomboBox.SelectedIndex == 2)//CP Family Suite (Not available)
                {
                    hotelrespricetextBox.Text = "Unavailable.";
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 0)// LB Single 1
                {
                    roomp = 160;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 1 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 1)// LB Single 2
                {
                    roomp = 160;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 2 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 2)// LB Single 3
                {
                    roomp = 160;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 3 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 3)// LB Single 4
                {
                    roomp = 160;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 4 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 4)// LB Single 5
                {
                    roomp = 160;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 5 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 5)// LB Single 6
                {
                    roomp = 160;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 6 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 6)// LB Single 7
                {
                    roomp = 160;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 7 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 7)// LB Single 8
                {
                    roomp = 160;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 8 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 8)// LB Single 9
                {
                    roomp = 160;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 9 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 9)// LB Single 10
                {
                    roomp = 160;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 10 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 0)// LB Double 1
                {
                    roomp = 304;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 1 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 1)// LB Double 2
                {
                    roomp = 304;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 2 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 2)// LB Double 3
                {
                    roomp = 304;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 3 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 3)// LB Double 4
                {
                    roomp = 304;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 4 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 4)// LB Double 5
                {
                    roomp = 304;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 5 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 5)// LB Double 6
                {
                    roomp = 304;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 6 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 6)// LB Double 7
                {
                    roomp = 304;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 7 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 7)// LB Double 8
                {
                    roomp = 304;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 8 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 8)// LB Double 9
                {
                    roomp = 304;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 9 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 9)// LB Double 10
                {
                    roomp = 304;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 10 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 0)// LB Family Suite 1
                {
                    roomp = 480;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 1 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 1)// LB Family Suite 2
                {
                    roomp = 480;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 2 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 2)// LB Family Suite 3
                {
                    roomp = 480;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 3 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 3)// LB Family Suite 4
                {
                    roomp = 480;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 4 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 4)// LB Family Suite 5
                {
                    roomp = 480;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 5 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 5)// LB Family Suite 6
                {
                    roomp = 480;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 6 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 6)// LB Family Suite 7
                {
                    roomp = 480;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 7 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 7)// LB Family Suite 8
                {
                    roomp = 480;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 8 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 8)// LB Family Suite 9
                {
                    roomp = 480;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 9 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 9)// LB Family Suite 10
                {
                    roomp = 480;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 10 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 0)// LA Single 1
                {
                    roomp = 144;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 1 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 1)// LA Single 2
                {
                    roomp = 144;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 2 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 2)// LA Single 3
                {
                    roomp = 144;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 3 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 3)// LA Single 4
                {
                    roomp = 144;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 4 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 4)// LA Single 5
                {
                    roomp = 144;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 5 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 5)// LA Single 6
                {
                    roomp = 144;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 6 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 6)// LA Single 7
                {
                    roomp = 144;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 7 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 7)// LA Single 8
                {
                    roomp = 144;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 8 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 8)// LA Single 9
                {
                    roomp = 144;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 9 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 9)// LA Single 10
                {
                    roomp = 144;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 10 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 0)// LA Double 1
                {
                    roomp = 192;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 1 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 1)// LA Double 2
                {
                    roomp = 192;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 2 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 2)// LA Double 3
                {
                    roomp = 192;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 3 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 3)// LA Double 4
                {
                    roomp = 192;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 4 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 4)// LA Double 5
                {
                    roomp = 192;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 5 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 5)// LA Double 6
                {
                    roomp = 192;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 6 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 6)// LA Double 7
                {
                    roomp = 192;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 7 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 7)// LA Double 8
                {
                    roomp = 192;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 8 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 8)// LA Double 9
                {
                    roomp = 192;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 9 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 9)// LA Double 10
                {
                    roomp = 192;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 10 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 0)// LA Family Suite 1
                {
                    roomp = 320;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 1 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 1)// LA Family Suite 2
                {
                    roomp = 320;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 2 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 2)// LA Family Suite 3
                {
                    roomp = 320;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 3 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 3)// LA Family Suite 4
                {
                    roomp = 320;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 4 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 4)// LA Family Suite 5
                {
                    roomp = 320;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 5 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 5)// LA Family Suite 6
                {
                    roomp = 320;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 6 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 6)// LA Family Suite 7
                {
                    roomp = 320;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 7 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 7)// LA Family Suite 8
                {
                    roomp = 320;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 8 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 8)// LA Family Suite 9
                {
                    roomp = 320;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 9 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 9)// LA Family Suite 10
                {
                    roomp = 320;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 10 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 0)// TT Single 1
                {
                    roomp = 176;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 1 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 1)// TT Single 2
                {
                    roomp = 176;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 2 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 2)// TT Single 3
                {
                    roomp = 176;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 3 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 3)// TT Single 4
                {
                    roomp = 176;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 4 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 4)// TT Single 5
                {
                    roomp = 176;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 5 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 5)// TT Single 6
                {
                    roomp = 176;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 6 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 6)// TT Single 7
                {
                    roomp = 176;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 7 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 7)// TT Single 8
                {
                    roomp = 176;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 8 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 8)// TT Single 9
                {
                    roomp = 176;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 9 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 9)// TT Single 10
                {
                    roomp = 176;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 10 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 0)// TT Double 1
                {
                    roomp = 280;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 1 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 1)// TT Double 2
                {
                    roomp = 280;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 2 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 2)// TT Double 3
                {
                    roomp = 280;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 3 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 3)// TT Double 4
                {
                    roomp = 280;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 4 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 4)// TT Double 5
                {
                    roomp = 280;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 5 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 5)// TT Double 6
                {
                    roomp = 280;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 6 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 6)// TT Double 7
                {
                    roomp = 280;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 7 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 7)// TT Double 8
                {
                    roomp = 280;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 8 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 8)// TT Double 9
                {
                    roomp = 280;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 9 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 9)// TT Double 10
                {
                    roomp = 280;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 10 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 0)// TT Family Suite 1
                {
                    roomp = 384;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 1 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 1)// TT Family Suite 2
                {
                    roomp = 384;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 2 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 2)// TT Family Suite 3
                {
                    roomp = 384;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 3 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 3)// TT Family Suite 4
                {
                    roomp = 384;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 4 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 4)// TT Family Suite 5
                {
                    roomp = 384;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 5 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 5)// TT Family Suite 6
                {
                    roomp = 384;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 6 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 6)// TT Family Suite 7
                {
                    roomp = 384;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 7 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 7)// TT Family Suite 8
                {
                    roomp = 384;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 8 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 8)// TT Family Suite 9
                {
                    roomp = 384;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 9 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 9)// TT Family Suite 10
                {
                    roomp = 384;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 10 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 0)// TB Single 1
                {
                    roomp = 200;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 1 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 1)// TB Single 2
                {
                    roomp = 200;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 2 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 2)// TB Single 3
                {
                    roomp = 200;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 3 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 3)// TB Single 4
                {
                    roomp = 200;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 4 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 4)// TB Single 5
                {
                    roomp = 200;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 5 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 5)// TB Single 6
                {
                    roomp = 200;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 6 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 6)// TB Single 7
                {
                    roomp = 200;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 7 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 7)// TB Single 8
                {
                    roomp = 200;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 8 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 8)// TB Single 9
                {
                    roomp = 200;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 9 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 9)// TB Single 10
                {
                    roomp = 200;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 10 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 0)// TB Double 1
                {
                    roomp = 304;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 1 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 1)// TB Double 2
                {
                    roomp = 304;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 2 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 2)// TB Double 3
                {
                    roomp = 304;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 3 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 3)// TB Double 4
                {
                    roomp = 304;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 4 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 4)// TB Double 5
                {
                    roomp = 304;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 5 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 5)// TB Double 6
                {
                    roomp = 304;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 5 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 6)// TB Double 7
                {
                    roomp = 304;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 6 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 7)// TB Double 8
                {
                    roomp = 304;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 8 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 8)// TB Double 9
                {
                    roomp = 304;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 9 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 9)// TB Double 10
                {
                    roomp = 304;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 10 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 0)// TB Family Suite 1
                {
                    roomp = 410;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 1 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 1)// TB Family Suite 2
                {
                    roomp = 410;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 2 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 2)// TB Family Suite 3
                {
                    roomp = 410;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 3 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 3)// TB Family Suite 4
                {
                    roomp = 410;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 4 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 4)// TB Family Suite 5
                {
                    roomp = 410;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 5 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 5)// TB Family Suite 6
                {
                    roomp = 410;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 6 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 6)// TB Family Suite 7
                {
                    roomp = 410;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 7 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 7)// TB Family Suite 8
                {
                    roomp = 410;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 8 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 8)// TB Family Suite 9
                {
                    roomp = 410;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 9 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
                else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 9)// TB Family Suite 10
                {
                    roomp = 410;
                    hotel h = new hotel(hoteln, roomt, roomp, dayr);
                    totalprice = 10 * h.price(dayr, roomp);
                    hotelrespricetextBox.Text = totalprice.ToString();
                }
            }
            else
            {
                MessageBox.Show("Please ensure the dates are correct.");
            }
        }

        private void amountcomboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 0)//CHR Single 1
            {
                roomp = 144;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 1 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 1)//CHR Single 2
            {
                roomp = 144;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 2 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 2)//CHR Single 3
            {
                roomp = 144;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 3 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 3)//CHR Single 4
            {
                roomp = 144;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 4 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 4)//CHR Single 5
            {
                roomp = 144;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 5 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 5)//CHR Single 6
            {
                roomp = 144;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 6 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 6)//CHR Single 7
            {
                roomp = 144;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 7 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 7)//CHR Single 8
            {
                roomp = 144;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 8 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 8)//CHR Single 9
            {
                roomp = 144;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 9 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 9)//CHR Single 10
            {
                roomp = 144;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 10 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 0)//CHR Double 1
            {
                roomp = 280;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 1 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 1)//CHR Double 2
            {
                roomp = 280;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 2 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 2)//CHR Double 3
            {
                roomp = 280;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 3 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 3)//CHR Double 4
            {
                roomp = 280;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 4 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 4)//CHR Double 5
            {
                roomp = 280;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 5 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 5)//CHR Double 6
            {
                roomp = 280;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 6 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 6)//CHR Double 7
            {
                roomp = 280;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 7 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 7)//CHR Double 8
            {
                roomp = 280;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 8 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 8)//CHR Double 9
            {
                roomp = 280;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 9 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 9)//CHR Double 10
            {
                roomp = 280;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 10 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 0)//CHR Family Suite 1
            {
                roomp = 400;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 1 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 1)//CHR Family Suite 2
            {
                roomp = 400;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 2 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 2)//CHR Family Suite 3
            {
                roomp = 400;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 3 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 3)//CHR Family Suite 4
            {
                roomp = 400;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 4 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 4)//CHR Family Suite 5
            {
                roomp = 400;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 5 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 5)//CHR Family Suite 6
            {
                roomp = 400;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 6 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 6)//CHR Family Suite 7
            {
                roomp = 400;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 7 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 7)//CHR Family Suite 8
            {
                roomp = 400;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 8 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 8)//CHR Family Suite 9
            {
                roomp = 400;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 9 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 0 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 9)//CHR Family Suite 10
            {
                roomp = 400;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 10 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 1 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 0)//CP Single 1
            {
                roomp = 160;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 1 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 1 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 1)//CP Single 2
            {
                roomp = 160;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 2 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 1 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 2)//CP Single 3
            {
                roomp = 160;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 3 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 1 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 3)//CP Single 4
            {
                roomp = 160;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 4 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 1 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 4)//CP Single 5
            {
                roomp = 160;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 5 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 1 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 5)//CP Single 6
            {
                roomp = 160;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 6 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 1 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 6)//CP Single 7
            {
                roomp = 160;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 7 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 1 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 7)//CP Single 8
            {
                roomp = 160;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 8 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 1 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 8)//CP Single 9
            {
                roomp = 160;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 9 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 1 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 9)//CP Single 10
            {
                roomp = 160;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 10 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 1 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 0)//CP Double 1
            {
                roomp = 288;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 1 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 1 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 1)//CP Double 2
            {
                roomp = 288;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 2 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 1 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 2)//CP Double 3
            {
                roomp = 288;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 3 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 1 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 3)//CP Double 4
            {
                roomp = 288;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 4 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 1 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 4)//CP Double 5
            {
                roomp = 288;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 5 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 1 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 5)//CP Double 6
            {
                roomp = 288;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 6 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 1 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 6)//CP Double 7
            {
                roomp = 288;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 7 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 1 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 7)//CP Double 8
            {
                roomp = 288;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 8 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 1 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 8)//CP Double 9
            {
                roomp = 288;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 9 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 1 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 9)//CP Double 10
            {
                roomp = 288;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 10 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 1 && hotelresroomtypecomboBox.SelectedIndex == 2)//CP Family Suite (Not available)
            {
                hotelrespricetextBox.Text = "Unavailable.";
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 0)// LB Single 1
            {
                roomp = 160;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 1 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 1)// LB Single 2
            {
                roomp = 160;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 2 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 2)// LB Single 3
            {
                roomp = 160;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 3 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 3)// LB Single 4
            {
                roomp = 160;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 4 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 4)// LB Single 5
            {
                roomp = 160;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 5 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 5)// LB Single 6
            {
                roomp = 160;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 6 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 6)// LB Single 7
            {
                roomp = 160;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 7 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 7)// LB Single 8
            {
                roomp = 160;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 8 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 8)// LB Single 9
            {
                roomp = 160;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 9 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 9)// LB Single 10
            {
                roomp = 160;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 10 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 0)// LB Double 1
            {
                roomp = 304;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 1 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 1)// LB Double 2
            {
                roomp = 304;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 2 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 2)// LB Double 3
            {
                roomp = 304;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 3 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 3)// LB Double 4
            {
                roomp = 304;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 4 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 4)// LB Double 5
            {
                roomp = 304;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 5 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 5)// LB Double 6
            {
                roomp = 304;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 6 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 6)// LB Double 7
            {
                roomp = 304;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 7 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 7)// LB Double 8
            {
                roomp = 304;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 8 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 8)// LB Double 9
            {
                roomp = 304;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 9 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 9)// LB Double 10
            {
                roomp = 304;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 10 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 0)// LB Family Suite 1
            {
                roomp = 480;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 1 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 1)// LB Family Suite 2
            {
                roomp = 480;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 2 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 2)// LB Family Suite 3
            {
                roomp = 480;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 3 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 3)// LB Family Suite 4
            {
                roomp = 480;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 4 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 4)// LB Family Suite 5
            {
                roomp = 480;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 5 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 5)// LB Family Suite 6
            {
                roomp = 480;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 6 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 6)// LB Family Suite 7
            {
                roomp = 480;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 7 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 7)// LB Family Suite 8
            {
                roomp = 480;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 8 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 8)// LB Family Suite 9
            {
                roomp = 480;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 9 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 2 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 9)// LB Family Suite 10
            {
                roomp = 480;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 10 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 0)// LA Single 1
            {
                roomp = 144;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 1 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 1)// LA Single 2
            {
                roomp = 144;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 2 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 2)// LA Single 3
            {
                roomp = 144;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 3 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 3)// LA Single 4
            {
                roomp = 144;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 4 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 4)// LA Single 5
            {
                roomp = 144;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 5 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 5)// LA Single 6
            {
                roomp = 144;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 6 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 6)// LA Single 7
            {
                roomp = 144;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 7 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 7)// LA Single 8
            {
                roomp = 144;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 8 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 8)// LA Single 9
            {
                roomp = 144;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 9 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 9)// LA Single 10
            {
                roomp = 144;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 10 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 0)// LA Double 1
            {
                roomp = 192;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 1 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 1)// LA Double 2
            {
                roomp = 192;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 2 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 2)// LA Double 3
            {
                roomp = 192;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 3 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 3)// LA Double 4
            {
                roomp = 192;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 4 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 4)// LA Double 5
            {
                roomp = 192;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 5 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 5)// LA Double 6
            {
                roomp = 192;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 6 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 6)// LA Double 7
            {
                roomp = 192;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 7 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 7)// LA Double 8
            {
                roomp = 192;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 8 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 8)// LA Double 9
            {
                roomp = 192;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 9 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 9)// LA Double 10
            {
                roomp = 192;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 10 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 0)// LA Family Suite 1
            {
                roomp = 320;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 1 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 1)// LA Family Suite 2
            {
                roomp = 320;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 2 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 2)// LA Family Suite 3
            {
                roomp = 320;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 3 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 3)// LA Family Suite 4
            {
                roomp = 320;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 4 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 4)// LA Family Suite 5
            {
                roomp = 320;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 5 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 5)// LA Family Suite 6
            {
                roomp = 320;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 6 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 6)// LA Family Suite 7
            {
                roomp = 320;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 7 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 7)// LA Family Suite 8
            {
                roomp = 320;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 8 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 8)// LA Family Suite 9
            {
                roomp = 320;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 9 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 3 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 9)// LA Family Suite 10
            {
                roomp = 320;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 10 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 0)// TT Single 1
            {
                roomp = 176;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 1 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 1)// TT Single 2
            {
                roomp = 176;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 2 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 2)// TT Single 3
            {
                roomp = 176;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 3 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 3)// TT Single 4
            {
                roomp = 176;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 4 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 4)// TT Single 5
            {
                roomp = 176;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 5 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 5)// TT Single 6
            {
                roomp = 176;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 6 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 6)// TT Single 7
            {
                roomp = 176;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 7 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 7)// TT Single 8
            {
                roomp = 176;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 8 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 8)// TT Single 9
            {
                roomp = 176;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 9 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 9)// TT Single 10
            {
                roomp = 176;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 10 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 0)// TT Double 1
            {
                roomp = 280;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 1 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 1)// TT Double 2
            {
                roomp = 280;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 2 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 2)// TT Double 3
            {
                roomp = 280;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 3 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 3)// TT Double 4
            {
                roomp = 280;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 4 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 4)// TT Double 5
            {
                roomp = 280;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 5 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 5)// TT Double 6
            {
                roomp = 280;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 6 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 6)// TT Double 7
            {
                roomp = 280;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 7 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 7)// TT Double 8
            {
                roomp = 280;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 8 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 8)// TT Double 9
            {
                roomp = 280;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 9 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 9)// TT Double 10
            {
                roomp = 280;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 10 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 0)// TT Family Suite 1
            {
                roomp = 384;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 1 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 1)// TT Family Suite 2
            {
                roomp = 384;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 2 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 2)// TT Family Suite 3
            {
                roomp = 384;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 3 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 3)// TT Family Suite 4
            {
                roomp = 384;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 4 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 4)// TT Family Suite 5
            {
                roomp = 384;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 5 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 5)// TT Family Suite 6
            {
                roomp = 384;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 6 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 6)// TT Family Suite 7
            {
                roomp = 384;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 7 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 7)// TT Family Suite 8
            {
                roomp = 384;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 8 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 8)// TT Family Suite 9
            {
                roomp = 384;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 9 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 4 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 9)// TT Family Suite 10
            {
                roomp = 384;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 10 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 0)// TB Single 1
            {
                roomp = 200;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 1 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 1)// TB Single 2
            {
                roomp = 200;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 2 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 2)// TB Single 3
            {
                roomp = 200;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 3 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 3)// TB Single 4
            {
                roomp = 200;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 4 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 4)// TB Single 5
            {
                roomp = 200;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 5 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 5)// TB Single 6
            {
                roomp = 200;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 6 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 6)// TB Single 7
            {
                roomp = 200;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 7 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 7)// TB Single 8
            {
                roomp = 200;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 8 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 8)// TB Single 9
            {
                roomp = 200;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 9 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 0 && amountcomboBox.SelectedIndex == 9)// TB Single 10
            {
                roomp = 200;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 10 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 0)// TB Double 1
            {
                roomp = 304;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 1 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 1)// TB Double 2
            {
                roomp = 304;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 2 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 2)// TB Double 3
            {
                roomp = 304;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 3 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 3)// TB Double 4
            {
                roomp = 304;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 4 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 4)// TB Double 5
            {
                roomp = 304;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 5 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 5)// TB Double 6
            {
                roomp = 304;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 5 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 6)// TB Double 7
            {
                roomp = 304;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 6 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 7)// TB Double 8
            {
                roomp = 304;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 8 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 8)// TB Double 9
            {
                roomp = 304;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 9 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 1 && amountcomboBox.SelectedIndex == 9)// TB Double 10
            {
                roomp = 304;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 10 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 0)// TB Family Suite 1
            {
                roomp = 410;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 1 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 1)// TB Family Suite 2
            {
                roomp = 410;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 2 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 2)// TB Family Suite 3
            {
                roomp = 410;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 3 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 3)// TB Family Suite 4
            {
                roomp = 410;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 4 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 4)// TB Family Suite 5
            {
                roomp = 410;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 5 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 5)// TB Family Suite 6
            {
                roomp = 410;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 6 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 6)// TB Family Suite 7
            {
                roomp = 410;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 7 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 7)// TB Family Suite 8
            {
                roomp = 410;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 8 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 8)// TB Family Suite 9
            {
                roomp = 410;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 9 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
            else if (hotelreshotelnamecomboBox.SelectedIndex == 5 && hotelresroomtypecomboBox.SelectedIndex == 2 && amountcomboBox.SelectedIndex == 9)// TB Family Suite 10
            {
                roomp = 410;
                hotel h = new hotel(hoteln, roomt, roomp, dayr);
                totalprice = 10 * h.price(dayr, roomp);
                hotelrespricetextBox.Text = totalprice.ToString();
            }
        }

        private void updatebutton_Click(object sender, EventArgs e)
        {

        }
    }
}
    

