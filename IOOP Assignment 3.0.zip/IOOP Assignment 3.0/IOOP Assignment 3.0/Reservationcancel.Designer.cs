﻿namespace IOOP_Assignment_3._0
{
    partial class Reservationcancel
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rescancmainmenubutton = new System.Windows.Forms.Button();
            this.searchholidayreservation = new System.Windows.Forms.Button();
            this.rescancresultlistbox = new System.Windows.Forms.ListBox();
            this.confirmresmodbutton = new System.Windows.Forms.Button();
            this.searchhotelresbutton = new System.Windows.Forms.Button();
            this.resmodresultlabel = new System.Windows.Forms.Label();
            this.resmodsearchcusidlabel = new System.Windows.Forms.Label();
            this.searchcusidtextBox = new System.Windows.Forms.TextBox();
            this.searchresidtextBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.searchtourresbutton = new System.Windows.Forms.Button();
            this.hotelradioButton = new System.Windows.Forms.RadioButton();
            this.tourradioButton = new System.Windows.Forms.RadioButton();
            this.holidayradioButton = new System.Windows.Forms.RadioButton();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.viewchangehotelradioButton = new System.Windows.Forms.RadioButton();
            this.viewchangetourradioButton = new System.Windows.Forms.RadioButton();
            this.viewchangeholidayradioButton = new System.Windows.Forms.RadioButton();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // rescancmainmenubutton
            // 
            this.rescancmainmenubutton.Location = new System.Drawing.Point(463, 402);
            this.rescancmainmenubutton.Name = "rescancmainmenubutton";
            this.rescancmainmenubutton.Size = new System.Drawing.Size(122, 23);
            this.rescancmainmenubutton.TabIndex = 2;
            this.rescancmainmenubutton.Text = "Back to main menu";
            this.rescancmainmenubutton.UseVisualStyleBackColor = true;
            this.rescancmainmenubutton.Click += new System.EventHandler(this.rescancmainmenubutton_Click);
            // 
            // searchholidayreservation
            // 
            this.searchholidayreservation.Location = new System.Drawing.Point(285, 132);
            this.searchholidayreservation.Name = "searchholidayreservation";
            this.searchholidayreservation.Size = new System.Drawing.Size(122, 36);
            this.searchholidayreservation.TabIndex = 19;
            this.searchholidayreservation.Text = "Search Holiday Reservation";
            this.searchholidayreservation.UseVisualStyleBackColor = true;
            this.searchholidayreservation.Click += new System.EventHandler(this.searchholidayreservation_Click_1);
            // 
            // rescancresultlistbox
            // 
            this.rescancresultlistbox.FormattingEnabled = true;
            this.rescancresultlistbox.Location = new System.Drawing.Point(13, 188);
            this.rescancresultlistbox.Name = "rescancresultlistbox";
            this.rescancresultlistbox.Size = new System.Drawing.Size(562, 134);
            this.rescancresultlistbox.TabIndex = 17;
            // 
            // confirmresmodbutton
            // 
            this.confirmresmodbutton.Location = new System.Drawing.Point(49, 68);
            this.confirmresmodbutton.Name = "confirmresmodbutton";
            this.confirmresmodbutton.Size = new System.Drawing.Size(120, 23);
            this.confirmresmodbutton.TabIndex = 16;
            this.confirmresmodbutton.Text = "Confirm Cancellation";
            this.confirmresmodbutton.UseVisualStyleBackColor = true;
            this.confirmresmodbutton.Click += new System.EventHandler(this.confirmresmodbutton_Click);
            // 
            // searchhotelresbutton
            // 
            this.searchhotelresbutton.Location = new System.Drawing.Point(13, 132);
            this.searchhotelresbutton.Name = "searchhotelresbutton";
            this.searchhotelresbutton.Size = new System.Drawing.Size(120, 36);
            this.searchhotelresbutton.TabIndex = 15;
            this.searchhotelresbutton.Text = "Search Hotel Reservation";
            this.searchhotelresbutton.UseVisualStyleBackColor = true;
            this.searchhotelresbutton.Click += new System.EventHandler(this.searchhotelresbutton_Click);
            // 
            // resmodresultlabel
            // 
            this.resmodresultlabel.AutoSize = true;
            this.resmodresultlabel.Location = new System.Drawing.Point(10, 173);
            this.resmodresultlabel.Name = "resmodresultlabel";
            this.resmodresultlabel.Size = new System.Drawing.Size(40, 13);
            this.resmodresultlabel.TabIndex = 14;
            this.resmodresultlabel.Text = "Result:";
            // 
            // resmodsearchcusidlabel
            // 
            this.resmodsearchcusidlabel.AutoSize = true;
            this.resmodsearchcusidlabel.Location = new System.Drawing.Point(10, 69);
            this.resmodsearchcusidlabel.Name = "resmodsearchcusidlabel";
            this.resmodsearchcusidlabel.Size = new System.Drawing.Size(204, 13);
            this.resmodsearchcusidlabel.TabIndex = 13;
            this.resmodsearchcusidlabel.Text = "Search for customer IC/ Passport Number";
            // 
            // searchcusidtextBox
            // 
            this.searchcusidtextBox.Location = new System.Drawing.Point(13, 97);
            this.searchcusidtextBox.Name = "searchcusidtextBox";
            this.searchcusidtextBox.Size = new System.Drawing.Size(562, 20);
            this.searchcusidtextBox.TabIndex = 12;
            // 
            // searchresidtextBox
            // 
            this.searchresidtextBox.Location = new System.Drawing.Point(13, 37);
            this.searchresidtextBox.Name = "searchresidtextBox";
            this.searchresidtextBox.Size = new System.Drawing.Size(562, 20);
            this.searchresidtextBox.TabIndex = 12;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(10, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(130, 13);
            this.label1.TabIndex = 13;
            this.label1.Text = "Search for Reservation ID";
            // 
            // searchtourresbutton
            // 
            this.searchtourresbutton.Location = new System.Drawing.Point(150, 132);
            this.searchtourresbutton.Name = "searchtourresbutton";
            this.searchtourresbutton.Size = new System.Drawing.Size(113, 36);
            this.searchtourresbutton.TabIndex = 18;
            this.searchtourresbutton.Text = "Search Tour Reservation";
            this.searchtourresbutton.UseVisualStyleBackColor = true;
            this.searchtourresbutton.Click += new System.EventHandler(this.searchtourresbutton_Click);
            // 
            // hotelradioButton
            // 
            this.hotelradioButton.AutoSize = true;
            this.hotelradioButton.Location = new System.Drawing.Point(13, 35);
            this.hotelradioButton.Name = "hotelradioButton";
            this.hotelradioButton.Size = new System.Drawing.Size(50, 17);
            this.hotelradioButton.TabIndex = 20;
            this.hotelradioButton.TabStop = true;
            this.hotelradioButton.Text = "Hotel";
            this.hotelradioButton.UseVisualStyleBackColor = true;
            // 
            // tourradioButton
            // 
            this.tourradioButton.AutoSize = true;
            this.tourradioButton.Location = new System.Drawing.Point(69, 35);
            this.tourradioButton.Name = "tourradioButton";
            this.tourradioButton.Size = new System.Drawing.Size(47, 17);
            this.tourradioButton.TabIndex = 20;
            this.tourradioButton.TabStop = true;
            this.tourradioButton.Text = "Tour";
            this.tourradioButton.UseVisualStyleBackColor = true;
            // 
            // holidayradioButton
            // 
            this.holidayradioButton.AutoSize = true;
            this.holidayradioButton.Location = new System.Drawing.Point(122, 35);
            this.holidayradioButton.Name = "holidayradioButton";
            this.holidayradioButton.Size = new System.Drawing.Size(60, 17);
            this.holidayradioButton.TabIndex = 20;
            this.holidayradioButton.TabStop = true;
            this.holidayradioButton.Text = "Holiday";
            this.holidayradioButton.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.holidayradioButton);
            this.groupBox1.Controls.Add(this.confirmresmodbutton);
            this.groupBox1.Controls.Add(this.tourradioButton);
            this.groupBox1.Controls.Add(this.hotelradioButton);
            this.groupBox1.Location = new System.Drawing.Point(12, 328);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(217, 105);
            this.groupBox1.TabIndex = 21;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Select type:";
            // 
            // viewchangehotelradioButton
            // 
            this.viewchangehotelradioButton.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.viewchangehotelradioButton.AutoSize = true;
            this.viewchangehotelradioButton.Location = new System.Drawing.Point(257, 363);
            this.viewchangehotelradioButton.Name = "viewchangehotelradioButton";
            this.viewchangehotelradioButton.Size = new System.Drawing.Size(50, 17);
            this.viewchangehotelradioButton.TabIndex = 22;
            this.viewchangehotelradioButton.TabStop = true;
            this.viewchangehotelradioButton.Text = "Hotel";
            this.viewchangehotelradioButton.UseVisualStyleBackColor = true;
            this.viewchangehotelradioButton.CheckedChanged += new System.EventHandler(this.viewchangehotelradioButton_CheckedChanged);
            // 
            // viewchangetourradioButton
            // 
            this.viewchangetourradioButton.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.viewchangetourradioButton.AutoSize = true;
            this.viewchangetourradioButton.Location = new System.Drawing.Point(257, 386);
            this.viewchangetourradioButton.Name = "viewchangetourradioButton";
            this.viewchangetourradioButton.Size = new System.Drawing.Size(47, 17);
            this.viewchangetourradioButton.TabIndex = 22;
            this.viewchangetourradioButton.TabStop = true;
            this.viewchangetourradioButton.Text = "Tour";
            this.viewchangetourradioButton.UseVisualStyleBackColor = true;
            this.viewchangetourradioButton.CheckedChanged += new System.EventHandler(this.viewchangetourradioButton_CheckedChanged);
            // 
            // viewchangeholidayradioButton
            // 
            this.viewchangeholidayradioButton.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.viewchangeholidayradioButton.AutoSize = true;
            this.viewchangeholidayradioButton.Location = new System.Drawing.Point(257, 408);
            this.viewchangeholidayradioButton.Name = "viewchangeholidayradioButton";
            this.viewchangeholidayradioButton.Size = new System.Drawing.Size(60, 17);
            this.viewchangeholidayradioButton.TabIndex = 22;
            this.viewchangeholidayradioButton.TabStop = true;
            this.viewchangeholidayradioButton.Text = "Holiday";
            this.viewchangeholidayradioButton.UseVisualStyleBackColor = true;
            this.viewchangeholidayradioButton.CheckedChanged += new System.EventHandler(this.viewchangeholidayradioButton_CheckedChanged);
            // 
            // groupBox2
            // 
            this.groupBox2.Location = new System.Drawing.Point(235, 328);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(159, 105);
            this.groupBox2.TabIndex = 24;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "View Tables";
            // 
            // Reservationcancel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(616, 437);
            this.Controls.Add(this.viewchangeholidayradioButton);
            this.Controls.Add(this.viewchangetourradioButton);
            this.Controls.Add(this.viewchangehotelradioButton);
            this.Controls.Add(this.searchholidayreservation);
            this.Controls.Add(this.searchtourresbutton);
            this.Controls.Add(this.rescancresultlistbox);
            this.Controls.Add(this.searchhotelresbutton);
            this.Controls.Add(this.resmodresultlabel);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.searchresidtextBox);
            this.Controls.Add(this.resmodsearchcusidlabel);
            this.Controls.Add(this.searchcusidtextBox);
            this.Controls.Add(this.rescancmainmenubutton);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.groupBox2);
            this.Name = "Reservationcancel";
            this.Text = "Reservation Cancellation";
            this.Load += new System.EventHandler(this.Reservationcancel_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button rescancmainmenubutton;
        private System.Windows.Forms.Button searchholidayreservation;
        private System.Windows.Forms.ListBox rescancresultlistbox;
        private System.Windows.Forms.Button confirmresmodbutton;
        private System.Windows.Forms.Button searchhotelresbutton;
        private System.Windows.Forms.Label resmodresultlabel;
        private System.Windows.Forms.Label resmodsearchcusidlabel;
        private System.Windows.Forms.TextBox searchcusidtextBox;
        private System.Windows.Forms.TextBox searchresidtextBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button searchtourresbutton;
        private System.Windows.Forms.RadioButton hotelradioButton;
        private System.Windows.Forms.RadioButton tourradioButton;
        private System.Windows.Forms.RadioButton holidayradioButton;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton viewchangehotelradioButton;
        private System.Windows.Forms.RadioButton viewchangetourradioButton;
        private System.Windows.Forms.RadioButton viewchangeholidayradioButton;
        private System.Windows.Forms.GroupBox groupBox2;
    }
}