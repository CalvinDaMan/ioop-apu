﻿namespace IOOP_Assignment_3._0
{
    partial class CusInfo_holir
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.backtoresbutton_hotelr = new System.Windows.Forms.Button();
            this.mainmenubutton_hotelr = new System.Windows.Forms.Button();
            this.cuscontacttextBox_holidayr = new System.Windows.Forms.TextBox();
            this.emailtextBox_holidayr = new System.Windows.Forms.TextBox();
            this.cusaddresstextBox_holidayr = new System.Windows.Forms.TextBox();
            this.cusnametextBox_holidayr = new System.Windows.Forms.TextBox();
            this.cusidtextBox_holidayr = new System.Windows.Forms.TextBox();
            this.confirmbutton_hotelr = new System.Windows.Forms.Button();
            this.dateofbookinglabel_holidayr = new System.Windows.Forms.Label();
            this.cuscontactlabel_holidayr = new System.Windows.Forms.Label();
            this.emaillabel_holidayr = new System.Windows.Forms.Label();
            this.addresslabel_holidayr = new System.Windows.Forms.Label();
            this.cusnamelabel_holidayr = new System.Windows.Forms.Label();
            this.cusidlabel_holidayr = new System.Windows.Forms.Label();
            this.cusinfolabel_holidayr = new System.Windows.Forms.Label();
            this.cusinfoholresdateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.SuspendLayout();
            // 
            // backtoresbutton_hotelr
            // 
            this.backtoresbutton_hotelr.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.backtoresbutton_hotelr.Location = new System.Drawing.Point(215, 289);
            this.backtoresbutton_hotelr.Name = "backtoresbutton_hotelr";
            this.backtoresbutton_hotelr.Size = new System.Drawing.Size(75, 35);
            this.backtoresbutton_hotelr.TabIndex = 31;
            this.backtoresbutton_hotelr.Text = "Back to Reservation";
            this.backtoresbutton_hotelr.UseVisualStyleBackColor = true;
            this.backtoresbutton_hotelr.Click += new System.EventHandler(this.backtoresbutton_hotelr_Click);
            // 
            // mainmenubutton_hotelr
            // 
            this.mainmenubutton_hotelr.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.mainmenubutton_hotelr.Location = new System.Drawing.Point(56, 289);
            this.mainmenubutton_hotelr.Name = "mainmenubutton_hotelr";
            this.mainmenubutton_hotelr.Size = new System.Drawing.Size(114, 23);
            this.mainmenubutton_hotelr.TabIndex = 30;
            this.mainmenubutton_hotelr.Text = "Back to main menu";
            this.mainmenubutton_hotelr.UseVisualStyleBackColor = true;
            this.mainmenubutton_hotelr.Click += new System.EventHandler(this.mainmenubutton_hotelr_Click);
            // 
            // cuscontacttextBox_holidayr
            // 
            this.cuscontacttextBox_holidayr.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.cuscontacttextBox_holidayr.Location = new System.Drawing.Point(213, 203);
            this.cuscontacttextBox_holidayr.Name = "cuscontacttextBox_holidayr";
            this.cuscontacttextBox_holidayr.Size = new System.Drawing.Size(254, 20);
            this.cuscontacttextBox_holidayr.TabIndex = 28;
            // 
            // emailtextBox_holidayr
            // 
            this.emailtextBox_holidayr.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.emailtextBox_holidayr.Location = new System.Drawing.Point(213, 165);
            this.emailtextBox_holidayr.Name = "emailtextBox_holidayr";
            this.emailtextBox_holidayr.Size = new System.Drawing.Size(254, 20);
            this.emailtextBox_holidayr.TabIndex = 27;
            // 
            // cusaddresstextBox_holidayr
            // 
            this.cusaddresstextBox_holidayr.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.cusaddresstextBox_holidayr.Location = new System.Drawing.Point(213, 130);
            this.cusaddresstextBox_holidayr.Name = "cusaddresstextBox_holidayr";
            this.cusaddresstextBox_holidayr.Size = new System.Drawing.Size(254, 20);
            this.cusaddresstextBox_holidayr.TabIndex = 26;
            // 
            // cusnametextBox_holidayr
            // 
            this.cusnametextBox_holidayr.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.cusnametextBox_holidayr.Location = new System.Drawing.Point(213, 92);
            this.cusnametextBox_holidayr.Name = "cusnametextBox_holidayr";
            this.cusnametextBox_holidayr.Size = new System.Drawing.Size(254, 20);
            this.cusnametextBox_holidayr.TabIndex = 25;
            // 
            // cusidtextBox_holidayr
            // 
            this.cusidtextBox_holidayr.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.cusidtextBox_holidayr.Location = new System.Drawing.Point(213, 57);
            this.cusidtextBox_holidayr.Name = "cusidtextBox_holidayr";
            this.cusidtextBox_holidayr.Size = new System.Drawing.Size(254, 20);
            this.cusidtextBox_holidayr.TabIndex = 24;
            // 
            // confirmbutton_hotelr
            // 
            this.confirmbutton_hotelr.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.confirmbutton_hotelr.Location = new System.Drawing.Point(338, 289);
            this.confirmbutton_hotelr.Name = "confirmbutton_hotelr";
            this.confirmbutton_hotelr.Size = new System.Drawing.Size(75, 23);
            this.confirmbutton_hotelr.TabIndex = 23;
            this.confirmbutton_hotelr.Text = "Confirm";
            this.confirmbutton_hotelr.UseVisualStyleBackColor = true;
            this.confirmbutton_hotelr.Click += new System.EventHandler(this.confirmbutton_hotelr_Click);
            // 
            // dateofbookinglabel_holidayr
            // 
            this.dateofbookinglabel_holidayr.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.dateofbookinglabel_holidayr.AutoSize = true;
            this.dateofbookinglabel_holidayr.Location = new System.Drawing.Point(9, 240);
            this.dateofbookinglabel_holidayr.Name = "dateofbookinglabel_holidayr";
            this.dateofbookinglabel_holidayr.Size = new System.Drawing.Size(83, 13);
            this.dateofbookinglabel_holidayr.TabIndex = 22;
            this.dateofbookinglabel_holidayr.Text = "Date of booking";
            // 
            // cuscontactlabel_holidayr
            // 
            this.cuscontactlabel_holidayr.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.cuscontactlabel_holidayr.AutoSize = true;
            this.cuscontactlabel_holidayr.Location = new System.Drawing.Point(9, 203);
            this.cuscontactlabel_holidayr.Name = "cuscontactlabel_holidayr";
            this.cuscontactlabel_holidayr.Size = new System.Drawing.Size(90, 13);
            this.cuscontactlabel_holidayr.TabIndex = 21;
            this.cuscontactlabel_holidayr.Text = "Customer contact";
            // 
            // emaillabel_holidayr
            // 
            this.emaillabel_holidayr.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.emaillabel_holidayr.AutoSize = true;
            this.emaillabel_holidayr.Location = new System.Drawing.Point(9, 165);
            this.emaillabel_holidayr.Name = "emaillabel_holidayr";
            this.emaillabel_holidayr.Size = new System.Drawing.Size(32, 13);
            this.emaillabel_holidayr.TabIndex = 20;
            this.emaillabel_holidayr.Text = "Email";
            // 
            // addresslabel_holidayr
            // 
            this.addresslabel_holidayr.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.addresslabel_holidayr.AutoSize = true;
            this.addresslabel_holidayr.Location = new System.Drawing.Point(9, 130);
            this.addresslabel_holidayr.Name = "addresslabel_holidayr";
            this.addresslabel_holidayr.Size = new System.Drawing.Size(92, 13);
            this.addresslabel_holidayr.TabIndex = 19;
            this.addresslabel_holidayr.Text = "Customer Address";
            // 
            // cusnamelabel_holidayr
            // 
            this.cusnamelabel_holidayr.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.cusnamelabel_holidayr.AutoSize = true;
            this.cusnamelabel_holidayr.Location = new System.Drawing.Point(9, 92);
            this.cusnamelabel_holidayr.Name = "cusnamelabel_holidayr";
            this.cusnamelabel_holidayr.Size = new System.Drawing.Size(82, 13);
            this.cusnamelabel_holidayr.TabIndex = 18;
            this.cusnamelabel_holidayr.Text = "Customer Name";
            // 
            // cusidlabel_holidayr
            // 
            this.cusidlabel_holidayr.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.cusidlabel_holidayr.AutoSize = true;
            this.cusidlabel_holidayr.Location = new System.Drawing.Point(9, 57);
            this.cusidlabel_holidayr.Name = "cusidlabel_holidayr";
            this.cusidlabel_holidayr.Size = new System.Drawing.Size(194, 13);
            this.cusidlabel_holidayr.TabIndex = 17;
            this.cusidlabel_holidayr.Text = "Customer IC number/ Passport Number ";
            // 
            // cusinfolabel_holidayr
            // 
            this.cusinfolabel_holidayr.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.cusinfolabel_holidayr.AutoSize = true;
            this.cusinfolabel_holidayr.Font = new System.Drawing.Font("Segoe UI Symbol", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cusinfolabel_holidayr.Location = new System.Drawing.Point(8, 9);
            this.cusinfolabel_holidayr.Name = "cusinfolabel_holidayr";
            this.cusinfolabel_holidayr.Size = new System.Drawing.Size(428, 21);
            this.cusinfolabel_holidayr.TabIndex = 16;
            this.cusinfolabel_holidayr.Text = "Customer Information (Holiday Package Reservation)";
            // 
            // cusinfoholresdateTimePicker
            // 
            this.cusinfoholresdateTimePicker.Location = new System.Drawing.Point(213, 243);
            this.cusinfoholresdateTimePicker.Name = "cusinfoholresdateTimePicker";
            this.cusinfoholresdateTimePicker.Size = new System.Drawing.Size(254, 20);
            this.cusinfoholresdateTimePicker.TabIndex = 32;
            // 
            // CusInfo_holir
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(479, 334);
            this.Controls.Add(this.cusinfoholresdateTimePicker);
            this.Controls.Add(this.backtoresbutton_hotelr);
            this.Controls.Add(this.mainmenubutton_hotelr);
            this.Controls.Add(this.cuscontacttextBox_holidayr);
            this.Controls.Add(this.emailtextBox_holidayr);
            this.Controls.Add(this.cusaddresstextBox_holidayr);
            this.Controls.Add(this.cusnametextBox_holidayr);
            this.Controls.Add(this.cusidtextBox_holidayr);
            this.Controls.Add(this.confirmbutton_hotelr);
            this.Controls.Add(this.dateofbookinglabel_holidayr);
            this.Controls.Add(this.cuscontactlabel_holidayr);
            this.Controls.Add(this.emaillabel_holidayr);
            this.Controls.Add(this.addresslabel_holidayr);
            this.Controls.Add(this.cusnamelabel_holidayr);
            this.Controls.Add(this.cusidlabel_holidayr);
            this.Controls.Add(this.cusinfolabel_holidayr);
            this.Name = "CusInfo_holir";
            this.Text = "Cus Info (Holiday Package)";
            this.Load += new System.EventHandler(this.CusInfo_holir_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button backtoresbutton_hotelr;
        private System.Windows.Forms.Button mainmenubutton_hotelr;
        private System.Windows.Forms.TextBox cuscontacttextBox_holidayr;
        private System.Windows.Forms.TextBox emailtextBox_holidayr;
        private System.Windows.Forms.TextBox cusaddresstextBox_holidayr;
        private System.Windows.Forms.TextBox cusnametextBox_holidayr;
        private System.Windows.Forms.TextBox cusidtextBox_holidayr;
        private System.Windows.Forms.Button confirmbutton_hotelr;
        private System.Windows.Forms.Label dateofbookinglabel_holidayr;
        private System.Windows.Forms.Label cuscontactlabel_holidayr;
        private System.Windows.Forms.Label emaillabel_holidayr;
        private System.Windows.Forms.Label addresslabel_holidayr;
        private System.Windows.Forms.Label cusnamelabel_holidayr;
        private System.Windows.Forms.Label cusidlabel_holidayr;
        private System.Windows.Forms.Label cusinfolabel_holidayr;
        private System.Windows.Forms.DateTimePicker cusinfoholresdateTimePicker;
    }
}