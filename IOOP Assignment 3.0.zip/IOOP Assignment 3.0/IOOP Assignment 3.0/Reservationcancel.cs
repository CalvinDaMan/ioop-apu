﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
namespace IOOP_Assignment_3._0
{
    public partial class Reservationcancel : Form
    {
        OleDbConnection cnnOLEDB = new OleDbConnection();
        OleDbCommand cmdInsert = new OleDbCommand();
        OleDbCommand cmdDelete = new OleDbCommand();
        OleDbCommand cmdUpdate = new OleDbCommand();
        OleDbCommand cmdSearch = new OleDbCommand();


        public Reservationcancel()
        {
            InitializeComponent();
        }

        private void rescancmainmenubutton_Click(object sender, EventArgs e)
        {
            const string message = "Do you want to go to MAIN MENU?";
            const string caption = "MAIN MENU";
            var result = MessageBox.Show(message, caption, MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes) //if user click on "yes", the program would be closed, 
                                            //if not message box would be close
            {
                MainMenu newForm = new MainMenu();
                newForm.Show();
                this.Hide();
            }
        }



        private void confirmresmodbutton_Click(object sender, EventArgs e)
        {
            string hotelresidvalid = "Hotel Reservation ID:" + searchresidtextBox.Text;
            string hotelcusidvalid = "HCustomer ID:" + searchcusidtextBox.Text;
            string tourresidvalid = "Tour Reservation ID:" + searchresidtextBox.Text;
            string tourcusidvalid = "TCustomer ID:" + searchcusidtextBox.Text;
            string holiresidvalid = "Holiday Reservation ID:" + searchresidtextBox.Text;
            string holicusidvalid = "HoCustomer ID:" + searchcusidtextBox.Text;

            const string message = "Do you want to CANCEL RESERVATION?";
            const string caption = "CANCELLATION";
            var result = MessageBox.Show(message, caption, MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes) //if user click on "yes", the program would be closed,if not msgbox would be close
            {
                if (rescancresultlistbox.Items.Count != 0)// if listbox is not empty
                {
                    if (hotelradioButton.Checked == true && tourradioButton.Checked == false && holidayradioButton.Checked == false)
                    {
                        if (hotelcusidvalid == rescancresultlistbox.Items[8].ToString() || hotelresidvalid == rescancresultlistbox.Items[0].ToString())// check that the value in txtbox is same as the listbox
                        {
                            cmdDelete.CommandText = "Delete from hotelres where customerID=\'" + searchcusidtextBox.Text + "\'or hotelreservationID=\'" + searchresidtextBox.Text + "\';";
                            cmdDelete.CommandType = CommandType.Text;
                            cmdDelete.Connection = cnnOLEDB;
                            cmdDelete.ExecuteNonQuery();
                            MessageBox.Show("Deletion Successful");
                        }
                        else
                        {
                            MessageBox.Show("Please select the correct reservation type that associates with CustomerID or RegistrationID.");
                        }

                    }
                    else if (hotelradioButton.Checked == false && tourradioButton.Checked == true && holidayradioButton.Checked == false)
                    {
                        if (tourcusidvalid == rescancresultlistbox.Items[7].ToString() || tourresidvalid == rescancresultlistbox.Items[0].ToString())// check that the value in txtbox is same as the listbox
                        {
                            cmdDelete.CommandText = "Delete from tourres where customerid=\'" + searchcusidtextBox.Text + "\'or tourreservationID=\'" + searchresidtextBox.Text + "\';";
                            cmdDelete.CommandType = CommandType.Text;
                            cmdDelete.Connection = cnnOLEDB;
                            cmdDelete.ExecuteNonQuery();
                            MessageBox.Show("Deletion Successful");
                        }
                        else
                        {
                            MessageBox.Show("Please select the correct reservation type that associates with CustomerID or RegistrationID.");
                        }
                    }
                    else if (hotelradioButton.Checked == false && tourradioButton.Checked == false && holidayradioButton.Checked == true)
                    {
                        if (holicusidvalid == rescancresultlistbox.Items[8].ToString() || holiresidvalid == rescancresultlistbox.Items[0].ToString())// check that the value in txtbox is same as the listbox
                        {
                            cmdDelete.CommandText = "Delete from holidayres where customerid=\'" + searchcusidtextBox.Text + "\'or holireservationID=\'" + searchresidtextBox.Text + "\';";
                            cmdDelete.CommandType = CommandType.Text;
                            cmdDelete.Connection = cnnOLEDB;
                            cmdDelete.ExecuteNonQuery();
                            MessageBox.Show("Deletion Successful");
                        }
                        else
                        {
                            MessageBox.Show("Please select the correct reservation type that associates with CustomerID or RegistrationID.");
                        }
                    }
                    else
                    {
                        MessageBox.Show("Please select the correct type of reservation and information is matched correctly.");
                    }
                }
                else
                {
                    MessageBox.Show("Please enter data in the textbox.");
                }
            }
        }

        private void searchhotelresbutton_Click(object sender, EventArgs e)
        {
            if (searchcusidtextBox.Text != "" && searchresidtextBox.Text == "")
            {
                cmdSearch.CommandText = "Select * from hotelres where customerID= \'" + searchcusidtextBox.Text + "\';";
                cmdSearch.Connection = cnnOLEDB;
                OleDbDataReader dr = cmdSearch.ExecuteReader();
                if (dr.Read() == true)
                {
                    rescancresultlistbox.Items.Clear();//clear the previous entry
                    rescancresultlistbox.Items.Add("Hotel Reservation ID:" + dr[0].ToString());
                    rescancresultlistbox.Items.Add("Hotel ID: " + dr[1].ToString());
                    rescancresultlistbox.Items.Add("Hotel Name: " + dr[2].ToString());
                    rescancresultlistbox.Items.Add("Amount Reserved: " + dr[3].ToString());
                    rescancresultlistbox.Items.Add("Room Type: " + dr[4].ToString());
                    rescancresultlistbox.Items.Add("Room Price: " + dr[5].ToString());
                    rescancresultlistbox.Items.Add("Date Reserved (Start): " + dr[6].ToString());
                    rescancresultlistbox.Items.Add("Date Reserved (End): " + dr[7].ToString());
                    rescancresultlistbox.Items.Add("HCustomer ID:" + dr[8].ToString());
                }
                else
                {
                    MessageBox.Show("Information not found");
                    rescancresultlistbox.Items.Clear();
                }
                dr.Close();
            }
            else if (searchresidtextBox.Text != "" && searchcusidtextBox.Text == "")
            {
                cmdSearch.CommandText = "Select * from hotelres where hotelreservationID= \'" + searchresidtextBox.Text + "\';";
                cmdSearch.Connection = cnnOLEDB;
                OleDbDataReader dr = cmdSearch.ExecuteReader();
                if (dr.Read() == true)
                {
                    rescancresultlistbox.Items.Clear();//clear the previous entry
                    rescancresultlistbox.Items.Add("Hotel Reservation ID:" + dr[0].ToString());
                    rescancresultlistbox.Items.Add("Hotel ID: " + dr[1].ToString());
                    rescancresultlistbox.Items.Add("Hotel Name: " + dr[2].ToString());
                    rescancresultlistbox.Items.Add("Amount Reserved: " + dr[3].ToString());
                    rescancresultlistbox.Items.Add("Room Type: " + dr[4].ToString());
                    rescancresultlistbox.Items.Add("Room Price: " + dr[5].ToString());
                    rescancresultlistbox.Items.Add("Date Reserved (Start): " + dr[6].ToString());
                    rescancresultlistbox.Items.Add("Date Reserved (End): " + dr[7].ToString());
                    rescancresultlistbox.Items.Add("HCustomer ID:" + dr[8].ToString());
                }
                else
                {
                    MessageBox.Show("Information not found");
                    rescancresultlistbox.Items.Clear();
                }
                dr.Close();
            }
            else if (searchresidtextBox.Text != "" && searchcusidtextBox.Text != "")
            {
                cmdSearch.CommandText = "Select * from hotelres where hotelreservationID= \'" + searchresidtextBox.Text + "\';";
                cmdSearch.Connection = cnnOLEDB;
                OleDbDataReader dr = cmdSearch.ExecuteReader();
                if (dr.Read() == true)
                {
                    rescancresultlistbox.Items.Clear();//clear the previous entry
                    rescancresultlistbox.Items.Add("Hotel Reservation ID:" + dr[0].ToString());
                    rescancresultlistbox.Items.Add("Hotel ID: " + dr[1].ToString());
                    rescancresultlistbox.Items.Add("Hotel Name: " + dr[2].ToString());
                    rescancresultlistbox.Items.Add("Amount Reserved: " + dr[3].ToString());
                    rescancresultlistbox.Items.Add("Room Type: " + dr[4].ToString());
                    rescancresultlistbox.Items.Add("Room Price: " + dr[5].ToString());
                    rescancresultlistbox.Items.Add("Date Reserved (Start): " + dr[6].ToString());
                    rescancresultlistbox.Items.Add("Date Reserved (End): " + dr[7].ToString());
                    rescancresultlistbox.Items.Add("HCustomer ID:" + dr[8].ToString());
                }
                else
                {
                    MessageBox.Show("Information not found");
                    rescancresultlistbox.Items.Clear();
                }
                dr.Close();
            }
            else
            {
                MessageBox.Show("Blank fields are not allowed.");
            }
        }

        private void Reservationcancel_Load(object sender, EventArgs e)
        {
            cnnOLEDB.ConnectionString = "Provider =Microsoft.ACE.OLEDB.12.0; Data Source =IOOPDb.accdb";
            cnnOLEDB.Open();
        }

        private void searchtourresbutton_Click(object sender, EventArgs e)
        {
            if (searchcusidtextBox.Text != "" && searchresidtextBox.Text == "")
            {
                cmdSearch.CommandText = "Select * from tourres where customerid= \'" + searchcusidtextBox.Text + "\';";
                cmdSearch.Connection = cnnOLEDB;
                OleDbDataReader dr = cmdSearch.ExecuteReader();
                if (dr.Read() == true)
                {
                    rescancresultlistbox.Items.Clear();//clear the previous entry
                    rescancresultlistbox.Items.Add("Tour Reservation ID:" + dr[0].ToString());
                    rescancresultlistbox.Items.Add("Tour ID: " + dr[1].ToString());
                    rescancresultlistbox.Items.Add("Tour Name: " + dr[2].ToString());
                    rescancresultlistbox.Items.Add("Amount reserved: " + dr[3].ToString());
                    rescancresultlistbox.Items.Add("Tour Price: " + dr[4].ToString());
                    rescancresultlistbox.Items.Add("Date Reserved (Start): " + dr[5].ToString());
                    rescancresultlistbox.Items.Add("Date Reserved (End): " + dr[6].ToString());
                    rescancresultlistbox.Items.Add("TCustomer ID:" + dr[7].ToString());
                }
                else
                {
                    MessageBox.Show("Information not found");
                }
                dr.Close();
            }
            else if (searchcusidtextBox.Text == "" && searchresidtextBox.Text != "")
            {
                cmdSearch.CommandText = "Select * from tourres where tourreservationID= \'" + searchresidtextBox.Text + "\';";
                cmdSearch.Connection = cnnOLEDB;
                OleDbDataReader dr = cmdSearch.ExecuteReader();
                if (dr.Read() == true)
                {
                    rescancresultlistbox.Items.Clear();//clear the previous entry
                    rescancresultlistbox.Items.Add("Tour Reservation ID:" + dr[0].ToString());
                    rescancresultlistbox.Items.Add("Tour ID: " + dr[1].ToString());
                    rescancresultlistbox.Items.Add("Tour Name: " + dr[2].ToString());
                    rescancresultlistbox.Items.Add("Amount reserved: " + dr[3].ToString());
                    rescancresultlistbox.Items.Add("Tour Price: " + dr[4].ToString());
                    rescancresultlistbox.Items.Add("Date Reserved (Start): " + dr[5].ToString());
                    rescancresultlistbox.Items.Add("Date Reserved (End): " + dr[6].ToString());
                    rescancresultlistbox.Items.Add("TCustomer ID:" + dr[7].ToString());
                }
                else
                {
                    MessageBox.Show("Information not found");
                    rescancresultlistbox.Items.Clear();
                }
                dr.Close();
            }
            else if (searchcusidtextBox.Text != "" && searchresidtextBox.Text != "")
            {
                cmdSearch.CommandText = "Select * from tourres where customerid= \'" + searchcusidtextBox.Text + "\';";
                cmdSearch.Connection = cnnOLEDB;
                OleDbDataReader dr = cmdSearch.ExecuteReader();
                if (dr.Read() == true)
                {
                    rescancresultlistbox.Items.Clear();//clear the previous entry
                    rescancresultlistbox.Items.Add("Tour Reservation ID:" + dr[0].ToString());
                    rescancresultlistbox.Items.Add("Tour ID: " + dr[1].ToString());
                    rescancresultlistbox.Items.Add("Tour Name: " + dr[2].ToString());
                    rescancresultlistbox.Items.Add("Amount reserved: " + dr[3].ToString());
                    rescancresultlistbox.Items.Add("Tour Price: " + dr[4].ToString());
                    rescancresultlistbox.Items.Add("Date Reserved (Start): " + dr[5].ToString());
                    rescancresultlistbox.Items.Add("Date Reserved (End): " + dr[6].ToString());
                    rescancresultlistbox.Items.Add("TCustomer ID:" + dr[7].ToString());
                }
                else
                {
                    MessageBox.Show("Information not found");
                    rescancresultlistbox.Items.Clear();
                }
                dr.Close();
            }
            else
            {
                MessageBox.Show("Blank fields are not allowed.");
            }
        }

        private void searchholidayreservation_Click(object sender, EventArgs e)
        {

        }

        private void searchholidayreservation_Click_1(object sender, EventArgs e)
        {
            if (searchcusidtextBox.Text != "" && searchresidtextBox.Text == "")
            {
                cmdSearch.CommandText = "Select * from holidayres where customerid= \'" + searchcusidtextBox.Text + "\';";
                cmdSearch.Connection = cnnOLEDB;
                OleDbDataReader dr = cmdSearch.ExecuteReader();
                if (dr.Read() == true)
                {
                    rescancresultlistbox.Items.Clear();//clear the previous entry
                    rescancresultlistbox.Items.Add("Holiday Reservation ID:" + dr[0].ToString());
                    rescancresultlistbox.Items.Add("Holiday Package ID: " + dr[1].ToString());
                    rescancresultlistbox.Items.Add("Holiday Package: " + dr[2].ToString());
                    rescancresultlistbox.Items.Add("Room Type: " + dr[3].ToString());
                    rescancresultlistbox.Items.Add("Amount Reserved: " + dr[4].ToString());
                    rescancresultlistbox.Items.Add("Holiday Price: " + dr[5].ToString());
                    rescancresultlistbox.Items.Add("Date Reserved (Start): " + dr[6].ToString());
                    rescancresultlistbox.Items.Add("Date Reserved (End): " + dr[7].ToString());
                    rescancresultlistbox.Items.Add("HoCustomer ID:" + dr[8].ToString());
                }
                else
                {
                    MessageBox.Show("Information not found");
                    rescancresultlistbox.Items.Clear();
                }
                dr.Close();
            }
            else if (searchcusidtextBox.Text == "" && searchresidtextBox.Text != "")
            {
                cmdSearch.CommandText = "Select * from holidayres where holireservationID= \'" + searchresidtextBox.Text + "\';";
                cmdSearch.Connection = cnnOLEDB;
                OleDbDataReader dr = cmdSearch.ExecuteReader();
                if (dr.Read() == true)
                {
                    rescancresultlistbox.Items.Clear();//clear the previous entry
                    rescancresultlistbox.Items.Add("Holiday Reservation ID:" + dr[0].ToString());
                    rescancresultlistbox.Items.Add("Holiday Package ID: " + dr[1].ToString());
                    rescancresultlistbox.Items.Add("Holiday Package: " + dr[2].ToString());
                    rescancresultlistbox.Items.Add("Room Type: " + dr[3].ToString());
                    rescancresultlistbox.Items.Add("Amount Reserved: " + dr[4].ToString());
                    rescancresultlistbox.Items.Add("Holiday Price: " + dr[5].ToString());
                    rescancresultlistbox.Items.Add("Date Reserved (Start): " + dr[6].ToString());
                    rescancresultlistbox.Items.Add("Date Reserved (End): " + dr[7].ToString());
                    rescancresultlistbox.Items.Add("HoCustomer ID:" + dr[8].ToString());
                }
                else
                {
                    MessageBox.Show("Information not found");
                    rescancresultlistbox.Items.Clear();
                }
                dr.Close();
            }
            else if (searchcusidtextBox.Text != "" && searchresidtextBox.Text != "")
            {
                cmdSearch.CommandText = "Select * from holidayres where customerid= \'" + searchcusidtextBox.Text + "\';";
                cmdSearch.Connection = cnnOLEDB;
                OleDbDataReader dr = cmdSearch.ExecuteReader();
                if (dr.Read() == true)
                {
                    rescancresultlistbox.Items.Clear();//clear the previous entry
                    rescancresultlistbox.Items.Add("Holiday Reservation ID:" + dr[0].ToString());
                    rescancresultlistbox.Items.Add("Holiday Package ID: " + dr[1].ToString());
                    rescancresultlistbox.Items.Add("Holiday Package: " + dr[2].ToString());
                    rescancresultlistbox.Items.Add("Room Type: " + dr[3].ToString());
                    rescancresultlistbox.Items.Add("Amount Reserved: " + dr[4].ToString());
                    rescancresultlistbox.Items.Add("Holiday Price: " + dr[5].ToString());
                    rescancresultlistbox.Items.Add("Date Reserved (Start): " + dr[6].ToString());
                    rescancresultlistbox.Items.Add("Date Reserved (End): " + dr[7].ToString());
                    rescancresultlistbox.Items.Add("HoCustomer ID:" + dr[8].ToString());
                }
                else
                {
                    MessageBox.Show("Information not found");
                    rescancresultlistbox.Items.Clear();
                }
            }
            else
            {
                MessageBox.Show("Blank fields are not allowed.");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
           // newForm= new rescancdatagridview();
           // newForm.Show();
            //this.Hide();
        }

        private void viewchangehotelradioButton_CheckedChanged(object sender, EventArgs e)
        {
            if (viewchangehotelradioButton.Checked== true && viewchangetourradioButton.Checked == false && viewchangeholidayradioButton.Checked == false)
            {
                vewchangehotel newform = new vewchangehotel();
                newform.Show();
            }
        }

        private void viewchangetourradioButton_CheckedChanged(object sender, EventArgs e)
        {
            if (viewchangehotelradioButton.Checked == false && viewchangetourradioButton.Checked== true && viewchangeholidayradioButton.Checked == false)
            {
                viewchangetour newform = new viewchangetour();
                newform.Show();
            }
        }

        private void viewchangeholidayradioButton_CheckedChanged(object sender, EventArgs e)
        {if (viewchangehotelradioButton.Checked == false && viewchangetourradioButton.Checked== false && viewchangeholidayradioButton.Checked == true)
            {
                viewchangeholiday newform = new viewchangeholiday();
                newform.Show();
            }
        }
    }
}
