﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IOOP_Assignment_3._0
{
    public partial class MainMenu : Form
    {
        public MainMenu()
        {
            InitializeComponent();
        }

        private void exitbutton_Click(object sender, EventArgs e)
        {
            const string message = "Do you want to exit?";
            const string caption = "EXIT";
            var result = MessageBox.Show(message, caption, MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes) //if user click on "yes", the program would be closed, 
                                            //if not message box would be close
            {
                Application .Exit();
            }
        }

        private void logoutbutton_Click(object sender, EventArgs e)
        {
            const string message = "Do you want to logout?";
            const string caption = "LOGOUT";
            var result = MessageBox.Show(message, caption, MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes) //if user click on "yes", the program would be closed, 
                                            //if not message box would be close
            {
                Login newForm = new Login();
                newForm.Show();
                this.Hide();
            }
        }

        private void resbutton_Click(object sender, EventArgs e)
        {
            Reservation newForm = new Reservation();
            newForm.Show();
            this.Hide();
        }

        private void cancpolicybutton_Click(object sender, EventArgs e)
        {
            Cancelpol newForm = new Cancelpol();
            newForm.Show();
            this.Hide();
        }

        private void reportgenerationbutton_Click(object sender, EventArgs e)
        {
            Reportgen newForm = new Reportgen();
            newForm.Show();
            this.Hide();
        }

        private void resmodbutton_Click(object sender, EventArgs e)
        {

            reservationmodselection newForm = new reservationmodselection();
            newForm.Show();
            this.Hide();
        }

        private void rescancelbutton_Click(object sender, EventArgs e)
        {
            Reservationcancel newForm = new Reservationcancel();
            newForm .Show ();
            this.Hide();
        }

        private void paymentstatusbutton_Click(object sender, EventArgs e)
        {
            payment newForm = new payment();
            newForm.Show();
            this.Hide();
        }
    }
}
