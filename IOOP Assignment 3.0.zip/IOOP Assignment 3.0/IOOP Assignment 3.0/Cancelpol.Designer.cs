﻿namespace IOOP_Assignment_3._0
{
    partial class Cancelpol
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.mainmenubutton = new System.Windows.Forms.Button();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.cancelpolicylabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // mainmenubutton
            // 
            this.mainmenubutton.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.mainmenubutton.Location = new System.Drawing.Point(148, 212);
            this.mainmenubutton.Name = "mainmenubutton";
            this.mainmenubutton.Size = new System.Drawing.Size(124, 22);
            this.mainmenubutton.TabIndex = 16;
            this.mainmenubutton.Text = "Back to Main Menu";
            this.mainmenubutton.UseVisualStyleBackColor = true;
            this.mainmenubutton.Click += new System.EventHandler(this.mainmenubutton_Click);
            // 
            // richTextBox1
            // 
            this.richTextBox1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.richTextBox1.BackColor = System.Drawing.SystemColors.Control;
            this.richTextBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.richTextBox1.Location = new System.Drawing.Point(18, 57);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.ReadOnly = true;
            this.richTextBox1.Size = new System.Drawing.Size(386, 96);
            this.richTextBox1.TabIndex = 15;
            this.richTextBox1.Text = "Customers can cancel their reservations 5 days prior to the scheduled date. If pa" +
    "yment is late, RM 50.00 of administrative charges are applicable.";
            // 
            // cancelpolicylabel
            // 
            this.cancelpolicylabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.cancelpolicylabel.AutoSize = true;
            this.cancelpolicylabel.Location = new System.Drawing.Point(21, 26);
            this.cancelpolicylabel.Name = "cancelpolicylabel";
            this.cancelpolicylabel.Size = new System.Drawing.Size(39, 13);
            this.cancelpolicylabel.TabIndex = 14;
            this.cancelpolicylabel.Text = "Details";
            // 
            // Cancelpol
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(422, 261);
            this.Controls.Add(this.mainmenubutton);
            this.Controls.Add(this.richTextBox1);
            this.Controls.Add(this.cancelpolicylabel);
            this.Name = "Cancelpol";
            this.Text = "Form3";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button mainmenubutton;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.Label cancelpolicylabel;
    }
}