﻿namespace IOOP_Assignment_3._0
{
    partial class MainMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.logoutbutton = new System.Windows.Forms.Button();
            this.reportgenerationbutton = new System.Windows.Forms.Button();
            this.rescancelbutton = new System.Windows.Forms.Button();
            this.cancpolicybutton = new System.Windows.Forms.Button();
            this.resmodbutton = new System.Windows.Forms.Button();
            this.resbutton = new System.Windows.Forms.Button();
            this.exitbutton = new System.Windows.Forms.Button();
            this.pacifictouroperatorlabel = new System.Windows.Forms.Label();
            this.paymentstatusbutton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // logoutbutton
            // 
            this.logoutbutton.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.logoutbutton.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.logoutbutton.Location = new System.Drawing.Point(38, 261);
            this.logoutbutton.Name = "logoutbutton";
            this.logoutbutton.Size = new System.Drawing.Size(75, 34);
            this.logoutbutton.TabIndex = 33;
            this.logoutbutton.Text = "Logout";
            this.logoutbutton.UseVisualStyleBackColor = true;
            this.logoutbutton.Click += new System.EventHandler(this.logoutbutton_Click);
            // 
            // reportgenerationbutton
            // 
            this.reportgenerationbutton.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.reportgenerationbutton.Font = new System.Drawing.Font("Monotype Corsiva", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.reportgenerationbutton.Location = new System.Drawing.Point(166, 358);
            this.reportgenerationbutton.Name = "reportgenerationbutton";
            this.reportgenerationbutton.Size = new System.Drawing.Size(366, 53);
            this.reportgenerationbutton.TabIndex = 32;
            this.reportgenerationbutton.Text = "Report Generation (For Managers Only)";
            this.reportgenerationbutton.UseVisualStyleBackColor = true;
            this.reportgenerationbutton.Click += new System.EventHandler(this.reportgenerationbutton_Click);
            // 
            // rescancelbutton
            // 
            this.rescancelbutton.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.rescancelbutton.Font = new System.Drawing.Font("Monotype Corsiva", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rescancelbutton.Location = new System.Drawing.Point(166, 187);
            this.rescancelbutton.Name = "rescancelbutton";
            this.rescancelbutton.Size = new System.Drawing.Size(366, 36);
            this.rescancelbutton.TabIndex = 31;
            this.rescancelbutton.Text = "Reservation Cancellation";
            this.rescancelbutton.UseVisualStyleBackColor = true;
            this.rescancelbutton.Click += new System.EventHandler(this.rescancelbutton_Click);
            // 
            // cancpolicybutton
            // 
            this.cancpolicybutton.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.cancpolicybutton.Font = new System.Drawing.Font("Monotype Corsiva", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cancpolicybutton.Location = new System.Drawing.Point(166, 247);
            this.cancpolicybutton.Name = "cancpolicybutton";
            this.cancpolicybutton.Size = new System.Drawing.Size(366, 34);
            this.cancpolicybutton.TabIndex = 30;
            this.cancpolicybutton.Text = "Cancellation Policy";
            this.cancpolicybutton.UseVisualStyleBackColor = true;
            this.cancpolicybutton.Click += new System.EventHandler(this.cancpolicybutton_Click);
            // 
            // resmodbutton
            // 
            this.resmodbutton.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.resmodbutton.Font = new System.Drawing.Font("Monotype Corsiva", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.resmodbutton.Location = new System.Drawing.Point(166, 129);
            this.resmodbutton.Name = "resmodbutton";
            this.resmodbutton.Size = new System.Drawing.Size(366, 34);
            this.resmodbutton.TabIndex = 29;
            this.resmodbutton.Text = "Reservation Modification";
            this.resmodbutton.UseVisualStyleBackColor = true;
            this.resmodbutton.Click += new System.EventHandler(this.resmodbutton_Click);
            // 
            // resbutton
            // 
            this.resbutton.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.resbutton.AutoSize = true;
            this.resbutton.Font = new System.Drawing.Font("Monotype Corsiva", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.resbutton.Location = new System.Drawing.Point(166, 70);
            this.resbutton.Name = "resbutton";
            this.resbutton.Size = new System.Drawing.Size(366, 40);
            this.resbutton.TabIndex = 28;
            this.resbutton.Text = "Reservation";
            this.resbutton.UseVisualStyleBackColor = true;
            this.resbutton.Click += new System.EventHandler(this.resbutton_Click);
            // 
            // exitbutton
            // 
            this.exitbutton.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.exitbutton.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.exitbutton.Location = new System.Drawing.Point(38, 312);
            this.exitbutton.Name = "exitbutton";
            this.exitbutton.Size = new System.Drawing.Size(68, 38);
            this.exitbutton.TabIndex = 27;
            this.exitbutton.Text = "Exit";
            this.exitbutton.UseVisualStyleBackColor = true;
            this.exitbutton.Click += new System.EventHandler(this.exitbutton_Click);
            // 
            // pacifictouroperatorlabel
            // 
            this.pacifictouroperatorlabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pacifictouroperatorlabel.AutoSize = true;
            this.pacifictouroperatorlabel.Font = new System.Drawing.Font("Impact", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pacifictouroperatorlabel.ForeColor = System.Drawing.SystemColors.Highlight;
            this.pacifictouroperatorlabel.Location = new System.Drawing.Point(178, 9);
            this.pacifictouroperatorlabel.Name = "pacifictouroperatorlabel";
            this.pacifictouroperatorlabel.Size = new System.Drawing.Size(340, 45);
            this.pacifictouroperatorlabel.TabIndex = 26;
            this.pacifictouroperatorlabel.Text = "Pacific Tour Operator";
            // 
            // paymentstatusbutton
            // 
            this.paymentstatusbutton.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.paymentstatusbutton.Font = new System.Drawing.Font("Monotype Corsiva", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.paymentstatusbutton.Location = new System.Drawing.Point(166, 303);
            this.paymentstatusbutton.Name = "paymentstatusbutton";
            this.paymentstatusbutton.Size = new System.Drawing.Size(366, 37);
            this.paymentstatusbutton.TabIndex = 34;
            this.paymentstatusbutton.Text = "Payment Status";
            this.paymentstatusbutton.UseVisualStyleBackColor = true;
            this.paymentstatusbutton.Click += new System.EventHandler(this.paymentstatusbutton_Click);
            // 
            // MainMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(624, 417);
            this.Controls.Add(this.paymentstatusbutton);
            this.Controls.Add(this.logoutbutton);
            this.Controls.Add(this.reportgenerationbutton);
            this.Controls.Add(this.rescancelbutton);
            this.Controls.Add(this.cancpolicybutton);
            this.Controls.Add(this.resmodbutton);
            this.Controls.Add(this.resbutton);
            this.Controls.Add(this.exitbutton);
            this.Controls.Add(this.pacifictouroperatorlabel);
            this.Name = "MainMenu";
            this.Text = "MAIN MENU";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button logoutbutton;
        private System.Windows.Forms.Button reportgenerationbutton;
        private System.Windows.Forms.Button rescancelbutton;
        private System.Windows.Forms.Button cancpolicybutton;
        private System.Windows.Forms.Button resmodbutton;
        private System.Windows.Forms.Button resbutton;
        private System.Windows.Forms.Button exitbutton;
        private System.Windows.Forms.Label pacifictouroperatorlabel;
        private System.Windows.Forms.Button paymentstatusbutton;
    }
}

