﻿namespace IOOP_Assignment_3._0
{
    partial class hotelrescanc
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.confirmresmodbutton = new System.Windows.Forms.Button();
            this.searchresmodbutton = new System.Windows.Forms.Button();
            this.resmodresultlabel = new System.Windows.Forms.Label();
            this.resmodmainmenubutton = new System.Windows.Forms.Button();
            this.hotelcancsearchcusidlabel = new System.Windows.Forms.Label();
            this.resmodresulttextBox = new System.Windows.Forms.TextBox();
            this.resmodsearchcusidtextBox = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.rescancsearchhotelidtextBox = new System.Windows.Forms.TextBox();
            this.hotelrescancsearchhotelidlabel = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // confirmresmodbutton
            // 
            this.confirmresmodbutton.Location = new System.Drawing.Point(175, 338);
            this.confirmresmodbutton.Name = "confirmresmodbutton";
            this.confirmresmodbutton.Size = new System.Drawing.Size(75, 23);
            this.confirmresmodbutton.TabIndex = 15;
            this.confirmresmodbutton.Text = "Confirm";
            this.confirmresmodbutton.UseVisualStyleBackColor = true;
            // 
            // searchresmodbutton
            // 
            this.searchresmodbutton.Location = new System.Drawing.Point(361, 166);
            this.searchresmodbutton.Name = "searchresmodbutton";
            this.searchresmodbutton.Size = new System.Drawing.Size(75, 23);
            this.searchresmodbutton.TabIndex = 14;
            this.searchresmodbutton.Text = "Search";
            this.searchresmodbutton.UseVisualStyleBackColor = true;
            // 
            // resmodresultlabel
            // 
            this.resmodresultlabel.AutoSize = true;
            this.resmodresultlabel.Location = new System.Drawing.Point(129, 266);
            this.resmodresultlabel.Name = "resmodresultlabel";
            this.resmodresultlabel.Size = new System.Drawing.Size(37, 13);
            this.resmodresultlabel.TabIndex = 13;
            this.resmodresultlabel.Text = "Result";
            // 
            // resmodmainmenubutton
            // 
            this.resmodmainmenubutton.Location = new System.Drawing.Point(288, 338);
            this.resmodmainmenubutton.Name = "resmodmainmenubutton";
            this.resmodmainmenubutton.Size = new System.Drawing.Size(112, 23);
            this.resmodmainmenubutton.TabIndex = 12;
            this.resmodmainmenubutton.Text = "Back to Main Menu";
            this.resmodmainmenubutton.UseVisualStyleBackColor = true;
            // 
            // hotelcancsearchcusidlabel
            // 
            this.hotelcancsearchcusidlabel.AutoSize = true;
            this.hotelcancsearchcusidlabel.Location = new System.Drawing.Point(140, 152);
            this.hotelcancsearchcusidlabel.Name = "hotelcancsearchcusidlabel";
            this.hotelcancsearchcusidlabel.Size = new System.Drawing.Size(204, 13);
            this.hotelcancsearchcusidlabel.TabIndex = 11;
            this.hotelcancsearchcusidlabel.Text = "Search for customer IC/ Passport Number";
            // 
            // resmodresulttextBox
            // 
            this.resmodresulttextBox.Location = new System.Drawing.Point(131, 282);
            this.resmodresulttextBox.Name = "resmodresulttextBox";
            this.resmodresulttextBox.Size = new System.Drawing.Size(305, 20);
            this.resmodresulttextBox.TabIndex = 9;
            // 
            // resmodsearchcusidtextBox
            // 
            this.resmodsearchcusidtextBox.Location = new System.Drawing.Point(142, 168);
            this.resmodsearchcusidtextBox.Name = "resmodsearchcusidtextBox";
            this.resmodsearchcusidtextBox.Size = new System.Drawing.Size(213, 20);
            this.resmodsearchcusidtextBox.TabIndex = 10;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(361, 215);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 18;
            this.button1.Text = "Search";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // rescancsearchhotelidtextBox
            // 
            this.rescancsearchhotelidtextBox.Location = new System.Drawing.Point(143, 217);
            this.rescancsearchhotelidtextBox.Name = "rescancsearchhotelidtextBox";
            this.rescancsearchhotelidtextBox.Size = new System.Drawing.Size(212, 20);
            this.rescancsearchhotelidtextBox.TabIndex = 17;
            // 
            // hotelrescancsearchhotelidlabel
            // 
            this.hotelrescancsearchhotelidlabel.AutoSize = true;
            this.hotelrescancsearchhotelidlabel.Location = new System.Drawing.Point(140, 201);
            this.hotelrescancsearchhotelidlabel.Name = "hotelrescancsearchhotelidlabel";
            this.hotelrescancsearchhotelidlabel.Size = new System.Drawing.Size(96, 13);
            this.hotelrescancsearchhotelidlabel.TabIndex = 16;
            this.hotelrescancsearchhotelidlabel.Text = "Search for hotel ID";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(227, 116);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 19;
            this.button2.Text = "button2";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // hotelrescanc
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(583, 386);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.rescancsearchhotelidtextBox);
            this.Controls.Add(this.hotelrescancsearchhotelidlabel);
            this.Controls.Add(this.confirmresmodbutton);
            this.Controls.Add(this.searchresmodbutton);
            this.Controls.Add(this.resmodresultlabel);
            this.Controls.Add(this.resmodmainmenubutton);
            this.Controls.Add(this.hotelcancsearchcusidlabel);
            this.Controls.Add(this.resmodresulttextBox);
            this.Controls.Add(this.resmodsearchcusidtextBox);
            this.Name = "hotelrescanc";
            this.Text = "Hotel Reservation Cancellation";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button confirmresmodbutton;
        private System.Windows.Forms.Button searchresmodbutton;
        private System.Windows.Forms.Label resmodresultlabel;
        private System.Windows.Forms.Button resmodmainmenubutton;
        private System.Windows.Forms.Label hotelcancsearchcusidlabel;
        private System.Windows.Forms.TextBox resmodresulttextBox;
        private System.Windows.Forms.TextBox resmodsearchcusidtextBox;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox rescancsearchhotelidtextBox;
        private System.Windows.Forms.Label hotelrescancsearchhotelidlabel;
        private System.Windows.Forms.Button button2;
    }
}