﻿namespace IOOP_Assignment_3._0
{
    partial class hotelresmod
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.resmodmainmenubutton = new System.Windows.Forms.Button();
            this.backbutton = new System.Windows.Forms.Button();
            this.amountcomboBox = new System.Windows.Forms.ComboBox();
            this.amountlabel = new System.Windows.Forms.Label();
            this.hotelresstartdateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.hotelresenddateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.label1 = new System.Windows.Forms.Label();
            this.hoteldatereservedlabel = new System.Windows.Forms.Label();
            this.hotelreshotelpricelabel = new System.Windows.Forms.Label();
            this.hotelrespricetextBox = new System.Windows.Forms.TextBox();
            this.hotelrescusidtextBox = new System.Windows.Forms.TextBox();
            this.hotelrestextBox = new System.Windows.Forms.TextBox();
            this.hotelreshotelidtextBox = new System.Windows.Forms.TextBox();
            this.hotelresroomtypelabel = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.hotelreshotelnamelabel = new System.Windows.Forms.Label();
            this.hotelreshotelidlabel = new System.Windows.Forms.Label();
            this.hotelresroomtypecomboBox = new System.Windows.Forms.ComboBox();
            this.hotelreshotelnamecomboBox = new System.Windows.Forms.ComboBox();
            this.updatebutton = new System.Windows.Forms.Button();
            this.displayholiresbutton = new System.Windows.Forms.Button();
            this.hotelresdataGridView = new System.Windows.Forms.DataGridView();
            this.label9 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.hotelresdataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // resmodmainmenubutton
            // 
            this.resmodmainmenubutton.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.resmodmainmenubutton.Location = new System.Drawing.Point(73, 429);
            this.resmodmainmenubutton.Name = "resmodmainmenubutton";
            this.resmodmainmenubutton.Size = new System.Drawing.Size(112, 23);
            this.resmodmainmenubutton.TabIndex = 3;
            this.resmodmainmenubutton.Text = "Back to Main Menu";
            this.resmodmainmenubutton.UseVisualStyleBackColor = true;
            this.resmodmainmenubutton.Click += new System.EventHandler(this.resmodmainmenubutton_Click);
            // 
            // backbutton
            // 
            this.backbutton.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.backbutton.Location = new System.Drawing.Point(210, 429);
            this.backbutton.Name = "backbutton";
            this.backbutton.Size = new System.Drawing.Size(75, 23);
            this.backbutton.TabIndex = 4;
            this.backbutton.Text = "Back";
            this.backbutton.UseVisualStyleBackColor = true;
            this.backbutton.Click += new System.EventHandler(this.backbutton_Click);
            // 
            // amountcomboBox
            // 
            this.amountcomboBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.amountcomboBox.FormattingEnabled = true;
            this.amountcomboBox.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10"});
            this.amountcomboBox.Location = new System.Drawing.Point(190, 336);
            this.amountcomboBox.Name = "amountcomboBox";
            this.amountcomboBox.Size = new System.Drawing.Size(241, 21);
            this.amountcomboBox.TabIndex = 54;
            this.amountcomboBox.SelectedIndexChanged += new System.EventHandler(this.amountcomboBox_SelectedIndexChanged);
            // 
            // amountlabel
            // 
            this.amountlabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.amountlabel.AutoSize = true;
            this.amountlabel.Location = new System.Drawing.Point(11, 339);
            this.amountlabel.Name = "amountlabel";
            this.amountlabel.Size = new System.Drawing.Size(133, 13);
            this.amountlabel.TabIndex = 53;
            this.amountlabel.Text = "Amount of rooms (Max: 10)";
            // 
            // hotelresstartdateTimePicker
            // 
            this.hotelresstartdateTimePicker.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.hotelresstartdateTimePicker.Location = new System.Drawing.Point(190, 178);
            this.hotelresstartdateTimePicker.Name = "hotelresstartdateTimePicker";
            this.hotelresstartdateTimePicker.Size = new System.Drawing.Size(241, 20);
            this.hotelresstartdateTimePicker.TabIndex = 52;
            this.hotelresstartdateTimePicker.ValueChanged += new System.EventHandler(this.hotelresstartdateTimePicker_ValueChanged);
            // 
            // hotelresenddateTimePicker
            // 
            this.hotelresenddateTimePicker.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.hotelresenddateTimePicker.Location = new System.Drawing.Point(190, 213);
            this.hotelresenddateTimePicker.Name = "hotelresenddateTimePicker";
            this.hotelresenddateTimePicker.Size = new System.Drawing.Size(241, 20);
            this.hotelresenddateTimePicker.TabIndex = 51;
            this.hotelresenddateTimePicker.ValueChanged += new System.EventHandler(this.hotelresenddateTimePicker_ValueChanged);
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(11, 219);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(107, 13);
            this.label1.TabIndex = 50;
            this.label1.Text = "Date Reserved (End)";
            // 
            // hoteldatereservedlabel
            // 
            this.hoteldatereservedlabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.hoteldatereservedlabel.AutoSize = true;
            this.hoteldatereservedlabel.Location = new System.Drawing.Point(11, 178);
            this.hoteldatereservedlabel.Name = "hoteldatereservedlabel";
            this.hoteldatereservedlabel.Size = new System.Drawing.Size(110, 13);
            this.hoteldatereservedlabel.TabIndex = 49;
            this.hoteldatereservedlabel.Text = "Date Reserved (Start)";
            // 
            // hotelreshotelpricelabel
            // 
            this.hotelreshotelpricelabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.hotelreshotelpricelabel.AutoSize = true;
            this.hotelreshotelpricelabel.Location = new System.Drawing.Point(11, 385);
            this.hotelreshotelpricelabel.Name = "hotelreshotelpricelabel";
            this.hotelreshotelpricelabel.Size = new System.Drawing.Size(59, 13);
            this.hotelreshotelpricelabel.TabIndex = 48;
            this.hotelreshotelpricelabel.Text = "Hotel Price";
            // 
            // hotelrespricetextBox
            // 
            this.hotelrespricetextBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.hotelrespricetextBox.Location = new System.Drawing.Point(190, 382);
            this.hotelrespricetextBox.Name = "hotelrespricetextBox";
            this.hotelrespricetextBox.Size = new System.Drawing.Size(241, 20);
            this.hotelrespricetextBox.TabIndex = 47;
            // 
            // hotelrescusidtextBox
            // 
            this.hotelrescusidtextBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.hotelrescusidtextBox.Location = new System.Drawing.Point(190, 137);
            this.hotelrescusidtextBox.Name = "hotelrescusidtextBox";
            this.hotelrescusidtextBox.Size = new System.Drawing.Size(241, 20);
            this.hotelrescusidtextBox.TabIndex = 46;
            // 
            // hotelrestextBox
            // 
            this.hotelrestextBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.hotelrestextBox.Location = new System.Drawing.Point(190, 58);
            this.hotelrestextBox.Name = "hotelrestextBox";
            this.hotelrestextBox.Size = new System.Drawing.Size(241, 20);
            this.hotelrestextBox.TabIndex = 45;
            // 
            // hotelreshotelidtextBox
            // 
            this.hotelreshotelidtextBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.hotelreshotelidtextBox.Location = new System.Drawing.Point(190, 97);
            this.hotelreshotelidtextBox.Name = "hotelreshotelidtextBox";
            this.hotelreshotelidtextBox.Size = new System.Drawing.Size(241, 20);
            this.hotelreshotelidtextBox.TabIndex = 44;
            // 
            // hotelresroomtypelabel
            // 
            this.hotelresroomtypelabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.hotelresroomtypelabel.AutoSize = true;
            this.hotelresroomtypelabel.Location = new System.Drawing.Point(11, 298);
            this.hotelresroomtypelabel.Name = "hotelresroomtypelabel";
            this.hotelresroomtypelabel.Size = new System.Drawing.Size(62, 13);
            this.hotelresroomtypelabel.TabIndex = 43;
            this.hotelresroomtypelabel.Text = "Room Type";
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(11, 140);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(153, 13);
            this.label2.TabIndex = 42;
            this.label2.Text = "Customer IC/ Passport Number";
            // 
            // label3
            // 
            this.label3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(11, 61);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(78, 13);
            this.label3.TabIndex = 41;
            this.label3.Text = "Reservation ID";
            // 
            // hotelreshotelnamelabel
            // 
            this.hotelreshotelnamelabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.hotelreshotelnamelabel.AutoSize = true;
            this.hotelreshotelnamelabel.Location = new System.Drawing.Point(11, 257);
            this.hotelreshotelnamelabel.Name = "hotelreshotelnamelabel";
            this.hotelreshotelnamelabel.Size = new System.Drawing.Size(63, 13);
            this.hotelreshotelnamelabel.TabIndex = 40;
            this.hotelreshotelnamelabel.Text = "Hotel Name";
            // 
            // hotelreshotelidlabel
            // 
            this.hotelreshotelidlabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.hotelreshotelidlabel.AutoSize = true;
            this.hotelreshotelidlabel.Location = new System.Drawing.Point(11, 100);
            this.hotelreshotelidlabel.Name = "hotelreshotelidlabel";
            this.hotelreshotelidlabel.Size = new System.Drawing.Size(46, 13);
            this.hotelreshotelidlabel.TabIndex = 39;
            this.hotelreshotelidlabel.Text = "Hotel ID";
            // 
            // hotelresroomtypecomboBox
            // 
            this.hotelresroomtypecomboBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.hotelresroomtypecomboBox.FormattingEnabled = true;
            this.hotelresroomtypecomboBox.Items.AddRange(new object[] {
            "Single",
            "Double",
            "Family Suite"});
            this.hotelresroomtypecomboBox.Location = new System.Drawing.Point(190, 295);
            this.hotelresroomtypecomboBox.Name = "hotelresroomtypecomboBox";
            this.hotelresroomtypecomboBox.Size = new System.Drawing.Size(241, 21);
            this.hotelresroomtypecomboBox.TabIndex = 38;
            this.hotelresroomtypecomboBox.SelectedIndexChanged += new System.EventHandler(this.hotelresroomtypecomboBox_SelectedIndexChanged);
            // 
            // hotelreshotelnamecomboBox
            // 
            this.hotelreshotelnamecomboBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.hotelreshotelnamecomboBox.FormattingEnabled = true;
            this.hotelreshotelnamecomboBox.Items.AddRange(new object[] {
            "(Cameron Highlands) Cameron Highlands Resort",
            "(Cameron Highlands) Century Pines Resort ",
            "(Langkawi) Berjaya Langkawi Resort",
            "(Langkawi) Adya Hotel Langkawi",
            "(Tioman) Tunamaya Beach & Spa Resort",
            "(Tioman) Berjaya Tioman Resort"});
            this.hotelreshotelnamecomboBox.Location = new System.Drawing.Point(190, 254);
            this.hotelreshotelnamecomboBox.Name = "hotelreshotelnamecomboBox";
            this.hotelreshotelnamecomboBox.Size = new System.Drawing.Size(241, 21);
            this.hotelreshotelnamecomboBox.TabIndex = 37;
            this.hotelreshotelnamecomboBox.SelectedIndexChanged += new System.EventHandler(this.hotelreshotelnamecomboBox_SelectedIndexChanged);
            // 
            // updatebutton
            // 
            this.updatebutton.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.updatebutton.Location = new System.Drawing.Point(310, 429);
            this.updatebutton.Name = "updatebutton";
            this.updatebutton.Size = new System.Drawing.Size(75, 23);
            this.updatebutton.TabIndex = 55;
            this.updatebutton.Text = "Update";
            this.updatebutton.UseVisualStyleBackColor = true;
            this.updatebutton.Click += new System.EventHandler(this.updatebutton_Click);
            // 
            // displayholiresbutton
            // 
            this.displayholiresbutton.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.displayholiresbutton.Location = new System.Drawing.Point(637, 423);
            this.displayholiresbutton.Name = "displayholiresbutton";
            this.displayholiresbutton.Size = new System.Drawing.Size(133, 40);
            this.displayholiresbutton.TabIndex = 79;
            this.displayholiresbutton.Text = "Display Hotel Reservation Table";
            this.displayholiresbutton.UseVisualStyleBackColor = true;
            this.displayholiresbutton.Click += new System.EventHandler(this.displayholiresbutton_Click);
            // 
            // hotelresdataGridView
            // 
            this.hotelresdataGridView.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.hotelresdataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.hotelresdataGridView.Location = new System.Drawing.Point(443, 61);
            this.hotelresdataGridView.Name = "hotelresdataGridView";
            this.hotelresdataGridView.Size = new System.Drawing.Size(521, 341);
            this.hotelresdataGridView.TabIndex = 78;
            // 
            // label9
            // 
            this.label9.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Modern No. 20", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(50, 23);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(816, 17);
            this.label9.TabIndex = 80;
            this.label9.Text = "This Interface is to insert or update Reservation Information of Customers (Hotel" +
    ").  All fields need to be filled up.";
            // 
            // hotelresmod
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(976, 475);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.displayholiresbutton);
            this.Controls.Add(this.hotelresdataGridView);
            this.Controls.Add(this.updatebutton);
            this.Controls.Add(this.amountcomboBox);
            this.Controls.Add(this.amountlabel);
            this.Controls.Add(this.hotelresstartdateTimePicker);
            this.Controls.Add(this.hotelresenddateTimePicker);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.hoteldatereservedlabel);
            this.Controls.Add(this.hotelreshotelpricelabel);
            this.Controls.Add(this.hotelrespricetextBox);
            this.Controls.Add(this.hotelrescusidtextBox);
            this.Controls.Add(this.hotelrestextBox);
            this.Controls.Add(this.hotelreshotelidtextBox);
            this.Controls.Add(this.hotelresroomtypelabel);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.hotelreshotelnamelabel);
            this.Controls.Add(this.hotelreshotelidlabel);
            this.Controls.Add(this.hotelresroomtypecomboBox);
            this.Controls.Add(this.hotelreshotelnamecomboBox);
            this.Controls.Add(this.backbutton);
            this.Controls.Add(this.resmodmainmenubutton);
            this.Name = "hotelresmod";
            this.Text = "Hotel Reservation Modification";
            ((System.ComponentModel.ISupportInitialize)(this.hotelresdataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button resmodmainmenubutton;
        private System.Windows.Forms.Button backbutton;
        private System.Windows.Forms.ComboBox amountcomboBox;
        private System.Windows.Forms.Label amountlabel;
        private System.Windows.Forms.DateTimePicker hotelresstartdateTimePicker;
        private System.Windows.Forms.DateTimePicker hotelresenddateTimePicker;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label hoteldatereservedlabel;
        private System.Windows.Forms.Label hotelreshotelpricelabel;
        private System.Windows.Forms.TextBox hotelrespricetextBox;
        private System.Windows.Forms.TextBox hotelrescusidtextBox;
        private System.Windows.Forms.TextBox hotelrestextBox;
        private System.Windows.Forms.TextBox hotelreshotelidtextBox;
        private System.Windows.Forms.Label hotelresroomtypelabel;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label hotelreshotelnamelabel;
        private System.Windows.Forms.Label hotelreshotelidlabel;
        private System.Windows.Forms.ComboBox hotelresroomtypecomboBox;
        private System.Windows.Forms.ComboBox hotelreshotelnamecomboBox;
        private System.Windows.Forms.Button updatebutton;
        private System.Windows.Forms.Button displayholiresbutton;
        private System.Windows.Forms.DataGridView hotelresdataGridView;
        private System.Windows.Forms.Label label9;
    }
}