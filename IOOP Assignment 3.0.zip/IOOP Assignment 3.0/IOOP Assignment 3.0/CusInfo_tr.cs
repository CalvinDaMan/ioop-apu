﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace IOOP_Assignment_3._0
{
    public partial class CusInfo_tr : Form
    {
        OleDbConnection cnnOLEDB = new OleDbConnection();
        OleDbCommand cmdInsert = new OleDbCommand();
        OleDbCommand cmdDelete = new OleDbCommand();
        OleDbCommand cmdUpdate = new OleDbCommand();
        OleDbCommand cmdSearch = new OleDbCommand();
        public CusInfo_tr()
        {
            InitializeComponent();
        }

        private void mainmenubuttontr_Click(object sender, EventArgs e)
        {
            const string message = "Do you want to go to MAIN MENU?";
            const string caption = "MAIN MENU";
            var result = MessageBox.Show(message, caption, MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes)
            {
                MainMenu newForm = new MainMenu();
                newForm.Show();
                this.Hide();
            }
        }

        private void backtoresbuttontr_Click(object sender, EventArgs e)
        {
            const string message = "Do you want to go to RESERVATION?";
            const string caption = "RESERVATION";
            var result = MessageBox.Show(message, caption, MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes)
            {
                Reservation newForm = new Reservation();
                newForm.Show();
                this.Hide();
            }
        }

        private void confirmbuttontr_Click(object sender, EventArgs e)
        {
            try
            {

                DateTime bookingdatetr = DateTime.Parse(cusinfotourresdateTimePicker.Text);
                using (OleDbConnection conn = new OleDbConnection())
                {

                    conn.ConnectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=IOOPDb.accdb";
                    string sql = string.Format("INSERT INTO cusinfotourr(customerID, customername, address, email, contact, bookingdate) VALUES('{0}','{1}','{2}','{3}','{4}','{5}')", cusidtextBoxtr .Text, cusnametextBoxtr .Text, cusaddresstextBoxtr.Text, emailtextBoxtr.Text, cuscontacttextBoxtr.Text, bookingdatetr);

                    using (OleDbCommand cmd = new OleDbCommand(sql, conn))
                    {
                        conn.Open();
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Insertion successful.");
                        touridlabel newForm = new touridlabel();
                        newForm.Show();
                        this.Hide();

                    }

                }
            }
            catch
            {
                MessageBox.Show("Insertion unsuccessful. Make sure all the fields are in the correct format and filled.");
            } //to tell users to input the info accordingly
        }

        private void CusInfo_tr_Load(object sender, EventArgs e)
        {
            cnnOLEDB.ConnectionString = "Provider =Microsoft.ACE.OLEDB.12.0; Data Source =IOOPDb.accdb";
            cnnOLEDB.Open();
        }
    }
}
