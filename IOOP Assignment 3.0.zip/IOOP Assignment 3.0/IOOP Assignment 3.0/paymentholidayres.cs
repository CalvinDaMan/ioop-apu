﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace IOOP_Assignment_3._0
{
    public partial class paymentholidayres : Form
    {
        OleDbConnection cnnOLEDB = new OleDbConnection();
        OleDbCommand cmdInsert = new OleDbCommand();
        OleDbCommand cmdDelete = new OleDbCommand();
        OleDbCommand cmdUpdate = new OleDbCommand();
        OleDbCommand cmdSearch = new OleDbCommand();
        double depositamount, remainingamount;
        public paymentholidayres()
        {
            InitializeComponent();
        }

        private void mainmenubutton_Click(object sender, EventArgs e)
        {
            const string message = "Do you want to go to MAIN MENU?";
            const string caption = "MAIN MENU";
            var result = MessageBox.Show(message, caption, MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes)
            {
                MainMenu newForm = new MainMenu();
                newForm.Show();
                this.Hide();
            }
        }

        private void backbutton_Click(object sender, EventArgs e)
        {
            payment newForm = new payment();
            newForm.Show();
            this.Hide();
        }

        private void displaybutton_Click(object sender, EventArgs e)
        {
            string connectionString = "Provider =Microsoft.ACE.OLEDB.12.0; Data Source =IOOPDb.accdb";
            string sql = "SELECT * FROM paymentholidayres";
            OleDbConnection connection = new OleDbConnection(connectionString);
            OleDbDataAdapter dataadapter = new OleDbDataAdapter(sql, connection);
            DataSet ds = new DataSet();
            connection.Open();
            dataadapter.Fill(ds, "paymentholires_table");
            connection.Close();
            holiresdataGridView.DataSource = ds;
            holiresdataGridView.DataMember = "paymentholires_table";
        }

        private void paymentholidayres_Load(object sender, EventArgs e)
        {
            cnnOLEDB.ConnectionString = "Provider =Microsoft.ACE.OLEDB.12.0; Data Source =IOOPDb.accdb";
            cnnOLEDB.Open();
        }

        private void updatebutton_Click(object sender, EventArgs e)
        {
            const string message = "Do you want to UPDATE INFO?";
            const string caption = "INFO";
            var result = MessageBox.Show(message, caption, MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes)
            {
                if (holidaypaymentidtextBox.Text != "" && remainamountstatuscomboBox.SelectedIndex > -1 && addchargesstatuscomboBox.SelectedIndex > -1)//update when id is input and statuses are updated
                {
                    try
                    {
                        if (double.TryParse(depositamounttextBox.Text, out depositamount) && double.TryParse(remainingamounttextBox.Text, out remainingamount))
                        {
                            String query1 = "UPDATE paymentholidayres SET depositprice=?, depositstatus= ?, holidayremainprice=?, holidayremainstatus=?, additionalcharges=?, additionalchargesstatus=? WHERE holidaypaymentID = ?";
                            using (OleDbConnection conn = new OleDbConnection())
                            {
                                conn.ConnectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=IOOPDb.accdb";
                                OleDbCommand cmd = new OleDbCommand(query1, conn);
                                cmd.Parameters.AddWithValue("@depositprice", depositamounttextBox.Text);
                                cmd.Parameters.AddWithValue("@depositstatus", depositstatuscomboBox.SelectedItem.ToString());
                                cmd.Parameters.AddWithValue("@holidayremainprice", remainingamounttextBox.Text);
                                cmd.Parameters.AddWithValue("@holidayremainstatus", remainamountstatuscomboBox.SelectedItem.ToString());
                                cmd.Parameters.AddWithValue("@additionalcharges", addchargescomboBox.SelectedItem.ToString());
                                cmd.Parameters.AddWithValue("@additionalchargesstatus", addchargesstatuscomboBox.SelectedItem.ToString());
                                cmd.Parameters.AddWithValue("@holidaypaymentID", holidaypaymentidtextBox.Text);
                                conn.Open();
                                cmd.ExecuteNonQuery();
                                MessageBox.Show("Update successful.");
                                conn.Close();
                            }
                        }
                    }
                    catch
                    {
                        MessageBox.Show("Please ensure all fields are inserted.");
                    }
                }
                else
                {
                    MessageBox.Show("Please ensure all fields are inserted.");
                }
            }
        }

        private void confirmbutton_Click(object sender, EventArgs e)
        {
            const string message = "Do you want to INSERT INFO?";
            const string caption = "INFO";
            var result = MessageBox.Show(message, caption, MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes)
            {
                try
                {
                    if (holidaypaymentidtextBox.Text != "" && cusidtextBox.Text != "" && holidayreservationidtextBox.Text != "" && depositamounttextBox.Text != "" && depositstatuscomboBox.SelectedIndex > -1 && remainingamounttextBox.Text != "" && remainamountstatuscomboBox.SelectedIndex > -1 && addchargescomboBox.SelectedIndex > -1 && addchargesstatuscomboBox.SelectedIndex > -1)
                    {
                        if (double.TryParse(depositamounttextBox.Text, out depositamount) && double.TryParse(remainingamounttextBox.Text, out remainingamount))//prevent text from being acepted into db 
                        {
                            using (OleDbConnection conn = new OleDbConnection())
                            {
                                conn.ConnectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=IOOPDb.accdb";
                                string sql = string.Format("INSERT INTO paymentholidayres(holidaypaymentID, depositprice, depositstatus, holidayremainprice ,holidayremainstatus, additionalcharges,additionalchargesstatus, holireservationid, customerid) VALUES('{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}','{8}')", holidaypaymentidtextBox.Text, depositamounttextBox.Text, depositstatuscomboBox.SelectedItem, remainingamounttextBox.Text, remainamountstatuscomboBox.SelectedItem, addchargescomboBox.SelectedItem, addchargesstatuscomboBox.SelectedItem, holidayreservationidtextBox.Text, cusidtextBox.Text);

                                using (OleDbCommand cmd = new OleDbCommand(sql, conn))
                                {
                                    conn.Open();
                                    cmd.ExecuteNonQuery();
                                    MessageBox.Show("Insertion successful.");
                                }
                            }
                        }
                        else
                        {
                            MessageBox.Show("Please enter amount in numbers.");
                        }
                    }
                    else
                    {
                        MessageBox.Show("Please ensure that the fields are not empty.");
                    }
                }
                catch
                {
                    MessageBox.Show("Please ensure that the fields are not empty and data is of correct format.");
                }
            }
        }
    }
}
