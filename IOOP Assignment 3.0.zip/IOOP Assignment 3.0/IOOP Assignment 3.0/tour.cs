﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IOOP_Assignment_3._0
{
    class tour
    {
        private string _tourname;
        private double _tourprice;
        private double _dayreserved;
        public string tourname
        {
            get
            {
                return _tourname;
            }
            set
            {
                _tourname = value;
            }
        }
        public double tourprice
        {
            get
            {
                return _tourprice;
            }
            set
            {
                _tourprice = value;
            }
        }
        public double dayreserved
        {
            get
            {
                return _dayreserved;
            }
            set
            {
                _dayreserved = value;
            }
        }
        public tour(string tourn,double tourp, double dayr)
        {
            _tourname = tourn;
            _tourprice = tourp;
            _dayreserved = dayr;
        }

        public double tprice(double dayreserved, double tourprice)
        {
            return dayreserved * tourprice;
        }

    }
   
}
