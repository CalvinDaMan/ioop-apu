﻿namespace IOOP_Assignment_3._0
{
    partial class CusInfo_hr
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.backtoresbutton_hotelr = new System.Windows.Forms.Button();
            this.mainmenubutton_hotelr = new System.Windows.Forms.Button();
            this.cuscontacttextBox_hotelr = new System.Windows.Forms.TextBox();
            this.emailtextBox_hotelr = new System.Windows.Forms.TextBox();
            this.cusaddresstextBox_hotelr = new System.Windows.Forms.TextBox();
            this.cusnametextBox_hotelr = new System.Windows.Forms.TextBox();
            this.cusidtextBox_hotelr = new System.Windows.Forms.TextBox();
            this.confirmbutton_hotelr = new System.Windows.Forms.Button();
            this.dateofbookinglabel_hotelr = new System.Windows.Forms.Label();
            this.cuscontactlabel_hotelr = new System.Windows.Forms.Label();
            this.emaillabel_hotelr = new System.Windows.Forms.Label();
            this.addresslabel_hotelr = new System.Windows.Forms.Label();
            this.cusnamelabel_hotelr = new System.Windows.Forms.Label();
            this.cusidlabel_hotelr = new System.Windows.Forms.Label();
            this.cusinfolabel_hotelr = new System.Windows.Forms.Label();
            this.cusinfohotelresdateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.SuspendLayout();
            // 
            // backtoresbutton_hotelr
            // 
            this.backtoresbutton_hotelr.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.backtoresbutton_hotelr.Location = new System.Drawing.Point(232, 287);
            this.backtoresbutton_hotelr.Name = "backtoresbutton_hotelr";
            this.backtoresbutton_hotelr.Size = new System.Drawing.Size(75, 35);
            this.backtoresbutton_hotelr.TabIndex = 31;
            this.backtoresbutton_hotelr.Text = "Back to Reservation";
            this.backtoresbutton_hotelr.UseVisualStyleBackColor = true;
            this.backtoresbutton_hotelr.Click += new System.EventHandler(this.backtoresbutton_hotelr_Click);
            // 
            // mainmenubutton_hotelr
            // 
            this.mainmenubutton_hotelr.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.mainmenubutton_hotelr.Location = new System.Drawing.Point(73, 287);
            this.mainmenubutton_hotelr.Name = "mainmenubutton_hotelr";
            this.mainmenubutton_hotelr.Size = new System.Drawing.Size(114, 23);
            this.mainmenubutton_hotelr.TabIndex = 30;
            this.mainmenubutton_hotelr.Text = "Back to main menu";
            this.mainmenubutton_hotelr.UseVisualStyleBackColor = true;
            this.mainmenubutton_hotelr.Click += new System.EventHandler(this.mainmenubutton_hotelr_Click);
            // 
            // cuscontacttextBox_hotelr
            // 
            this.cuscontacttextBox_hotelr.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.cuscontacttextBox_hotelr.Location = new System.Drawing.Point(208, 201);
            this.cuscontacttextBox_hotelr.Name = "cuscontacttextBox_hotelr";
            this.cuscontacttextBox_hotelr.Size = new System.Drawing.Size(241, 20);
            this.cuscontacttextBox_hotelr.TabIndex = 28;
            // 
            // emailtextBox_hotelr
            // 
            this.emailtextBox_hotelr.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.emailtextBox_hotelr.Location = new System.Drawing.Point(208, 163);
            this.emailtextBox_hotelr.Name = "emailtextBox_hotelr";
            this.emailtextBox_hotelr.Size = new System.Drawing.Size(241, 20);
            this.emailtextBox_hotelr.TabIndex = 27;
            // 
            // cusaddresstextBox_hotelr
            // 
            this.cusaddresstextBox_hotelr.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.cusaddresstextBox_hotelr.Location = new System.Drawing.Point(208, 128);
            this.cusaddresstextBox_hotelr.Name = "cusaddresstextBox_hotelr";
            this.cusaddresstextBox_hotelr.Size = new System.Drawing.Size(241, 20);
            this.cusaddresstextBox_hotelr.TabIndex = 26;
            // 
            // cusnametextBox_hotelr
            // 
            this.cusnametextBox_hotelr.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.cusnametextBox_hotelr.Location = new System.Drawing.Point(208, 90);
            this.cusnametextBox_hotelr.Name = "cusnametextBox_hotelr";
            this.cusnametextBox_hotelr.Size = new System.Drawing.Size(241, 20);
            this.cusnametextBox_hotelr.TabIndex = 25;
            // 
            // cusidtextBox_hotelr
            // 
            this.cusidtextBox_hotelr.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.cusidtextBox_hotelr.Location = new System.Drawing.Point(208, 55);
            this.cusidtextBox_hotelr.Name = "cusidtextBox_hotelr";
            this.cusidtextBox_hotelr.Size = new System.Drawing.Size(241, 20);
            this.cusidtextBox_hotelr.TabIndex = 24;
            // 
            // confirmbutton_hotelr
            // 
            this.confirmbutton_hotelr.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.confirmbutton_hotelr.Location = new System.Drawing.Point(355, 287);
            this.confirmbutton_hotelr.Name = "confirmbutton_hotelr";
            this.confirmbutton_hotelr.Size = new System.Drawing.Size(75, 23);
            this.confirmbutton_hotelr.TabIndex = 23;
            this.confirmbutton_hotelr.Text = "Confirm";
            this.confirmbutton_hotelr.UseVisualStyleBackColor = true;
            this.confirmbutton_hotelr.Click += new System.EventHandler(this.confirmbutton_hotelr_Click);
            // 
            // dateofbookinglabel_hotelr
            // 
            this.dateofbookinglabel_hotelr.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.dateofbookinglabel_hotelr.AutoSize = true;
            this.dateofbookinglabel_hotelr.Location = new System.Drawing.Point(32, 241);
            this.dateofbookinglabel_hotelr.Name = "dateofbookinglabel_hotelr";
            this.dateofbookinglabel_hotelr.Size = new System.Drawing.Size(140, 13);
            this.dateofbookinglabel_hotelr.TabIndex = 22;
            this.dateofbookinglabel_hotelr.Text = "Date of booking (dd/mm/yy)";
            // 
            // cuscontactlabel_hotelr
            // 
            this.cuscontactlabel_hotelr.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.cuscontactlabel_hotelr.AutoSize = true;
            this.cuscontactlabel_hotelr.Location = new System.Drawing.Point(32, 204);
            this.cuscontactlabel_hotelr.Name = "cuscontactlabel_hotelr";
            this.cuscontactlabel_hotelr.Size = new System.Drawing.Size(90, 13);
            this.cuscontactlabel_hotelr.TabIndex = 21;
            this.cuscontactlabel_hotelr.Text = "Customer contact";
            // 
            // emaillabel_hotelr
            // 
            this.emaillabel_hotelr.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.emaillabel_hotelr.AutoSize = true;
            this.emaillabel_hotelr.Location = new System.Drawing.Point(32, 166);
            this.emaillabel_hotelr.Name = "emaillabel_hotelr";
            this.emaillabel_hotelr.Size = new System.Drawing.Size(32, 13);
            this.emaillabel_hotelr.TabIndex = 20;
            this.emaillabel_hotelr.Text = "Email";
            // 
            // addresslabel_hotelr
            // 
            this.addresslabel_hotelr.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.addresslabel_hotelr.AutoSize = true;
            this.addresslabel_hotelr.Location = new System.Drawing.Point(32, 131);
            this.addresslabel_hotelr.Name = "addresslabel_hotelr";
            this.addresslabel_hotelr.Size = new System.Drawing.Size(92, 13);
            this.addresslabel_hotelr.TabIndex = 19;
            this.addresslabel_hotelr.Text = "Customer Address";
            // 
            // cusnamelabel_hotelr
            // 
            this.cusnamelabel_hotelr.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.cusnamelabel_hotelr.AutoSize = true;
            this.cusnamelabel_hotelr.Location = new System.Drawing.Point(32, 93);
            this.cusnamelabel_hotelr.Name = "cusnamelabel_hotelr";
            this.cusnamelabel_hotelr.Size = new System.Drawing.Size(82, 13);
            this.cusnamelabel_hotelr.TabIndex = 18;
            this.cusnamelabel_hotelr.Text = "Customer Name";
            // 
            // cusidlabel_hotelr
            // 
            this.cusidlabel_hotelr.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.cusidlabel_hotelr.AutoSize = true;
            this.cusidlabel_hotelr.Location = new System.Drawing.Point(32, 58);
            this.cusidlabel_hotelr.Name = "cusidlabel_hotelr";
            this.cusidlabel_hotelr.Size = new System.Drawing.Size(153, 13);
            this.cusidlabel_hotelr.TabIndex = 17;
            this.cusidlabel_hotelr.Text = "Customer IC/ Passport Number";
            // 
            // cusinfolabel_hotelr
            // 
            this.cusinfolabel_hotelr.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.cusinfolabel_hotelr.AutoSize = true;
            this.cusinfolabel_hotelr.Font = new System.Drawing.Font("Segoe UI Symbol", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cusinfolabel_hotelr.Location = new System.Drawing.Point(70, 25);
            this.cusinfolabel_hotelr.Name = "cusinfolabel_hotelr";
            this.cusinfolabel_hotelr.Size = new System.Drawing.Size(341, 21);
            this.cusinfolabel_hotelr.TabIndex = 16;
            this.cusinfolabel_hotelr.Text = "Customer Information (Hotel Reservation)";
            // 
            // cusinfohotelresdateTimePicker
            // 
            this.cusinfohotelresdateTimePicker.Location = new System.Drawing.Point(212, 238);
            this.cusinfohotelresdateTimePicker.Name = "cusinfohotelresdateTimePicker";
            this.cusinfohotelresdateTimePicker.Size = new System.Drawing.Size(239, 20);
            this.cusinfohotelresdateTimePicker.TabIndex = 32;
            // 
            // CusInfo_hr
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(501, 347);
            this.Controls.Add(this.cusinfohotelresdateTimePicker);
            this.Controls.Add(this.backtoresbutton_hotelr);
            this.Controls.Add(this.mainmenubutton_hotelr);
            this.Controls.Add(this.cuscontacttextBox_hotelr);
            this.Controls.Add(this.emailtextBox_hotelr);
            this.Controls.Add(this.cusaddresstextBox_hotelr);
            this.Controls.Add(this.cusnametextBox_hotelr);
            this.Controls.Add(this.cusidtextBox_hotelr);
            this.Controls.Add(this.confirmbutton_hotelr);
            this.Controls.Add(this.dateofbookinglabel_hotelr);
            this.Controls.Add(this.cuscontactlabel_hotelr);
            this.Controls.Add(this.emaillabel_hotelr);
            this.Controls.Add(this.addresslabel_hotelr);
            this.Controls.Add(this.cusnamelabel_hotelr);
            this.Controls.Add(this.cusidlabel_hotelr);
            this.Controls.Add(this.cusinfolabel_hotelr);
            this.Name = "CusInfo_hr";
            this.Text = "Cus Info (Hotel Reservation)";
            this.Load += new System.EventHandler(this.CusInfo_hr_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button backtoresbutton_hotelr;
        private System.Windows.Forms.Button mainmenubutton_hotelr;
        private System.Windows.Forms.TextBox cuscontacttextBox_hotelr;
        private System.Windows.Forms.TextBox emailtextBox_hotelr;
        private System.Windows.Forms.TextBox cusaddresstextBox_hotelr;
        private System.Windows.Forms.TextBox cusnametextBox_hotelr;
        private System.Windows.Forms.TextBox cusidtextBox_hotelr;
        private System.Windows.Forms.Button confirmbutton_hotelr;
        private System.Windows.Forms.Label dateofbookinglabel_hotelr;
        private System.Windows.Forms.Label cuscontactlabel_hotelr;
        private System.Windows.Forms.Label emaillabel_hotelr;
        private System.Windows.Forms.Label addresslabel_hotelr;
        private System.Windows.Forms.Label cusnamelabel_hotelr;
        private System.Windows.Forms.Label cusidlabel_hotelr;
        private System.Windows.Forms.Label cusinfolabel_hotelr;
        private System.Windows.Forms.DateTimePicker cusinfohotelresdateTimePicker;
    }
}