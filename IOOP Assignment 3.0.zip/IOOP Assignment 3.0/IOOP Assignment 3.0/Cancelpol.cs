﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IOOP_Assignment_3._0
{
    public partial class Cancelpol : Form
    {
        public Cancelpol()
        {
            InitializeComponent();
        }

        private void mainmenubutton_Click(object sender, EventArgs e)
        {
            const string message = "Do you want to go to MAIN MENU?";
            const string caption = "MAIN MENU";
            var result = MessageBox.Show(message, caption, MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes)
            {
                MainMenu newForm = new MainMenu();
                newForm.Show();
                this.Hide();
            }
        }
    }
}
