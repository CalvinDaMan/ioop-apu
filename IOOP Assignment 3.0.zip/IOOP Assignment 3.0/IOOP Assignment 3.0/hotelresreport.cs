﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace IOOP_Assignment_3._0
{
    public partial class hotelresreport : Form
    {
        public hotelresreport()
        {
            InitializeComponent();
        }

        private void mainmenubutton_Click(object sender, EventArgs e)
        {
            const string message = "Do you want to go to MAIN MENU?";
            const string caption = "MAIN MENU";
            var result = MessageBox.Show(message, caption, MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes)
            {
                MainMenu newForm = new MainMenu();
                newForm.Show();
                this.Hide();
            }
        }

        private void displaybutton_Click(object sender, EventArgs e)
        {
            string connectionString = "Provider =Microsoft.ACE.OLEDB.12.0; Data Source =IOOPDb.accdb";
            string sql = "SELECT * FROM hotelres";
            OleDbConnection connection = new OleDbConnection(connectionString);
            OleDbDataAdapter dataadapter = new OleDbDataAdapter(sql, connection);
            DataSet ds = new DataSet();
            connection.Open();
            dataadapter.Fill(ds, "hotelres_table");
            connection.Close();
            hotelresdatagrid.DataSource = ds;
            hotelresdatagrid.DataMember = "hotelres_table";
        }

        private void backbutton_Click(object sender, EventArgs e)
        {
            ReportGen2 newForm = new ReportGen2();
            newForm.Show();
            this.Hide();
        }
    }
}
