﻿namespace IOOP_Assignment_3._0
{
    partial class paymentholidayres
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.mainmenubutton = new System.Windows.Forms.Button();
            this.confirmbutton = new System.Windows.Forms.Button();
            this.backbutton = new System.Windows.Forms.Button();
            this.cusidtextBox = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.depositstatuscomboBox = new System.Windows.Forms.ComboBox();
            this.remainamountstatuscomboBox = new System.Windows.Forms.ComboBox();
            this.addchargesstatuscomboBox = new System.Windows.Forms.ComboBox();
            this.addchargescomboBox = new System.Windows.Forms.ComboBox();
            this.holidayreservationidtextBox = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.remainingamounttextBox = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.depositamounttextBox = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.holidaypaymentidtextBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.displaybutton = new System.Windows.Forms.Button();
            this.holiresdataGridView = new System.Windows.Forms.DataGridView();
            this.updatebutton = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.holiresdataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // mainmenubutton
            // 
            this.mainmenubutton.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.mainmenubutton.Location = new System.Drawing.Point(317, 449);
            this.mainmenubutton.Name = "mainmenubutton";
            this.mainmenubutton.Size = new System.Drawing.Size(75, 23);
            this.mainmenubutton.TabIndex = 1;
            this.mainmenubutton.Text = "Main Menu";
            this.mainmenubutton.UseVisualStyleBackColor = true;
            this.mainmenubutton.Click += new System.EventHandler(this.mainmenubutton_Click);
            // 
            // confirmbutton
            // 
            this.confirmbutton.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.confirmbutton.Location = new System.Drawing.Point(163, 449);
            this.confirmbutton.Name = "confirmbutton";
            this.confirmbutton.Size = new System.Drawing.Size(67, 23);
            this.confirmbutton.TabIndex = 5;
            this.confirmbutton.Text = "Insert";
            this.confirmbutton.UseVisualStyleBackColor = true;
            this.confirmbutton.Click += new System.EventHandler(this.confirmbutton_Click);
            // 
            // backbutton
            // 
            this.backbutton.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.backbutton.Location = new System.Drawing.Point(236, 449);
            this.backbutton.Name = "backbutton";
            this.backbutton.Size = new System.Drawing.Size(75, 23);
            this.backbutton.TabIndex = 7;
            this.backbutton.Text = "Back";
            this.backbutton.UseVisualStyleBackColor = true;
            this.backbutton.Click += new System.EventHandler(this.backbutton_Click);
            // 
            // cusidtextBox
            // 
            this.cusidtextBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.cusidtextBox.Location = new System.Drawing.Point(236, 84);
            this.cusidtextBox.Name = "cusidtextBox";
            this.cusidtextBox.Size = new System.Drawing.Size(169, 20);
            this.cusidtextBox.TabIndex = 29;
            // 
            // label10
            // 
            this.label10.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(24, 87);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(68, 13);
            this.label10.TabIndex = 28;
            this.label10.Text = "Customer ID:";
            // 
            // depositstatuscomboBox
            // 
            this.depositstatuscomboBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.depositstatuscomboBox.FormattingEnabled = true;
            this.depositstatuscomboBox.Items.AddRange(new object[] {
            "Paid",
            "Unpaid"});
            this.depositstatuscomboBox.Location = new System.Drawing.Point(236, 215);
            this.depositstatuscomboBox.Name = "depositstatuscomboBox";
            this.depositstatuscomboBox.Size = new System.Drawing.Size(169, 21);
            this.depositstatuscomboBox.TabIndex = 27;
            // 
            // remainamountstatuscomboBox
            // 
            this.remainamountstatuscomboBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.remainamountstatuscomboBox.FormattingEnabled = true;
            this.remainamountstatuscomboBox.Items.AddRange(new object[] {
            "Paid",
            "Unpaid"});
            this.remainamountstatuscomboBox.Location = new System.Drawing.Point(236, 301);
            this.remainamountstatuscomboBox.Name = "remainamountstatuscomboBox";
            this.remainamountstatuscomboBox.Size = new System.Drawing.Size(169, 21);
            this.remainamountstatuscomboBox.TabIndex = 26;
            // 
            // addchargesstatuscomboBox
            // 
            this.addchargesstatuscomboBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.addchargesstatuscomboBox.FormattingEnabled = true;
            this.addchargesstatuscomboBox.Items.AddRange(new object[] {
            "Paid",
            "Unpaid",
            "None"});
            this.addchargesstatuscomboBox.Location = new System.Drawing.Point(236, 392);
            this.addchargesstatuscomboBox.Name = "addchargesstatuscomboBox";
            this.addchargesstatuscomboBox.Size = new System.Drawing.Size(169, 21);
            this.addchargesstatuscomboBox.TabIndex = 25;
            // 
            // addchargescomboBox
            // 
            this.addchargescomboBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.addchargescomboBox.FormattingEnabled = true;
            this.addchargescomboBox.Items.AddRange(new object[] {
            "RM 0.00",
            "RM 50.00"});
            this.addchargescomboBox.Location = new System.Drawing.Point(236, 346);
            this.addchargescomboBox.Name = "addchargescomboBox";
            this.addchargescomboBox.Size = new System.Drawing.Size(169, 21);
            this.addchargescomboBox.TabIndex = 24;
            // 
            // holidayreservationidtextBox
            // 
            this.holidayreservationidtextBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.holidayreservationidtextBox.Location = new System.Drawing.Point(236, 129);
            this.holidayreservationidtextBox.Name = "holidayreservationidtextBox";
            this.holidayreservationidtextBox.Size = new System.Drawing.Size(169, 20);
            this.holidayreservationidtextBox.TabIndex = 23;
            // 
            // label8
            // 
            this.label8.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(24, 132);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(119, 13);
            this.label8.TabIndex = 18;
            this.label8.Text = "Holiday Reservation ID:";
            // 
            // label7
            // 
            this.label7.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(24, 395);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(135, 13);
            this.label7.TabIndex = 12;
            this.label7.Text = "*Additional Charges Status ";
            // 
            // label6
            // 
            this.label6.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(24, 349);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(99, 13);
            this.label6.TabIndex = 17;
            this.label6.Text = "*Additional Charges";
            // 
            // label5
            // 
            this.label5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(24, 304);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(136, 13);
            this.label5.TabIndex = 16;
            this.label5.Text = "*Remaining Amount Status:";
            // 
            // remainingamounttextBox
            // 
            this.remainingamounttextBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.remainingamounttextBox.Location = new System.Drawing.Point(236, 256);
            this.remainingamounttextBox.Name = "remainingamounttextBox";
            this.remainingamounttextBox.Size = new System.Drawing.Size(169, 20);
            this.remainingamounttextBox.TabIndex = 21;
            // 
            // label4
            // 
            this.label4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(24, 259);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(99, 13);
            this.label4.TabIndex = 15;
            this.label4.Text = "Remaining Amount:";
            // 
            // label3
            // 
            this.label3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(24, 218);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(80, 13);
            this.label3.TabIndex = 14;
            this.label3.Text = "*Deposit Status";
            // 
            // depositamounttextBox
            // 
            this.depositamounttextBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.depositamounttextBox.Location = new System.Drawing.Point(236, 171);
            this.depositamounttextBox.Name = "depositamounttextBox";
            this.depositamounttextBox.Size = new System.Drawing.Size(169, 20);
            this.depositamounttextBox.TabIndex = 22;
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(24, 174);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(82, 13);
            this.label2.TabIndex = 13;
            this.label2.Text = "Deposit Amount";
            // 
            // holidaypaymentidtextBox
            // 
            this.holidaypaymentidtextBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.holidaypaymentidtextBox.Location = new System.Drawing.Point(236, 41);
            this.holidaypaymentidtextBox.Name = "holidaypaymentidtextBox";
            this.holidaypaymentidtextBox.Size = new System.Drawing.Size(169, 20);
            this.holidaypaymentidtextBox.TabIndex = 20;
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(24, 44);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(107, 13);
            this.label1.TabIndex = 19;
            this.label1.Text = "*Holiday Payment ID:";
            // 
            // displaybutton
            // 
            this.displaybutton.Location = new System.Drawing.Point(651, 427);
            this.displaybutton.Name = "displaybutton";
            this.displaybutton.Size = new System.Drawing.Size(136, 45);
            this.displaybutton.TabIndex = 31;
            this.displaybutton.Text = "Display Table of Holiday Payment Reservation";
            this.displaybutton.UseVisualStyleBackColor = true;
            this.displaybutton.Click += new System.EventHandler(this.displaybutton_Click);
            // 
            // holiresdataGridView
            // 
            this.holiresdataGridView.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.holiresdataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.holiresdataGridView.Location = new System.Drawing.Point(432, 41);
            this.holiresdataGridView.Name = "holiresdataGridView";
            this.holiresdataGridView.Size = new System.Drawing.Size(575, 376);
            this.holiresdataGridView.TabIndex = 30;
            // 
            // updatebutton
            // 
            this.updatebutton.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.updatebutton.Location = new System.Drawing.Point(80, 449);
            this.updatebutton.Name = "updatebutton";
            this.updatebutton.Size = new System.Drawing.Size(75, 23);
            this.updatebutton.TabIndex = 33;
            this.updatebutton.Text = "Update";
            this.updatebutton.UseVisualStyleBackColor = true;
            this.updatebutton.Click += new System.EventHandler(this.updatebutton_Click);
            // 
            // label9
            // 
            this.label9.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Modern No. 20", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(63, 16);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(850, 17);
            this.label9.TabIndex = 34;
            this.label9.Text = "This Interface is to insert or update HOLIDAY payment information of Customers. P" +
    "lease ensure all fields are entered.";
            // 
            // paymentholidayres
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1026, 484);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.updatebutton);
            this.Controls.Add(this.displaybutton);
            this.Controls.Add(this.holiresdataGridView);
            this.Controls.Add(this.cusidtextBox);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.depositstatuscomboBox);
            this.Controls.Add(this.remainamountstatuscomboBox);
            this.Controls.Add(this.addchargesstatuscomboBox);
            this.Controls.Add(this.addchargescomboBox);
            this.Controls.Add(this.holidayreservationidtextBox);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.remainingamounttextBox);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.depositamounttextBox);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.holidaypaymentidtextBox);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.backbutton);
            this.Controls.Add(this.confirmbutton);
            this.Controls.Add(this.mainmenubutton);
            this.Name = "paymentholidayres";
            this.Text = "Payment Holiday Reservation";
            this.Load += new System.EventHandler(this.paymentholidayres_Load);
            ((System.ComponentModel.ISupportInitialize)(this.holiresdataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button mainmenubutton;
        private System.Windows.Forms.Button confirmbutton;
        private System.Windows.Forms.Button backbutton;
        private System.Windows.Forms.TextBox cusidtextBox;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ComboBox depositstatuscomboBox;
        private System.Windows.Forms.ComboBox remainamountstatuscomboBox;
        private System.Windows.Forms.ComboBox addchargesstatuscomboBox;
        private System.Windows.Forms.ComboBox addchargescomboBox;
        private System.Windows.Forms.TextBox holidayreservationidtextBox;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox remainingamounttextBox;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox depositamounttextBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox holidaypaymentidtextBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button displaybutton;
        private System.Windows.Forms.DataGridView holiresdataGridView;
        private System.Windows.Forms.Button updatebutton;
        private System.Windows.Forms.Label label9;
    }
}