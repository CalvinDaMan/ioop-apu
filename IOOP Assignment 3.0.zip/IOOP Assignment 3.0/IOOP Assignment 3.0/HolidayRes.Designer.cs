﻿namespace IOOP_Assignment_3._0
{
    partial class HolidayRes
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(HolidayRes));
            this.holidayresmainmenubutton = new System.Windows.Forms.Button();
            this.holidaylabel = new System.Windows.Forms.Label();
            this.holidaypackagecomboBox = new System.Windows.Forms.ComboBox();
            this.packagepricelabel = new System.Windows.Forms.Label();
            this.packagepricetextBox = new System.Windows.Forms.TextBox();
            this.holidaydatereslabel = new System.Windows.Forms.Label();
            this.holidayresconfirmbutton = new System.Windows.Forms.Button();
            this.holidayresholidayidlabel = new System.Windows.Forms.Label();
            this.holidayresholidayidtextBox = new System.Windows.Forms.TextBox();
            this.tourexamplelabel = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.holidayresroomtypecomboBox = new System.Windows.Forms.ComboBox();
            this.backtoresbutton_holidayres = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.holirstartdateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.holirenddateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.holirescusidlabel = new System.Windows.Forms.Label();
            this.holirescusidtextBox = new System.Windows.Forms.TextBox();
            this.hotelresidlabel = new System.Windows.Forms.Label();
            this.holirestextBox = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.amountrescomboBox = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // holidayresmainmenubutton
            // 
            this.holidayresmainmenubutton.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.holidayresmainmenubutton.Location = new System.Drawing.Point(145, 465);
            this.holidayresmainmenubutton.Name = "holidayresmainmenubutton";
            this.holidayresmainmenubutton.Size = new System.Drawing.Size(131, 23);
            this.holidayresmainmenubutton.TabIndex = 1;
            this.holidayresmainmenubutton.Text = "Back to main menu";
            this.holidayresmainmenubutton.UseVisualStyleBackColor = true;
            this.holidayresmainmenubutton.Click += new System.EventHandler(this.holidayresmainmenubutton_Click);
            // 
            // holidaylabel
            // 
            this.holidaylabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.holidaylabel.AutoSize = true;
            this.holidaylabel.Location = new System.Drawing.Point(97, 214);
            this.holidaylabel.Name = "holidaylabel";
            this.holidaylabel.Size = new System.Drawing.Size(87, 13);
            this.holidaylabel.TabIndex = 5;
            this.holidaylabel.Text = "Holiday package";
            // 
            // holidaypackagecomboBox
            // 
            this.holidaypackagecomboBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.holidaypackagecomboBox.FormattingEnabled = true;
            this.holidaypackagecomboBox.Items.AddRange(new object[] {
            "Langkawi Island Tour (4 days 3 nights) Berjaya Resort",
            "Langkawi Island Tour (4 days 3 nights) Adya Hotel",
            "Cameron Highlands Tour (3 days 2 nights) Cameron Highlands Resort",
            "Cameron Highlands Tour (3 days 2 nights) Century Pines Resort",
            "Tioman Island Tour (5 days 4 nights) Tunamaya Beach & Spa Resort",
            "Tioman Island Tour (5 days 4 nights) Berjaya Resort"});
            this.holidaypackagecomboBox.Location = new System.Drawing.Point(267, 211);
            this.holidaypackagecomboBox.Name = "holidaypackagecomboBox";
            this.holidaypackagecomboBox.Size = new System.Drawing.Size(309, 21);
            this.holidaypackagecomboBox.TabIndex = 4;
            this.holidaypackagecomboBox.SelectedIndexChanged += new System.EventHandler(this.holidaypackagecomboBox_SelectedIndexChanged);
            // 
            // packagepricelabel
            // 
            this.packagepricelabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.packagepricelabel.AutoSize = true;
            this.packagepricelabel.Location = new System.Drawing.Point(97, 414);
            this.packagepricelabel.Name = "packagepricelabel";
            this.packagepricelabel.Size = new System.Drawing.Size(77, 13);
            this.packagepricelabel.TabIndex = 6;
            this.packagepricelabel.Text = "Package Price";
            // 
            // packagepricetextBox
            // 
            this.packagepricetextBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.packagepricetextBox.Location = new System.Drawing.Point(267, 414);
            this.packagepricetextBox.Name = "packagepricetextBox";
            this.packagepricetextBox.Size = new System.Drawing.Size(309, 20);
            this.packagepricetextBox.TabIndex = 7;
            // 
            // holidaydatereslabel
            // 
            this.holidaydatereslabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.holidaydatereslabel.AutoSize = true;
            this.holidaydatereslabel.Location = new System.Drawing.Point(97, 257);
            this.holidaydatereslabel.Name = "holidaydatereslabel";
            this.holidaydatereslabel.Size = new System.Drawing.Size(105, 13);
            this.holidaydatereslabel.TabIndex = 9;
            this.holidaydatereslabel.Text = "Date reserved (Start)";
            // 
            // holidayresconfirmbutton
            // 
            this.holidayresconfirmbutton.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.holidayresconfirmbutton.Location = new System.Drawing.Point(399, 465);
            this.holidayresconfirmbutton.Name = "holidayresconfirmbutton";
            this.holidayresconfirmbutton.Size = new System.Drawing.Size(75, 23);
            this.holidayresconfirmbutton.TabIndex = 10;
            this.holidayresconfirmbutton.Text = "Confirm";
            this.holidayresconfirmbutton.UseVisualStyleBackColor = true;
            this.holidayresconfirmbutton.Click += new System.EventHandler(this.holidayresconfirmbutton_Click);
            // 
            // holidayresholidayidlabel
            // 
            this.holidayresholidayidlabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.holidayresholidayidlabel.AutoSize = true;
            this.holidayresholidayidlabel.Location = new System.Drawing.Point(97, 134);
            this.holidayresholidayidlabel.Name = "holidayresholidayidlabel";
            this.holidayresholidayidlabel.Size = new System.Drawing.Size(56, 13);
            this.holidayresholidayidlabel.TabIndex = 11;
            this.holidayresholidayidlabel.Text = "Holiday ID";
            // 
            // holidayresholidayidtextBox
            // 
            this.holidayresholidayidtextBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.holidayresholidayidtextBox.Location = new System.Drawing.Point(267, 131);
            this.holidayresholidayidtextBox.Name = "holidayresholidayidtextBox";
            this.holidayresholidayidtextBox.Size = new System.Drawing.Size(309, 20);
            this.holidayresholidayidtextBox.TabIndex = 12;
            // 
            // tourexamplelabel
            // 
            this.tourexamplelabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.tourexamplelabel.AutoSize = true;
            this.tourexamplelabel.Font = new System.Drawing.Font("Palatino Linotype", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tourexamplelabel.Location = new System.Drawing.Point(12, 9);
            this.tourexamplelabel.Name = "tourexamplelabel";
            this.tourexamplelabel.Size = new System.Drawing.Size(629, 63);
            this.tourexamplelabel.TabIndex = 13;
            this.tourexamplelabel.Text = resources.GetString("tourexamplelabel.Text");
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(97, 331);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(62, 13);
            this.label1.TabIndex = 15;
            this.label1.Text = "Room Type";
            // 
            // holidayresroomtypecomboBox
            // 
            this.holidayresroomtypecomboBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.holidayresroomtypecomboBox.FormattingEnabled = true;
            this.holidayresroomtypecomboBox.Items.AddRange(new object[] {
            "Single",
            "Double",
            "Family Suite"});
            this.holidayresroomtypecomboBox.Location = new System.Drawing.Point(267, 328);
            this.holidayresroomtypecomboBox.Name = "holidayresroomtypecomboBox";
            this.holidayresroomtypecomboBox.Size = new System.Drawing.Size(309, 21);
            this.holidayresroomtypecomboBox.TabIndex = 4;
            this.holidayresroomtypecomboBox.SelectedIndexChanged += new System.EventHandler(this.holidayresroomtypecomboBox_SelectedIndexChanged);
            // 
            // backtoresbutton_holidayres
            // 
            this.backtoresbutton_holidayres.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.backtoresbutton_holidayres.Location = new System.Drawing.Point(297, 459);
            this.backtoresbutton_holidayres.Name = "backtoresbutton_holidayres";
            this.backtoresbutton_holidayres.Size = new System.Drawing.Size(75, 35);
            this.backtoresbutton_holidayres.TabIndex = 33;
            this.backtoresbutton_holidayres.Text = "Back to Reservation";
            this.backtoresbutton_holidayres.UseVisualStyleBackColor = true;
            this.backtoresbutton_holidayres.Click += new System.EventHandler(this.backtoresbutton_holidayres_Click);
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(97, 295);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(102, 13);
            this.label2.TabIndex = 35;
            this.label2.Text = "Date reserved (End)";
            // 
            // holirstartdateTimePicker
            // 
            this.holirstartdateTimePicker.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.holirstartdateTimePicker.Location = new System.Drawing.Point(267, 252);
            this.holirstartdateTimePicker.Name = "holirstartdateTimePicker";
            this.holirstartdateTimePicker.Size = new System.Drawing.Size(309, 20);
            this.holirstartdateTimePicker.TabIndex = 36;
            this.holirstartdateTimePicker.ValueChanged += new System.EventHandler(this.holirstartdateTimePicker_ValueChanged);
            // 
            // holirenddateTimePicker2
            // 
            this.holirenddateTimePicker2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.holirenddateTimePicker2.Location = new System.Drawing.Point(267, 289);
            this.holirenddateTimePicker2.Name = "holirenddateTimePicker2";
            this.holirenddateTimePicker2.Size = new System.Drawing.Size(309, 20);
            this.holirenddateTimePicker2.TabIndex = 36;
            this.holirenddateTimePicker2.ValueChanged += new System.EventHandler(this.holirenddateTimePicker2_ValueChanged);
            // 
            // holirescusidlabel
            // 
            this.holirescusidlabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.holirescusidlabel.AutoSize = true;
            this.holirescusidlabel.Location = new System.Drawing.Point(97, 171);
            this.holirescusidlabel.Name = "holirescusidlabel";
            this.holirescusidlabel.Size = new System.Drawing.Size(153, 13);
            this.holirescusidlabel.TabIndex = 11;
            this.holirescusidlabel.Text = "Customer IC/ Passport Number";
            // 
            // holirescusidtextBox
            // 
            this.holirescusidtextBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.holirescusidtextBox.Location = new System.Drawing.Point(267, 168);
            this.holirescusidtextBox.Name = "holirescusidtextBox";
            this.holirescusidtextBox.Size = new System.Drawing.Size(309, 20);
            this.holirescusidtextBox.TabIndex = 12;
            // 
            // hotelresidlabel
            // 
            this.hotelresidlabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.hotelresidlabel.AutoSize = true;
            this.hotelresidlabel.Location = new System.Drawing.Point(97, 96);
            this.hotelresidlabel.Name = "hotelresidlabel";
            this.hotelresidlabel.Size = new System.Drawing.Size(78, 13);
            this.hotelresidlabel.TabIndex = 11;
            this.hotelresidlabel.Text = "Reservation ID";
            // 
            // holirestextBox
            // 
            this.holirestextBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.holirestextBox.Location = new System.Drawing.Point(267, 93);
            this.holirestextBox.Name = "holirestextBox";
            this.holirestextBox.Size = new System.Drawing.Size(309, 20);
            this.holirestextBox.TabIndex = 12;
            // 
            // label3
            // 
            this.label3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(97, 371);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(131, 13);
            this.label3.TabIndex = 6;
            this.label3.Text = "Amount reserved (Max:10)";
            // 
            // amountrescomboBox
            // 
            this.amountrescomboBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.amountrescomboBox.FormattingEnabled = true;
            this.amountrescomboBox.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10"});
            this.amountrescomboBox.Location = new System.Drawing.Point(267, 368);
            this.amountrescomboBox.Name = "amountrescomboBox";
            this.amountrescomboBox.Size = new System.Drawing.Size(309, 21);
            this.amountrescomboBox.TabIndex = 37;
            this.amountrescomboBox.SelectedIndexChanged += new System.EventHandler(this.amountrescomboBox_SelectedIndexChanged);
            // 
            // HolidayRes
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(656, 500);
            this.Controls.Add(this.amountrescomboBox);
            this.Controls.Add(this.holirenddateTimePicker2);
            this.Controls.Add(this.holirstartdateTimePicker);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.backtoresbutton_holidayres);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tourexamplelabel);
            this.Controls.Add(this.holirescusidtextBox);
            this.Controls.Add(this.holirescusidlabel);
            this.Controls.Add(this.holirestextBox);
            this.Controls.Add(this.hotelresidlabel);
            this.Controls.Add(this.holidayresholidayidtextBox);
            this.Controls.Add(this.holidayresholidayidlabel);
            this.Controls.Add(this.holidayresconfirmbutton);
            this.Controls.Add(this.holidaydatereslabel);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.packagepricetextBox);
            this.Controls.Add(this.packagepricelabel);
            this.Controls.Add(this.holidaylabel);
            this.Controls.Add(this.holidayresroomtypecomboBox);
            this.Controls.Add(this.holidaypackagecomboBox);
            this.Controls.Add(this.holidayresmainmenubutton);
            this.Name = "HolidayRes";
            this.Text = "Holiday Reservation";
            this.Load += new System.EventHandler(this.HolidayRes_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button holidayresmainmenubutton;
        private System.Windows.Forms.Label holidaylabel;
        private System.Windows.Forms.ComboBox holidaypackagecomboBox;
        private System.Windows.Forms.Label packagepricelabel;
        private System.Windows.Forms.TextBox packagepricetextBox;
        private System.Windows.Forms.Label holidaydatereslabel;
        private System.Windows.Forms.Button holidayresconfirmbutton;
        private System.Windows.Forms.Label holidayresholidayidlabel;
        private System.Windows.Forms.TextBox holidayresholidayidtextBox;
        private System.Windows.Forms.Label tourexamplelabel;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox holidayresroomtypecomboBox;
        private System.Windows.Forms.Button backtoresbutton_holidayres;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DateTimePicker holirstartdateTimePicker;
        private System.Windows.Forms.DateTimePicker holirenddateTimePicker2;
        private System.Windows.Forms.Label holirescusidlabel;
        private System.Windows.Forms.TextBox holirescusidtextBox;
        private System.Windows.Forms.Label hotelresidlabel;
        private System.Windows.Forms.TextBox holirestextBox;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox amountrescomboBox;
    }
}