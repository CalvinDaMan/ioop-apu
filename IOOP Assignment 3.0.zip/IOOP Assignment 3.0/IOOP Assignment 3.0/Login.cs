﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IOOP_Assignment_3._0
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (usernametextBox.Text == "WongLF001" && passwordtextBox.Text == "PowerRangersWildForce")
            {
                MainMenu newForm = new MainMenu();
                newForm.Show();
                this.Hide();
            }
            else if (usernametextBox.Text == "AhmadMK002" && passwordtextBox.Text == "GlowLikeDat")
            {
                MainMenu newForm = new MainMenu();
                newForm.Show();
                this.Hide();
            }
            else if (usernametextBox.Text == "OmarKL003" && passwordtextBox.Text == "ApamBalik")
            {
                MainMenu newForm = new MainMenu();
                newForm.Show();
                this.Hide();
            }
            else if (usernametextBox .Text == "Admin" && passwordtextBox .Text == "AdventureTime")
            {
                MainMenu newForm = new MainMenu();
                newForm.Show();
                this.Hide();
            }
            else if (usernametextBox.Text == "" && passwordtextBox.Text == "")
            {
                MainMenu newForm = new MainMenu();
                newForm.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Incorrect username or password.");
                usernametextBox.Text = null;//clears the incorrect username entered by the user
                passwordtextBox.Text = null;//clears incorrect password
            }
        }

        private void exitbutton_Click(object sender, EventArgs e)
        {
            const string message = "Do you want to exit?";
            const string caption = "EXIT";
            var result = MessageBox.Show(message, caption, MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes) //if user click on "yes", the program would be closed, 
                                            //if not message box would be close
            {
                this.Close();
            }
        }

        private void viewcheckBox_CheckedChanged(object sender, EventArgs e)
        {
            if (viewcheckBox.Checked)
            {
                passwordtextBox.UseSystemPasswordChar = false;
            }
            else
            {
                passwordtextBox.UseSystemPasswordChar = true;
            }
        }

        private void reportgenbutton_Click(object sender, EventArgs e)
        {
            Reportgen newForm = new Reportgen();
            newForm.Show();
            this.Hide();
        }
    }
}
