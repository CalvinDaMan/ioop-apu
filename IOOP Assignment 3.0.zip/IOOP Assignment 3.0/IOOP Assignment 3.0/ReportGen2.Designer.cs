﻿namespace IOOP_Assignment_3._0
{
    partial class ReportGen2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.mainmenubutton_hotelr = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.hotelresbutton = new System.Windows.Forms.Button();
            this.holiresbutton = new System.Windows.Forms.Button();
            this.tourresbutton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // mainmenubutton_hotelr
            // 
            this.mainmenubutton_hotelr.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.mainmenubutton_hotelr.Location = new System.Drawing.Point(142, 335);
            this.mainmenubutton_hotelr.Name = "mainmenubutton_hotelr";
            this.mainmenubutton_hotelr.Size = new System.Drawing.Size(114, 23);
            this.mainmenubutton_hotelr.TabIndex = 31;
            this.mainmenubutton_hotelr.Text = "Back to main menu";
            this.mainmenubutton_hotelr.UseVisualStyleBackColor = true;
            this.mainmenubutton_hotelr.Click += new System.EventHandler(this.mainmenubutton_hotelr_Click);
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(34, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(44, 13);
            this.label1.TabIndex = 32;
            this.label1.Text = "Reports";
            // 
            // hotelresbutton
            // 
            this.hotelresbutton.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.hotelresbutton.Location = new System.Drawing.Point(146, 120);
            this.hotelresbutton.Name = "hotelresbutton";
            this.hotelresbutton.Size = new System.Drawing.Size(110, 23);
            this.hotelresbutton.TabIndex = 33;
            this.hotelresbutton.Text = "Hotel Reservation";
            this.hotelresbutton.UseVisualStyleBackColor = true;
            this.hotelresbutton.Click += new System.EventHandler(this.hotelresbutton_Click);
            // 
            // holiresbutton
            // 
            this.holiresbutton.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.holiresbutton.Location = new System.Drawing.Point(146, 166);
            this.holiresbutton.Name = "holiresbutton";
            this.holiresbutton.Size = new System.Drawing.Size(110, 23);
            this.holiresbutton.TabIndex = 33;
            this.holiresbutton.Text = "Holiday Reservation";
            this.holiresbutton.UseVisualStyleBackColor = true;
            this.holiresbutton.Click += new System.EventHandler(this.holiresbutton_Click);
            // 
            // tourresbutton
            // 
            this.tourresbutton.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.tourresbutton.Location = new System.Drawing.Point(146, 218);
            this.tourresbutton.Name = "tourresbutton";
            this.tourresbutton.Size = new System.Drawing.Size(110, 23);
            this.tourresbutton.TabIndex = 33;
            this.tourresbutton.Text = "Tour Reservation";
            this.tourresbutton.UseVisualStyleBackColor = true;
            this.tourresbutton.Click += new System.EventHandler(this.tourresbutton_Click);
            // 
            // ReportGen2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(412, 380);
            this.Controls.Add(this.tourresbutton);
            this.Controls.Add(this.holiresbutton);
            this.Controls.Add(this.hotelresbutton);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.mainmenubutton_hotelr);
            this.Name = "ReportGen2";
            this.Text = "Report Generation";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button mainmenubutton_hotelr;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button hotelresbutton;
        private System.Windows.Forms.Button holiresbutton;
        private System.Windows.Forms.Button tourresbutton;
    }
}