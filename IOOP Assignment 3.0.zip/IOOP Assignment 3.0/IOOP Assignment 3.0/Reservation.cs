﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IOOP_Assignment_3._0
{
    public partial class Reservation : Form
    {
        public Reservation()
        {
            InitializeComponent();
        }

        private void mainmenubutton_Click(object sender, EventArgs e)
        {
            MainMenu newForm = new MainMenu();
            newForm.Show();
            this.Hide();
        }

        private void hotelresbutton_Click(object sender, EventArgs e)
        {
            CusInfo_hr newForm = new CusInfo_hr();
            newForm.Show();
            this.Hide();
        }

        private void tourpackageresutton_Click(object sender, EventArgs e)
        {
            CusInfo_tr newForm = new CusInfo_tr();
            newForm.Show();
            this.Hide();
        }

        private void holidaypackageresbutton_Click(object sender, EventArgs e)
        {
            CusInfo_holir newForm = new CusInfo_holir();
            newForm.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            HotelRes newForm = new HotelRes();
            newForm.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            touridlabel newForm =new touridlabel();
            newForm.Show();
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            HolidayRes newForm = new HolidayRes();
            newForm.Show();
            this.Hide();
        }
    }
}
