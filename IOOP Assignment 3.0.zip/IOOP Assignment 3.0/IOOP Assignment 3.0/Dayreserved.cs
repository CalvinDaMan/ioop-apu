﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IOOP_Assignment_3._0
{
    class Dayreserved
    {
        private DateTime _startdate;
        private DateTime _enddate;
    
    public DateTime startdate
        {
            get
            {
                return _startdate;
            }
            set
            {
                _startdate = value;
            }
        }
    public DateTime enddate
        {
            get
            {
                return _enddate;
            }
            set
            {
                _enddate = value;
            }
        }
   

    }
}
