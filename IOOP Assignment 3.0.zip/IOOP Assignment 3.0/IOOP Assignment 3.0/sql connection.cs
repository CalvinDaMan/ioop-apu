﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.OleDb;

namespace IOOP_Assignment_3._0
{
    class sql_connection
    {
        private string _connect;
        public string connect
        {
            get
            {
                return _connect;
            }
            set
            {
                _connect = value;
            }
        }

            public sql_connection(string cn)
            {
            _connect = cn;
            }
            
            public string dbconn(string connect)
            {
                return  "Provider =Microsoft.ACE.OLEDB.12.0; Data Source =C:\\database\\datedatabase.accdb";
        }
        
    }
}
