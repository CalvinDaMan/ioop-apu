﻿namespace IOOP_Assignment_3._0
{
    partial class touridlabel
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tourresmainmenubutton = new System.Windows.Forms.Button();
            this.tourrestouridlabel = new System.Windows.Forms.Label();
            this.tourrestournamecomboBox = new System.Windows.Forms.ComboBox();
            this.touridexamplelabel = new System.Windows.Forms.Label();
            this.tourrestouridtextBox = new System.Windows.Forms.TextBox();
            this.tourresnamelabel = new System.Windows.Forms.Label();
            this.tourrespricelabel = new System.Windows.Forms.Label();
            this.tourrespricetextBox = new System.Windows.Forms.TextBox();
            this.tourdatereslabel = new System.Windows.Forms.Label();
            this.tourresconfirmbutton = new System.Windows.Forms.Button();
            this.backtoresbutton_tourres = new System.Windows.Forms.Button();
            this.tourrescusidlabel = new System.Windows.Forms.Label();
            this.tourrescusidtextBox = new System.Windows.Forms.TextBox();
            this.tourresdateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.tourdateresendlabel = new System.Windows.Forms.Label();
            this.touresenddateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.label1 = new System.Windows.Forms.Label();
            this.tourrestextBox = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.amountrescomboBox = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // tourresmainmenubutton
            // 
            this.tourresmainmenubutton.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.tourresmainmenubutton.Location = new System.Drawing.Point(127, 395);
            this.tourresmainmenubutton.Name = "tourresmainmenubutton";
            this.tourresmainmenubutton.Size = new System.Drawing.Size(131, 23);
            this.tourresmainmenubutton.TabIndex = 0;
            this.tourresmainmenubutton.Text = "Back to main menu";
            this.tourresmainmenubutton.UseVisualStyleBackColor = true;
            this.tourresmainmenubutton.Click += new System.EventHandler(this.tourresmainmenubutton_Click);
            // 
            // tourrestouridlabel
            // 
            this.tourrestouridlabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.tourrestouridlabel.AutoSize = true;
            this.tourrestouridlabel.Location = new System.Drawing.Point(77, 115);
            this.tourrestouridlabel.Name = "tourrestouridlabel";
            this.tourrestouridlabel.Size = new System.Drawing.Size(43, 13);
            this.tourrestouridlabel.TabIndex = 5;
            this.tourrestouridlabel.Text = "Tour ID";
            // 
            // tourrestournamecomboBox
            // 
            this.tourrestournamecomboBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.tourrestournamecomboBox.FormattingEnabled = true;
            this.tourrestournamecomboBox.Items.AddRange(new object[] {
            "Langkawi Island Tour (4 days 3 nights) ",
            "Cameron Highlands Tour (3 days 2 nights) ",
            "Tioman Island Tour (5 days 4 nights)"});
            this.tourrestournamecomboBox.Location = new System.Drawing.Point(241, 190);
            this.tourrestournamecomboBox.Name = "tourrestournamecomboBox";
            this.tourrestournamecomboBox.Size = new System.Drawing.Size(293, 21);
            this.tourrestournamecomboBox.TabIndex = 4;
            this.tourrestournamecomboBox.SelectedIndexChanged += new System.EventHandler(this.tourrestournamecomboBox_SelectedIndexChanged);
            // 
            // touridexamplelabel
            // 
            this.touridexamplelabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.touridexamplelabel.AutoSize = true;
            this.touridexamplelabel.Font = new System.Drawing.Font("Palatino Linotype", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.touridexamplelabel.Location = new System.Drawing.Point(2, 9);
            this.touridexamplelabel.Name = "touridexamplelabel";
            this.touridexamplelabel.Size = new System.Drawing.Size(600, 21);
            this.touridexamplelabel.TabIndex = 6;
            this.touridexamplelabel.Text = "Tour ID examples: LT001 (Langkawi), CT001 (Cameron Highlands), TT001 (Tioman)\r\n";
            // 
            // tourrestouridtextBox
            // 
            this.tourrestouridtextBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.tourrestouridtextBox.Location = new System.Drawing.Point(241, 112);
            this.tourrestouridtextBox.Name = "tourrestouridtextBox";
            this.tourrestouridtextBox.Size = new System.Drawing.Size(293, 20);
            this.tourrestouridtextBox.TabIndex = 7;
            // 
            // tourresnamelabel
            // 
            this.tourresnamelabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.tourresnamelabel.AutoSize = true;
            this.tourresnamelabel.Location = new System.Drawing.Point(77, 193);
            this.tourresnamelabel.Name = "tourresnamelabel";
            this.tourresnamelabel.Size = new System.Drawing.Size(58, 13);
            this.tourresnamelabel.TabIndex = 8;
            this.tourresnamelabel.Text = "Tour name";
            // 
            // tourrespricelabel
            // 
            this.tourrespricelabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.tourrespricelabel.AutoSize = true;
            this.tourrespricelabel.Location = new System.Drawing.Point(77, 357);
            this.tourrespricelabel.Name = "tourrespricelabel";
            this.tourrespricelabel.Size = new System.Drawing.Size(56, 13);
            this.tourrespricelabel.TabIndex = 9;
            this.tourrespricelabel.Text = "Tour Price";
            // 
            // tourrespricetextBox
            // 
            this.tourrespricetextBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.tourrespricetextBox.Location = new System.Drawing.Point(241, 350);
            this.tourrespricetextBox.Name = "tourrespricetextBox";
            this.tourrespricetextBox.Size = new System.Drawing.Size(293, 20);
            this.tourrespricetextBox.TabIndex = 10;
            // 
            // tourdatereslabel
            // 
            this.tourdatereslabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.tourdatereslabel.AutoSize = true;
            this.tourdatereslabel.Location = new System.Drawing.Point(77, 237);
            this.tourdatereslabel.Name = "tourdatereslabel";
            this.tourdatereslabel.Size = new System.Drawing.Size(103, 13);
            this.tourdatereslabel.TabIndex = 9;
            this.tourdatereslabel.Text = "Date reserved (start)";
            // 
            // tourresconfirmbutton
            // 
            this.tourresconfirmbutton.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.tourresconfirmbutton.Location = new System.Drawing.Point(394, 395);
            this.tourresconfirmbutton.Name = "tourresconfirmbutton";
            this.tourresconfirmbutton.Size = new System.Drawing.Size(94, 23);
            this.tourresconfirmbutton.TabIndex = 11;
            this.tourresconfirmbutton.Text = "Confirm";
            this.tourresconfirmbutton.UseVisualStyleBackColor = true;
            this.tourresconfirmbutton.Click += new System.EventHandler(this.tourresconfirmbutton_Click);
            // 
            // backtoresbutton_tourres
            // 
            this.backtoresbutton_tourres.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.backtoresbutton_tourres.Location = new System.Drawing.Point(285, 389);
            this.backtoresbutton_tourres.Name = "backtoresbutton_tourres";
            this.backtoresbutton_tourres.Size = new System.Drawing.Size(75, 35);
            this.backtoresbutton_tourres.TabIndex = 33;
            this.backtoresbutton_tourres.Text = "Back to Reservation";
            this.backtoresbutton_tourres.UseVisualStyleBackColor = true;
            this.backtoresbutton_tourres.Click += new System.EventHandler(this.backtoresbutton_tourres_Click);
            // 
            // tourrescusidlabel
            // 
            this.tourrescusidlabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.tourrescusidlabel.AutoSize = true;
            this.tourrescusidlabel.Location = new System.Drawing.Point(77, 153);
            this.tourrescusidlabel.Name = "tourrescusidlabel";
            this.tourrescusidlabel.Size = new System.Drawing.Size(153, 13);
            this.tourrescusidlabel.TabIndex = 34;
            this.tourrescusidlabel.Text = "Customer IC/ Passport Number";
            // 
            // tourrescusidtextBox
            // 
            this.tourrescusidtextBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.tourrescusidtextBox.Location = new System.Drawing.Point(241, 150);
            this.tourrescusidtextBox.Name = "tourrescusidtextBox";
            this.tourrescusidtextBox.Size = new System.Drawing.Size(293, 20);
            this.tourrescusidtextBox.TabIndex = 7;
            // 
            // tourresdateTimePicker
            // 
            this.tourresdateTimePicker.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.tourresdateTimePicker.Location = new System.Drawing.Point(241, 232);
            this.tourresdateTimePicker.Name = "tourresdateTimePicker";
            this.tourresdateTimePicker.Size = new System.Drawing.Size(293, 20);
            this.tourresdateTimePicker.TabIndex = 35;
            this.tourresdateTimePicker.ValueChanged += new System.EventHandler(this.tourresdateTimePicker_ValueChanged);
            // 
            // tourdateresendlabel
            // 
            this.tourdateresendlabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.tourdateresendlabel.AutoSize = true;
            this.tourdateresendlabel.Location = new System.Drawing.Point(77, 276);
            this.tourdateresendlabel.Name = "tourdateresendlabel";
            this.tourdateresendlabel.Size = new System.Drawing.Size(101, 13);
            this.tourdateresendlabel.TabIndex = 9;
            this.tourdateresendlabel.Text = "Date reserved (end)";
            // 
            // touresenddateTimePicker
            // 
            this.touresenddateTimePicker.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.touresenddateTimePicker.Location = new System.Drawing.Point(241, 270);
            this.touresenddateTimePicker.Name = "touresenddateTimePicker";
            this.touresenddateTimePicker.Size = new System.Drawing.Size(293, 20);
            this.touresenddateTimePicker.TabIndex = 36;
            this.touresenddateTimePicker.ValueChanged += new System.EventHandler(this.touresenddateTimePicker_ValueChanged);
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(77, 77);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(78, 13);
            this.label1.TabIndex = 5;
            this.label1.Text = "Reservation ID";
            // 
            // tourrestextBox
            // 
            this.tourrestextBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.tourrestextBox.Location = new System.Drawing.Point(241, 74);
            this.tourrestextBox.Name = "tourrestextBox";
            this.tourrestextBox.Size = new System.Drawing.Size(293, 20);
            this.tourrestextBox.TabIndex = 7;
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(77, 310);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(131, 13);
            this.label2.TabIndex = 37;
            this.label2.Text = "Amount reserved (Max:10)";
            // 
            // amountrescomboBox
            // 
            this.amountrescomboBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.amountrescomboBox.FormattingEnabled = true;
            this.amountrescomboBox.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10"});
            this.amountrescomboBox.Location = new System.Drawing.Point(241, 307);
            this.amountrescomboBox.Name = "amountrescomboBox";
            this.amountrescomboBox.Size = new System.Drawing.Size(293, 21);
            this.amountrescomboBox.TabIndex = 38;
            this.amountrescomboBox.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // label3
            // 
            this.label3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Palatino Linotype", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(95, 39);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(410, 21);
            this.label3.TabIndex = 6;
            this.label3.Text = "Please be aware that each tour is limited to 4 participants";
            // 
            // touridlabel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(614, 430);
            this.Controls.Add(this.amountrescomboBox);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.touresenddateTimePicker);
            this.Controls.Add(this.tourresdateTimePicker);
            this.Controls.Add(this.tourrescusidlabel);
            this.Controls.Add(this.backtoresbutton_tourres);
            this.Controls.Add(this.tourresconfirmbutton);
            this.Controls.Add(this.tourdateresendlabel);
            this.Controls.Add(this.tourrespricetextBox);
            this.Controls.Add(this.tourdatereslabel);
            this.Controls.Add(this.tourrespricelabel);
            this.Controls.Add(this.tourresnamelabel);
            this.Controls.Add(this.tourrescusidtextBox);
            this.Controls.Add(this.tourrestextBox);
            this.Controls.Add(this.tourrestouridtextBox);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.touridexamplelabel);
            this.Controls.Add(this.tourrestouridlabel);
            this.Controls.Add(this.tourrestournamecomboBox);
            this.Controls.Add(this.tourresmainmenubutton);
            this.Name = "touridlabel";
            this.Text = "TourRes";
            this.Load += new System.EventHandler(this.touridlabel_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button tourresmainmenubutton;
        private System.Windows.Forms.Label tourrestouridlabel;
        private System.Windows.Forms.ComboBox tourrestournamecomboBox;
        private System.Windows.Forms.Label touridexamplelabel;
        private System.Windows.Forms.TextBox tourrestouridtextBox;
        private System.Windows.Forms.Label tourresnamelabel;
        private System.Windows.Forms.Label tourrespricelabel;
        private System.Windows.Forms.TextBox tourrespricetextBox;
        private System.Windows.Forms.Label tourdatereslabel;
        private System.Windows.Forms.Button tourresconfirmbutton;
        private System.Windows.Forms.Button backtoresbutton_tourres;
        private System.Windows.Forms.Label tourrescusidlabel;
        private System.Windows.Forms.TextBox tourrescusidtextBox;
        private System.Windows.Forms.DateTimePicker tourresdateTimePicker;
        private System.Windows.Forms.Label tourdateresendlabel;
        private System.Windows.Forms.DateTimePicker touresenddateTimePicker;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tourrestextBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox amountrescomboBox;
        private System.Windows.Forms.Label label3;
    }
}