﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IOOP_Assignment_3._0
{
    public partial class Reportgen : Form
    {
        public Reportgen()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            const string message = "Do you want to go to LOGOUT?";
            const string caption = "LOGOUT";
            var result = MessageBox.Show(message, caption, MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes)
            {
                Login newForm = new Login();
                newForm.Show();
                this.Hide();
            }
        }

        private void managerloginbutton_Click(object sender, EventArgs e)
        {
            if(managerusernametextBox .Text =="Admin" && managerpasswordtextBox .Text == "AdventureTime")
            {
                ReportGen2 newForm = new ReportGen2();
                newForm.Show();
                this.Hide();
            }
            if (managerusernametextBox.Text == "" && managerpasswordtextBox.Text == "")
            {
                ReportGen2 newForm = new ReportGen2();
                newForm.Show();
                this.Hide();
            }
        }

        private void viewpasswordcheckBox_CheckedChanged(object sender, EventArgs e)
        {
            if (viewpasswordcheckBox.Checked)
            {
                managerpasswordtextBox.UseSystemPasswordChar = false;
            }
            else
            {
                managerpasswordtextBox.UseSystemPasswordChar = true;
            }
        }
    }
}
