﻿namespace IOOP_Assignment_3._0
{
    partial class hotelresreport
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.mainmenubutton = new System.Windows.Forms.Button();
            this.hotelresdatagrid = new System.Windows.Forms.DataGridView();
            this.displaybutton = new System.Windows.Forms.Button();
            this.backbutton = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.hotelresdatagrid)).BeginInit();
            this.SuspendLayout();
            // 
            // mainmenubutton
            // 
            this.mainmenubutton.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.mainmenubutton.Location = new System.Drawing.Point(398, 320);
            this.mainmenubutton.Name = "mainmenubutton";
            this.mainmenubutton.Size = new System.Drawing.Size(75, 23);
            this.mainmenubutton.TabIndex = 0;
            this.mainmenubutton.Text = "Main Menu";
            this.mainmenubutton.UseVisualStyleBackColor = true;
            this.mainmenubutton.Click += new System.EventHandler(this.mainmenubutton_Click);
            // 
            // hotelresdatagrid
            // 
            this.hotelresdatagrid.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.hotelresdatagrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.hotelresdatagrid.Location = new System.Drawing.Point(-1, 2);
            this.hotelresdatagrid.Name = "hotelresdatagrid";
            this.hotelresdatagrid.Size = new System.Drawing.Size(654, 263);
            this.hotelresdatagrid.TabIndex = 1;
            // 
            // displaybutton
            // 
            this.displaybutton.Location = new System.Drawing.Point(199, 320);
            this.displaybutton.Name = "displaybutton";
            this.displaybutton.Size = new System.Drawing.Size(75, 23);
            this.displaybutton.TabIndex = 2;
            this.displaybutton.Text = "Display";
            this.displaybutton.UseVisualStyleBackColor = true;
            this.displaybutton.Click += new System.EventHandler(this.displaybutton_Click);
            // 
            // backbutton
            // 
            this.backbutton.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.backbutton.Location = new System.Drawing.Point(294, 320);
            this.backbutton.Name = "backbutton";
            this.backbutton.Size = new System.Drawing.Size(75, 23);
            this.backbutton.TabIndex = 3;
            this.backbutton.Text = "Back";
            this.backbutton.UseVisualStyleBackColor = true;
            this.backbutton.Click += new System.EventHandler(this.backbutton_Click);
            // 
            // hotelresreport
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(652, 355);
            this.Controls.Add(this.backbutton);
            this.Controls.Add(this.displaybutton);
            this.Controls.Add(this.hotelresdatagrid);
            this.Controls.Add(this.mainmenubutton);
            this.Name = "hotelresreport";
            this.Text = "Hotel Reservation Report";
            ((System.ComponentModel.ISupportInitialize)(this.hotelresdatagrid)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button mainmenubutton;
        private System.Windows.Forms.DataGridView hotelresdatagrid;
        private System.Windows.Forms.Button displaybutton;
        private System.Windows.Forms.Button backbutton;
    }
}