﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace IOOP_Assignment_3._0
{
    public partial class paymenttourres : Form
    {
        double depositamount, remainingamount;
        public paymenttourres()
        {
            InitializeComponent();
        }

        private void mainmenubutton_Click(object sender, EventArgs e)
        {
            const string message = "Do you want to go to MAIN MENU?";
            const string caption = "MAIN MENU";
            var result = MessageBox.Show(message, caption, MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes)
            {
                MainMenu newForm = new MainMenu();
                newForm.Show();
                this.Hide();
            }
        }

        private void backbutton_Click(object sender, EventArgs e)
        {
            payment newForm = new payment();
            newForm.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string connectionString = "Provider =Microsoft.ACE.OLEDB.12.0; Data Source =IOOPDb.accdb";
            string sql = "SELECT * FROM paymenttourres";
            OleDbConnection connection = new OleDbConnection(connectionString);
            OleDbDataAdapter dataadapter = new OleDbDataAdapter(sql, connection);
            DataSet ds = new DataSet();
            connection.Open();
            dataadapter.Fill(ds, "paymenttourres_table");
            connection.Close();
            tourresdataGridView.DataSource = ds;
            tourresdataGridView.DataMember = "paymenttourres_table";
        }

        private void updatebutton_Click(object sender, EventArgs e)
        {
            const string message = "Do you want to UPDATE INFO?";
            const string caption = "INFO";
            var result = MessageBox.Show(message, caption, MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes)
            {

                if (tourpaymentidtextBox.Text != "" && remainamountstatuscomboBox.SelectedIndex > -1 && addchargesstatuscomboBox.SelectedIndex > -1)//update when id is input and statuses are updated
                {
                    try
                    {
                        if (double.TryParse(depositamounttextBox.Text, out depositamount) && double.TryParse(remainingamounttextBox.Text, out remainingamount))//prevent text from being acepted into db 
                        {
                            String query1 = "UPDATE paymenttourres SET depositprice=? ,depositstatus= ?, tourremainprice=?, tourremainstatus=?, additionalcharges=?, additionalchargesstatus=? WHERE tourpaymentID = ?";
                            using (OleDbConnection conn = new OleDbConnection())
                            {
                                conn.ConnectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=IOOPDb.accdb";
                                OleDbCommand cmd = new OleDbCommand(query1, conn);
                                cmd.Parameters.AddWithValue("@depositprice", depositamounttextBox.Text);
                                cmd.Parameters.AddWithValue("@depositstatus", depositstatuscomboBox.SelectedItem.ToString());
                                cmd.Parameters.AddWithValue("@tourremainprice", remainingamounttextBox.Text);
                                cmd.Parameters.AddWithValue("@tourremainstatus", remainamountstatuscomboBox.SelectedItem.ToString());
                                cmd.Parameters.AddWithValue("@additionalcharges", addchargescomboBox.SelectedItem.ToString());
                                cmd.Parameters.AddWithValue("@additionalchargesstatus", addchargesstatuscomboBox.SelectedItem.ToString());
                                cmd.Parameters.AddWithValue("@tourpaymentID", tourpaymentidtextBox.Text);
                                conn.Open();
                                cmd.ExecuteNonQuery();
                                MessageBox.Show("Update successful.");
                                conn.Close();
                            }
                        }
                        else
                        {
                            MessageBox.Show("Please enter amount in numbers.");
                        }
                    }
                    catch
                    {
                        MessageBox.Show("Please ensure all fields are inserted.");
                    }
                }
                else
                {
                    MessageBox.Show("Please ensure all fields are inserted.");
                }
            }
        }

        private void insertbutton_Click(object sender, EventArgs e)
        {
            const string message = "Do you want to INSERT INFO?";
            const string caption = "INFO";
            var result = MessageBox.Show(message, caption, MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes)
            {
                try
                {
                    if (tourpaymentidtextBox.Text != "" && cusidtextBox.Text != "" && hotelreservationidtextBox.Text != "" && depositamounttextBox.Text != "" && depositstatuscomboBox.SelectedIndex > -1 && remainingamounttextBox.Text != "" && remainamountstatuscomboBox.SelectedIndex > -1 && addchargescomboBox.SelectedIndex > -1 && addchargesstatuscomboBox.SelectedIndex > -1)
                    {
                        if (double.TryParse(depositamounttextBox.Text, out depositamount) && double.TryParse(remainingamounttextBox.Text, out remainingamount))
                        {
                            using (OleDbConnection conn = new OleDbConnection())
                            {
                                conn.ConnectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=IOOPDb.accdb";
                                string sql = string.Format("INSERT INTO paymenttourres(tourpaymentID, depositprice, depositstatus, tourremainprice ,tourremainstatus, additionalcharges,additionalchargesstatus, tourreservationid, customerid) VALUES('{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}','{8}')", tourpaymentidtextBox.Text, depositamounttextBox.Text, depositstatuscomboBox.SelectedItem, remainingamounttextBox.Text, remainamountstatuscomboBox.SelectedItem, addchargescomboBox.SelectedItem, addchargesstatuscomboBox.SelectedItem, hotelreservationidtextBox.Text, cusidtextBox.Text);

                                using (OleDbCommand cmd = new OleDbCommand(sql, conn))
                                {
                                    conn.Open();
                                    cmd.ExecuteNonQuery();
                                    MessageBox.Show("Insertion successful.");
                                }
                            }
                        }
                        else
                        {
                            MessageBox.Show("Please enter amount in numbers.");
                        }
                    }
                    else
                    {
                        MessageBox.Show("Please ensure that all the fields are not empty.");
                    }
                }
                catch
                {
                    MessageBox.Show("Please ensure that all the fields are not empty and data is of correct format.");
                }
                
            }
        }
    }
}
