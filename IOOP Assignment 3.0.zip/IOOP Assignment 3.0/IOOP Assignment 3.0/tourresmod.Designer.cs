﻿namespace IOOP_Assignment_3._0
{
    partial class tourresmod
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.resmodmainmenubutton = new System.Windows.Forms.Button();
            this.backbutton = new System.Windows.Forms.Button();
            this.amountrescomboBox = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.touresenddateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.tourresdateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.tourrescusidlabel = new System.Windows.Forms.Label();
            this.tourdateresendlabel = new System.Windows.Forms.Label();
            this.tourrespricetextBox = new System.Windows.Forms.TextBox();
            this.tourdatereslabel = new System.Windows.Forms.Label();
            this.tourrespricelabel = new System.Windows.Forms.Label();
            this.tourresnamelabel = new System.Windows.Forms.Label();
            this.tourrescusidtextBox = new System.Windows.Forms.TextBox();
            this.tourrestextBox = new System.Windows.Forms.TextBox();
            this.tourrestouridtextBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.tourrestouridlabel = new System.Windows.Forms.Label();
            this.tourrestournamecomboBox = new System.Windows.Forms.ComboBox();
            this.updatebutton = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.displaybutton = new System.Windows.Forms.Button();
            this.tourresdataGridView = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.tourresdataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // resmodmainmenubutton
            // 
            this.resmodmainmenubutton.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.resmodmainmenubutton.Location = new System.Drawing.Point(113, 431);
            this.resmodmainmenubutton.Name = "resmodmainmenubutton";
            this.resmodmainmenubutton.Size = new System.Drawing.Size(112, 23);
            this.resmodmainmenubutton.TabIndex = 4;
            this.resmodmainmenubutton.Text = "Back to Main Menu";
            this.resmodmainmenubutton.UseVisualStyleBackColor = true;
            this.resmodmainmenubutton.Click += new System.EventHandler(this.resmodmainmenubutton_Click);
            // 
            // backbutton
            // 
            this.backbutton.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.backbutton.Location = new System.Drawing.Point(245, 431);
            this.backbutton.Name = "backbutton";
            this.backbutton.Size = new System.Drawing.Size(75, 23);
            this.backbutton.TabIndex = 5;
            this.backbutton.Text = "Back";
            this.backbutton.UseVisualStyleBackColor = true;
            this.backbutton.Click += new System.EventHandler(this.backbutton_Click);
            // 
            // amountrescomboBox
            // 
            this.amountrescomboBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.amountrescomboBox.FormattingEnabled = true;
            this.amountrescomboBox.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10"});
            this.amountrescomboBox.Location = new System.Drawing.Point(184, 325);
            this.amountrescomboBox.Name = "amountrescomboBox";
            this.amountrescomboBox.Size = new System.Drawing.Size(262, 21);
            this.amountrescomboBox.TabIndex = 54;
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(20, 328);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(131, 13);
            this.label2.TabIndex = 53;
            this.label2.Text = "Amount reserved (Max:10)";
            // 
            // touresenddateTimePicker
            // 
            this.touresenddateTimePicker.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.touresenddateTimePicker.Location = new System.Drawing.Point(184, 288);
            this.touresenddateTimePicker.Name = "touresenddateTimePicker";
            this.touresenddateTimePicker.Size = new System.Drawing.Size(262, 20);
            this.touresenddateTimePicker.TabIndex = 52;
            // 
            // tourresdateTimePicker
            // 
            this.tourresdateTimePicker.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.tourresdateTimePicker.Location = new System.Drawing.Point(184, 250);
            this.tourresdateTimePicker.Name = "tourresdateTimePicker";
            this.tourresdateTimePicker.Size = new System.Drawing.Size(262, 20);
            this.tourresdateTimePicker.TabIndex = 51;
            // 
            // tourrescusidlabel
            // 
            this.tourrescusidlabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.tourrescusidlabel.AutoSize = true;
            this.tourrescusidlabel.Location = new System.Drawing.Point(20, 171);
            this.tourrescusidlabel.Name = "tourrescusidlabel";
            this.tourrescusidlabel.Size = new System.Drawing.Size(153, 13);
            this.tourrescusidlabel.TabIndex = 50;
            this.tourrescusidlabel.Text = "Customer IC/ Passport Number";
            // 
            // tourdateresendlabel
            // 
            this.tourdateresendlabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.tourdateresendlabel.AutoSize = true;
            this.tourdateresendlabel.Location = new System.Drawing.Point(20, 294);
            this.tourdateresendlabel.Name = "tourdateresendlabel";
            this.tourdateresendlabel.Size = new System.Drawing.Size(101, 13);
            this.tourdateresendlabel.TabIndex = 46;
            this.tourdateresendlabel.Text = "Date reserved (end)";
            // 
            // tourrespricetextBox
            // 
            this.tourrespricetextBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.tourrespricetextBox.Location = new System.Drawing.Point(184, 368);
            this.tourrespricetextBox.Name = "tourrespricetextBox";
            this.tourrespricetextBox.Size = new System.Drawing.Size(262, 20);
            this.tourrespricetextBox.TabIndex = 49;
            // 
            // tourdatereslabel
            // 
            this.tourdatereslabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.tourdatereslabel.AutoSize = true;
            this.tourdatereslabel.Location = new System.Drawing.Point(20, 255);
            this.tourdatereslabel.Name = "tourdatereslabel";
            this.tourdatereslabel.Size = new System.Drawing.Size(103, 13);
            this.tourdatereslabel.TabIndex = 47;
            this.tourdatereslabel.Text = "Date reserved (start)";
            // 
            // tourrespricelabel
            // 
            this.tourrespricelabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.tourrespricelabel.AutoSize = true;
            this.tourrespricelabel.Location = new System.Drawing.Point(20, 375);
            this.tourrespricelabel.Name = "tourrespricelabel";
            this.tourrespricelabel.Size = new System.Drawing.Size(56, 13);
            this.tourrespricelabel.TabIndex = 48;
            this.tourrespricelabel.Text = "Tour Price";
            // 
            // tourresnamelabel
            // 
            this.tourresnamelabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.tourresnamelabel.AutoSize = true;
            this.tourresnamelabel.Location = new System.Drawing.Point(20, 211);
            this.tourresnamelabel.Name = "tourresnamelabel";
            this.tourresnamelabel.Size = new System.Drawing.Size(58, 13);
            this.tourresnamelabel.TabIndex = 45;
            this.tourresnamelabel.Text = "Tour name";
            // 
            // tourrescusidtextBox
            // 
            this.tourrescusidtextBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.tourrescusidtextBox.Location = new System.Drawing.Point(184, 168);
            this.tourrescusidtextBox.Name = "tourrescusidtextBox";
            this.tourrescusidtextBox.Size = new System.Drawing.Size(262, 20);
            this.tourrescusidtextBox.TabIndex = 42;
            // 
            // tourrestextBox
            // 
            this.tourrestextBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.tourrestextBox.Location = new System.Drawing.Point(184, 92);
            this.tourrestextBox.Name = "tourrestextBox";
            this.tourrestextBox.Size = new System.Drawing.Size(262, 20);
            this.tourrestextBox.TabIndex = 43;
            // 
            // tourrestouridtextBox
            // 
            this.tourrestouridtextBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.tourrestouridtextBox.Location = new System.Drawing.Point(184, 130);
            this.tourrestouridtextBox.Name = "tourrestouridtextBox";
            this.tourrestouridtextBox.Size = new System.Drawing.Size(262, 20);
            this.tourrestouridtextBox.TabIndex = 44;
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(20, 95);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(78, 13);
            this.label1.TabIndex = 40;
            this.label1.Text = "Reservation ID";
            // 
            // tourrestouridlabel
            // 
            this.tourrestouridlabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.tourrestouridlabel.AutoSize = true;
            this.tourrestouridlabel.Location = new System.Drawing.Point(20, 133);
            this.tourrestouridlabel.Name = "tourrestouridlabel";
            this.tourrestouridlabel.Size = new System.Drawing.Size(43, 13);
            this.tourrestouridlabel.TabIndex = 41;
            this.tourrestouridlabel.Text = "Tour ID";
            // 
            // tourrestournamecomboBox
            // 
            this.tourrestournamecomboBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.tourrestournamecomboBox.FormattingEnabled = true;
            this.tourrestournamecomboBox.Items.AddRange(new object[] {
            "Langkawi Island Tour (4 days 3 nights) ",
            "Cameron Highlands Tour (3 days 2 nights) ",
            "Tioman Island Tour (5 days 4 nights)"});
            this.tourrestournamecomboBox.Location = new System.Drawing.Point(184, 208);
            this.tourrestournamecomboBox.Name = "tourrestournamecomboBox";
            this.tourrestournamecomboBox.Size = new System.Drawing.Size(262, 21);
            this.tourrestournamecomboBox.TabIndex = 39;
            // 
            // updatebutton
            // 
            this.updatebutton.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.updatebutton.Location = new System.Drawing.Point(339, 431);
            this.updatebutton.Name = "updatebutton";
            this.updatebutton.Size = new System.Drawing.Size(75, 23);
            this.updatebutton.TabIndex = 57;
            this.updatebutton.Text = "Update";
            this.updatebutton.UseVisualStyleBackColor = true;
            this.updatebutton.Click += new System.EventHandler(this.updatebutton_Click);
            // 
            // label9
            // 
            this.label9.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Modern No. 20", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(64, 33);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(810, 17);
            this.label9.TabIndex = 76;
            this.label9.Text = "This Interface is to insert or update Reservation Information of Customers (Tour)" +
    ".  All fields need to be filled up.";
            // 
            // displaybutton
            // 
            this.displaybutton.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.displaybutton.Location = new System.Drawing.Point(666, 431);
            this.displaybutton.Name = "displaybutton";
            this.displaybutton.Size = new System.Drawing.Size(136, 45);
            this.displaybutton.TabIndex = 78;
            this.displaybutton.Text = "Display Tour Reservation Table";
            this.displaybutton.UseVisualStyleBackColor = true;
            this.displaybutton.Click += new System.EventHandler(this.displaybutton_Click);
            // 
            // tourresdataGridView
            // 
            this.tourresdataGridView.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.tourresdataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.tourresdataGridView.Location = new System.Drawing.Point(481, 80);
            this.tourresdataGridView.Name = "tourresdataGridView";
            this.tourresdataGridView.Size = new System.Drawing.Size(491, 333);
            this.tourresdataGridView.TabIndex = 77;
            // 
            // tourresmod
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(984, 488);
            this.Controls.Add(this.displaybutton);
            this.Controls.Add(this.tourresdataGridView);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.updatebutton);
            this.Controls.Add(this.amountrescomboBox);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.touresenddateTimePicker);
            this.Controls.Add(this.tourresdateTimePicker);
            this.Controls.Add(this.tourrescusidlabel);
            this.Controls.Add(this.tourdateresendlabel);
            this.Controls.Add(this.tourrespricetextBox);
            this.Controls.Add(this.tourdatereslabel);
            this.Controls.Add(this.tourrespricelabel);
            this.Controls.Add(this.tourresnamelabel);
            this.Controls.Add(this.tourrescusidtextBox);
            this.Controls.Add(this.tourrestextBox);
            this.Controls.Add(this.tourrestouridtextBox);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tourrestouridlabel);
            this.Controls.Add(this.tourrestournamecomboBox);
            this.Controls.Add(this.backbutton);
            this.Controls.Add(this.resmodmainmenubutton);
            this.Name = "tourresmod";
            this.Text = "Tour Reservation Modification";
            ((System.ComponentModel.ISupportInitialize)(this.tourresdataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button resmodmainmenubutton;
        private System.Windows.Forms.Button backbutton;
        private System.Windows.Forms.ComboBox amountrescomboBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DateTimePicker touresenddateTimePicker;
        private System.Windows.Forms.DateTimePicker tourresdateTimePicker;
        private System.Windows.Forms.Label tourrescusidlabel;
        private System.Windows.Forms.Label tourdateresendlabel;
        private System.Windows.Forms.TextBox tourrespricetextBox;
        private System.Windows.Forms.Label tourdatereslabel;
        private System.Windows.Forms.Label tourrespricelabel;
        private System.Windows.Forms.Label tourresnamelabel;
        private System.Windows.Forms.TextBox tourrescusidtextBox;
        private System.Windows.Forms.TextBox tourrestextBox;
        private System.Windows.Forms.TextBox tourrestouridtextBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label tourrestouridlabel;
        private System.Windows.Forms.ComboBox tourrestournamecomboBox;
        private System.Windows.Forms.Button updatebutton;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button displaybutton;
        private System.Windows.Forms.DataGridView tourresdataGridView;
    }
}