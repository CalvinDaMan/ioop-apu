﻿namespace IOOP_Assignment_3._0
{
    partial class Reportgen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.managerusernamelabel = new System.Windows.Forms.Label();
            this.managerpasswordlabel = new System.Windows.Forms.Label();
            this.managerusernametextBox = new System.Windows.Forms.TextBox();
            this.managerpasswordtextBox = new System.Windows.Forms.TextBox();
            this.managerloginbutton = new System.Windows.Forms.Button();
            this.viewpasswordcheckBox = new System.Windows.Forms.CheckBox();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(88, 209);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 1;
            this.button1.Text = "Logout";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // managerusernamelabel
            // 
            this.managerusernamelabel.AutoSize = true;
            this.managerusernamelabel.Location = new System.Drawing.Point(47, 56);
            this.managerusernamelabel.Name = "managerusernamelabel";
            this.managerusernamelabel.Size = new System.Drawing.Size(55, 13);
            this.managerusernamelabel.TabIndex = 2;
            this.managerusernamelabel.Text = "Username";
            // 
            // managerpasswordlabel
            // 
            this.managerpasswordlabel.AutoSize = true;
            this.managerpasswordlabel.Location = new System.Drawing.Point(47, 106);
            this.managerpasswordlabel.Name = "managerpasswordlabel";
            this.managerpasswordlabel.Size = new System.Drawing.Size(58, 13);
            this.managerpasswordlabel.TabIndex = 3;
            this.managerpasswordlabel.Text = "Passsword";
            // 
            // managerusernametextBox
            // 
            this.managerusernametextBox.Location = new System.Drawing.Point(156, 53);
            this.managerusernametextBox.Name = "managerusernametextBox";
            this.managerusernametextBox.Size = new System.Drawing.Size(170, 20);
            this.managerusernametextBox.TabIndex = 4;
            // 
            // managerpasswordtextBox
            // 
            this.managerpasswordtextBox.Location = new System.Drawing.Point(156, 103);
            this.managerpasswordtextBox.Name = "managerpasswordtextBox";
            this.managerpasswordtextBox.Size = new System.Drawing.Size(170, 20);
            this.managerpasswordtextBox.TabIndex = 4;
            this.managerpasswordtextBox.UseSystemPasswordChar = true;
            // 
            // managerloginbutton
            // 
            this.managerloginbutton.Location = new System.Drawing.Point(239, 209);
            this.managerloginbutton.Name = "managerloginbutton";
            this.managerloginbutton.Size = new System.Drawing.Size(75, 23);
            this.managerloginbutton.TabIndex = 5;
            this.managerloginbutton.Text = "Login";
            this.managerloginbutton.UseVisualStyleBackColor = true;
            this.managerloginbutton.Click += new System.EventHandler(this.managerloginbutton_Click);
            // 
            // viewpasswordcheckBox
            // 
            this.viewpasswordcheckBox.AutoSize = true;
            this.viewpasswordcheckBox.Location = new System.Drawing.Point(166, 154);
            this.viewpasswordcheckBox.Name = "viewpasswordcheckBox";
            this.viewpasswordcheckBox.Size = new System.Drawing.Size(98, 17);
            this.viewpasswordcheckBox.TabIndex = 6;
            this.viewpasswordcheckBox.Text = "View Password";
            this.viewpasswordcheckBox.UseVisualStyleBackColor = true;
            this.viewpasswordcheckBox.CheckedChanged += new System.EventHandler(this.viewpasswordcheckBox_CheckedChanged);
            // 
            // Reportgen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(410, 295);
            this.Controls.Add(this.viewpasswordcheckBox);
            this.Controls.Add(this.managerloginbutton);
            this.Controls.Add(this.managerpasswordtextBox);
            this.Controls.Add(this.managerusernametextBox);
            this.Controls.Add(this.managerpasswordlabel);
            this.Controls.Add(this.managerusernamelabel);
            this.Controls.Add(this.button1);
            this.Name = "Reportgen";
            this.Text = "REPORT GENERATION LOGIN";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label managerusernamelabel;
        private System.Windows.Forms.Label managerpasswordlabel;
        private System.Windows.Forms.TextBox managerusernametextBox;
        private System.Windows.Forms.TextBox managerpasswordtextBox;
        private System.Windows.Forms.Button managerloginbutton;
        private System.Windows.Forms.CheckBox viewpasswordcheckBox;
    }
}