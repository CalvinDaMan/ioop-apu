﻿namespace IOOP_Assignment_3._0
{
    partial class CusInfo_tr
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.backtoresbuttontr = new System.Windows.Forms.Button();
            this.mainmenubuttontr = new System.Windows.Forms.Button();
            this.cuscontacttextBoxtr = new System.Windows.Forms.TextBox();
            this.emailtextBoxtr = new System.Windows.Forms.TextBox();
            this.cusaddresstextBoxtr = new System.Windows.Forms.TextBox();
            this.cusnametextBoxtr = new System.Windows.Forms.TextBox();
            this.cusidtextBoxtr = new System.Windows.Forms.TextBox();
            this.confirmbuttontr = new System.Windows.Forms.Button();
            this.dateofbookingtr = new System.Windows.Forms.Label();
            this.cuscontactlabeltr = new System.Windows.Forms.Label();
            this.emaillabeltr = new System.Windows.Forms.Label();
            this.addresslabeltr = new System.Windows.Forms.Label();
            this.cusnamelabeltr = new System.Windows.Forms.Label();
            this.cusidlabeltr = new System.Windows.Forms.Label();
            this.cusinfolabeltr = new System.Windows.Forms.Label();
            this.cusinfotourresdateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.SuspendLayout();
            // 
            // backtoresbuttontr
            // 
            this.backtoresbuttontr.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.backtoresbuttontr.Location = new System.Drawing.Point(178, 274);
            this.backtoresbuttontr.Name = "backtoresbuttontr";
            this.backtoresbuttontr.Size = new System.Drawing.Size(75, 35);
            this.backtoresbuttontr.TabIndex = 31;
            this.backtoresbuttontr.Text = "Back to Reservation";
            this.backtoresbuttontr.UseVisualStyleBackColor = true;
            this.backtoresbuttontr.Click += new System.EventHandler(this.backtoresbuttontr_Click);
            // 
            // mainmenubuttontr
            // 
            this.mainmenubuttontr.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.mainmenubuttontr.Location = new System.Drawing.Point(23, 274);
            this.mainmenubuttontr.Name = "mainmenubuttontr";
            this.mainmenubuttontr.Size = new System.Drawing.Size(114, 23);
            this.mainmenubuttontr.TabIndex = 30;
            this.mainmenubuttontr.Text = "Back to main menu";
            this.mainmenubuttontr.UseVisualStyleBackColor = true;
            this.mainmenubuttontr.Click += new System.EventHandler(this.mainmenubuttontr_Click);
            // 
            // cuscontacttextBoxtr
            // 
            this.cuscontacttextBoxtr.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.cuscontacttextBoxtr.Location = new System.Drawing.Point(189, 188);
            this.cuscontacttextBoxtr.Name = "cuscontacttextBoxtr";
            this.cuscontacttextBoxtr.Size = new System.Drawing.Size(191, 20);
            this.cuscontacttextBoxtr.TabIndex = 28;
            // 
            // emailtextBoxtr
            // 
            this.emailtextBoxtr.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.emailtextBoxtr.Location = new System.Drawing.Point(189, 150);
            this.emailtextBoxtr.Name = "emailtextBoxtr";
            this.emailtextBoxtr.Size = new System.Drawing.Size(191, 20);
            this.emailtextBoxtr.TabIndex = 27;
            // 
            // cusaddresstextBoxtr
            // 
            this.cusaddresstextBoxtr.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.cusaddresstextBoxtr.Location = new System.Drawing.Point(189, 115);
            this.cusaddresstextBoxtr.Name = "cusaddresstextBoxtr";
            this.cusaddresstextBoxtr.Size = new System.Drawing.Size(191, 20);
            this.cusaddresstextBoxtr.TabIndex = 26;
            // 
            // cusnametextBoxtr
            // 
            this.cusnametextBoxtr.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.cusnametextBoxtr.Location = new System.Drawing.Point(189, 77);
            this.cusnametextBoxtr.Name = "cusnametextBoxtr";
            this.cusnametextBoxtr.Size = new System.Drawing.Size(191, 20);
            this.cusnametextBoxtr.TabIndex = 25;
            // 
            // cusidtextBoxtr
            // 
            this.cusidtextBoxtr.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.cusidtextBoxtr.Location = new System.Drawing.Point(189, 42);
            this.cusidtextBoxtr.Name = "cusidtextBoxtr";
            this.cusidtextBoxtr.Size = new System.Drawing.Size(191, 20);
            this.cusidtextBoxtr.TabIndex = 24;
            // 
            // confirmbuttontr
            // 
            this.confirmbuttontr.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.confirmbuttontr.Location = new System.Drawing.Point(305, 274);
            this.confirmbuttontr.Name = "confirmbuttontr";
            this.confirmbuttontr.Size = new System.Drawing.Size(75, 23);
            this.confirmbuttontr.TabIndex = 23;
            this.confirmbuttontr.Text = "Confirm";
            this.confirmbuttontr.UseVisualStyleBackColor = true;
            this.confirmbuttontr.Click += new System.EventHandler(this.confirmbuttontr_Click);
            // 
            // dateofbookingtr
            // 
            this.dateofbookingtr.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.dateofbookingtr.AutoSize = true;
            this.dateofbookingtr.Location = new System.Drawing.Point(20, 232);
            this.dateofbookingtr.Name = "dateofbookingtr";
            this.dateofbookingtr.Size = new System.Drawing.Size(83, 13);
            this.dateofbookingtr.TabIndex = 22;
            this.dateofbookingtr.Text = "Date of booking";
            // 
            // cuscontactlabeltr
            // 
            this.cuscontactlabeltr.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.cuscontactlabeltr.AutoSize = true;
            this.cuscontactlabeltr.Location = new System.Drawing.Point(20, 195);
            this.cuscontactlabeltr.Name = "cuscontactlabeltr";
            this.cuscontactlabeltr.Size = new System.Drawing.Size(90, 13);
            this.cuscontactlabeltr.TabIndex = 21;
            this.cuscontactlabeltr.Text = "Customer contact";
            // 
            // emaillabeltr
            // 
            this.emaillabeltr.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.emaillabeltr.AutoSize = true;
            this.emaillabeltr.Location = new System.Drawing.Point(20, 157);
            this.emaillabeltr.Name = "emaillabeltr";
            this.emaillabeltr.Size = new System.Drawing.Size(32, 13);
            this.emaillabeltr.TabIndex = 20;
            this.emaillabeltr.Text = "Email";
            // 
            // addresslabeltr
            // 
            this.addresslabeltr.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.addresslabeltr.AutoSize = true;
            this.addresslabeltr.Location = new System.Drawing.Point(20, 122);
            this.addresslabeltr.Name = "addresslabeltr";
            this.addresslabeltr.Size = new System.Drawing.Size(92, 13);
            this.addresslabeltr.TabIndex = 19;
            this.addresslabeltr.Text = "Customer Address";
            // 
            // cusnamelabeltr
            // 
            this.cusnamelabeltr.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.cusnamelabeltr.AutoSize = true;
            this.cusnamelabeltr.Location = new System.Drawing.Point(20, 84);
            this.cusnamelabeltr.Name = "cusnamelabeltr";
            this.cusnamelabeltr.Size = new System.Drawing.Size(82, 13);
            this.cusnamelabeltr.TabIndex = 18;
            this.cusnamelabeltr.Text = "Customer Name";
            // 
            // cusidlabeltr
            // 
            this.cusidlabeltr.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.cusidlabeltr.AutoSize = true;
            this.cusidlabeltr.Location = new System.Drawing.Point(20, 49);
            this.cusidlabeltr.Name = "cusidlabeltr";
            this.cusidlabeltr.Size = new System.Drawing.Size(153, 13);
            this.cusidlabeltr.TabIndex = 17;
            this.cusidlabeltr.Text = "Customer IC/ Passport Number";
            // 
            // cusinfolabeltr
            // 
            this.cusinfolabeltr.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.cusinfolabeltr.AutoSize = true;
            this.cusinfolabeltr.Font = new System.Drawing.Font("Segoe UI Symbol", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cusinfolabeltr.Location = new System.Drawing.Point(20, 12);
            this.cusinfolabeltr.Name = "cusinfolabeltr";
            this.cusinfolabeltr.Size = new System.Drawing.Size(335, 21);
            this.cusinfolabeltr.TabIndex = 16;
            this.cusinfolabeltr.Text = "Customer Information (Tour Reservation)";
            // 
            // cusinfotourresdateTimePicker
            // 
            this.cusinfotourresdateTimePicker.Location = new System.Drawing.Point(189, 228);
            this.cusinfotourresdateTimePicker.Name = "cusinfotourresdateTimePicker";
            this.cusinfotourresdateTimePicker.Size = new System.Drawing.Size(191, 20);
            this.cusinfotourresdateTimePicker.TabIndex = 32;
            // 
            // CusInfo_tr
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(400, 320);
            this.Controls.Add(this.cusinfotourresdateTimePicker);
            this.Controls.Add(this.backtoresbuttontr);
            this.Controls.Add(this.mainmenubuttontr);
            this.Controls.Add(this.cuscontacttextBoxtr);
            this.Controls.Add(this.emailtextBoxtr);
            this.Controls.Add(this.cusaddresstextBoxtr);
            this.Controls.Add(this.cusnametextBoxtr);
            this.Controls.Add(this.cusidtextBoxtr);
            this.Controls.Add(this.confirmbuttontr);
            this.Controls.Add(this.dateofbookingtr);
            this.Controls.Add(this.cuscontactlabeltr);
            this.Controls.Add(this.emaillabeltr);
            this.Controls.Add(this.addresslabeltr);
            this.Controls.Add(this.cusnamelabeltr);
            this.Controls.Add(this.cusidlabeltr);
            this.Controls.Add(this.cusinfolabeltr);
            this.Name = "CusInfo_tr";
            this.Text = "Cus Info (Tour Reservation)";
            this.Load += new System.EventHandler(this.CusInfo_tr_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button backtoresbuttontr;
        private System.Windows.Forms.Button mainmenubuttontr;
        private System.Windows.Forms.TextBox cuscontacttextBoxtr;
        private System.Windows.Forms.TextBox emailtextBoxtr;
        private System.Windows.Forms.TextBox cusaddresstextBoxtr;
        private System.Windows.Forms.TextBox cusnametextBoxtr;
        private System.Windows.Forms.TextBox cusidtextBoxtr;
        private System.Windows.Forms.Button confirmbuttontr;
        private System.Windows.Forms.Label dateofbookingtr;
        private System.Windows.Forms.Label cuscontactlabeltr;
        private System.Windows.Forms.Label emaillabeltr;
        private System.Windows.Forms.Label addresslabeltr;
        private System.Windows.Forms.Label cusnamelabeltr;
        private System.Windows.Forms.Label cusidlabeltr;
        private System.Windows.Forms.Label cusinfolabeltr;
        private System.Windows.Forms.DateTimePicker cusinfotourresdateTimePicker;
    }
}