﻿namespace IOOP_Assignment_3._0
{
    partial class viewchangetour
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tourchangedataGridView = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.tourchangedataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // tourchangedataGridView
            // 
            this.tourchangedataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.tourchangedataGridView.Location = new System.Drawing.Point(1, -1);
            this.tourchangedataGridView.Name = "tourchangedataGridView";
            this.tourchangedataGridView.Size = new System.Drawing.Size(619, 338);
            this.tourchangedataGridView.TabIndex = 1;
            // 
            // viewchangetour
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(620, 370);
            this.Controls.Add(this.tourchangedataGridView);
            this.Name = "viewchangetour";
            this.Text = "viewchangetour";
            this.Load += new System.EventHandler(this.viewchangetour_Load);
            ((System.ComponentModel.ISupportInitialize)(this.tourchangedataGridView)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView tourchangedataGridView;
    }
}