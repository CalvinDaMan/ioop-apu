﻿namespace IOOP_Assignment_3._0
{
    partial class holiresmod
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.resmodmainmenubutton = new System.Windows.Forms.Button();
            this.backbutton = new System.Windows.Forms.Button();
            this.updatebutton = new System.Windows.Forms.Button();
            this.amountrescomboBox = new System.Windows.Forms.ComboBox();
            this.holirenddateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.holirstartdateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.holirescusidtextBox = new System.Windows.Forms.TextBox();
            this.holirescusidlabel = new System.Windows.Forms.Label();
            this.holirestextBox = new System.Windows.Forms.TextBox();
            this.hotelresidlabel = new System.Windows.Forms.Label();
            this.holidayresholidayidtextBox = new System.Windows.Forms.TextBox();
            this.holidayresholidayidlabel = new System.Windows.Forms.Label();
            this.holidaydatereslabel = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.packagepricetextBox = new System.Windows.Forms.TextBox();
            this.packagepricelabel = new System.Windows.Forms.Label();
            this.holidaylabel = new System.Windows.Forms.Label();
            this.holidayresroomtypecomboBox = new System.Windows.Forms.ComboBox();
            this.holidaypackagecomboBox = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.holiresdataGridView = new System.Windows.Forms.DataGridView();
            this.displayholiresbutton = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.holiresdataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // resmodmainmenubutton
            // 
            this.resmodmainmenubutton.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.resmodmainmenubutton.Location = new System.Drawing.Point(84, 434);
            this.resmodmainmenubutton.Name = "resmodmainmenubutton";
            this.resmodmainmenubutton.Size = new System.Drawing.Size(112, 23);
            this.resmodmainmenubutton.TabIndex = 4;
            this.resmodmainmenubutton.Text = "Back to Main Menu";
            this.resmodmainmenubutton.UseVisualStyleBackColor = true;
            this.resmodmainmenubutton.Click += new System.EventHandler(this.resmodmainmenubutton_Click);
            // 
            // backbutton
            // 
            this.backbutton.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.backbutton.Location = new System.Drawing.Point(218, 434);
            this.backbutton.Name = "backbutton";
            this.backbutton.Size = new System.Drawing.Size(75, 23);
            this.backbutton.TabIndex = 5;
            this.backbutton.Text = "Back";
            this.backbutton.UseVisualStyleBackColor = true;
            this.backbutton.Click += new System.EventHandler(this.backbutton_Click);
            // 
            // updatebutton
            // 
            this.updatebutton.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.updatebutton.Location = new System.Drawing.Point(313, 434);
            this.updatebutton.Name = "updatebutton";
            this.updatebutton.Size = new System.Drawing.Size(75, 23);
            this.updatebutton.TabIndex = 56;
            this.updatebutton.Text = "Update";
            this.updatebutton.UseVisualStyleBackColor = true;
            this.updatebutton.Click += new System.EventHandler(this.updatebutton_Click);
            // 
            // amountrescomboBox
            // 
            this.amountrescomboBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.amountrescomboBox.FormattingEnabled = true;
            this.amountrescomboBox.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10"});
            this.amountrescomboBox.Location = new System.Drawing.Point(186, 333);
            this.amountrescomboBox.Name = "amountrescomboBox";
            this.amountrescomboBox.Size = new System.Drawing.Size(275, 21);
            this.amountrescomboBox.TabIndex = 74;
            // 
            // holirenddateTimePicker2
            // 
            this.holirenddateTimePicker2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.holirenddateTimePicker2.Location = new System.Drawing.Point(186, 254);
            this.holirenddateTimePicker2.Name = "holirenddateTimePicker2";
            this.holirenddateTimePicker2.Size = new System.Drawing.Size(275, 20);
            this.holirenddateTimePicker2.TabIndex = 73;
            // 
            // holirstartdateTimePicker
            // 
            this.holirstartdateTimePicker.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.holirstartdateTimePicker.Location = new System.Drawing.Point(186, 217);
            this.holirstartdateTimePicker.Name = "holirstartdateTimePicker";
            this.holirstartdateTimePicker.Size = new System.Drawing.Size(275, 20);
            this.holirstartdateTimePicker.TabIndex = 72;
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(16, 260);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(102, 13);
            this.label2.TabIndex = 71;
            this.label2.Text = "Date reserved (End)";
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(16, 296);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(62, 13);
            this.label1.TabIndex = 70;
            this.label1.Text = "Room Type";
            // 
            // holirescusidtextBox
            // 
            this.holirescusidtextBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.holirescusidtextBox.Location = new System.Drawing.Point(186, 133);
            this.holirescusidtextBox.Name = "holirescusidtextBox";
            this.holirescusidtextBox.Size = new System.Drawing.Size(275, 20);
            this.holirescusidtextBox.TabIndex = 68;
            // 
            // holirescusidlabel
            // 
            this.holirescusidlabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.holirescusidlabel.AutoSize = true;
            this.holirescusidlabel.Location = new System.Drawing.Point(16, 136);
            this.holirescusidlabel.Name = "holirescusidlabel";
            this.holirescusidlabel.Size = new System.Drawing.Size(153, 13);
            this.holirescusidlabel.TabIndex = 66;
            this.holirescusidlabel.Text = "Customer IC/ Passport Number";
            // 
            // holirestextBox
            // 
            this.holirestextBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.holirestextBox.Location = new System.Drawing.Point(186, 58);
            this.holirestextBox.Name = "holirestextBox";
            this.holirestextBox.Size = new System.Drawing.Size(275, 20);
            this.holirestextBox.TabIndex = 69;
            // 
            // hotelresidlabel
            // 
            this.hotelresidlabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.hotelresidlabel.AutoSize = true;
            this.hotelresidlabel.Location = new System.Drawing.Point(16, 61);
            this.hotelresidlabel.Name = "hotelresidlabel";
            this.hotelresidlabel.Size = new System.Drawing.Size(78, 13);
            this.hotelresidlabel.TabIndex = 65;
            this.hotelresidlabel.Text = "Reservation ID";
            // 
            // holidayresholidayidtextBox
            // 
            this.holidayresholidayidtextBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.holidayresholidayidtextBox.Location = new System.Drawing.Point(186, 96);
            this.holidayresholidayidtextBox.Name = "holidayresholidayidtextBox";
            this.holidayresholidayidtextBox.Size = new System.Drawing.Size(275, 20);
            this.holidayresholidayidtextBox.TabIndex = 67;
            // 
            // holidayresholidayidlabel
            // 
            this.holidayresholidayidlabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.holidayresholidayidlabel.AutoSize = true;
            this.holidayresholidayidlabel.Location = new System.Drawing.Point(16, 99);
            this.holidayresholidayidlabel.Name = "holidayresholidayidlabel";
            this.holidayresholidayidlabel.Size = new System.Drawing.Size(56, 13);
            this.holidayresholidayidlabel.TabIndex = 64;
            this.holidayresholidayidlabel.Text = "Holiday ID";
            // 
            // holidaydatereslabel
            // 
            this.holidaydatereslabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.holidaydatereslabel.AutoSize = true;
            this.holidaydatereslabel.Location = new System.Drawing.Point(16, 222);
            this.holidaydatereslabel.Name = "holidaydatereslabel";
            this.holidaydatereslabel.Size = new System.Drawing.Size(105, 13);
            this.holidaydatereslabel.TabIndex = 63;
            this.holidaydatereslabel.Text = "Date reserved (Start)";
            // 
            // label3
            // 
            this.label3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(16, 336);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(131, 13);
            this.label3.TabIndex = 61;
            this.label3.Text = "Amount reserved (Max:10)";
            // 
            // packagepricetextBox
            // 
            this.packagepricetextBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.packagepricetextBox.Location = new System.Drawing.Point(186, 379);
            this.packagepricetextBox.Name = "packagepricetextBox";
            this.packagepricetextBox.Size = new System.Drawing.Size(275, 20);
            this.packagepricetextBox.TabIndex = 62;
            // 
            // packagepricelabel
            // 
            this.packagepricelabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.packagepricelabel.AutoSize = true;
            this.packagepricelabel.Location = new System.Drawing.Point(16, 379);
            this.packagepricelabel.Name = "packagepricelabel";
            this.packagepricelabel.Size = new System.Drawing.Size(77, 13);
            this.packagepricelabel.TabIndex = 60;
            this.packagepricelabel.Text = "Package Price";
            // 
            // holidaylabel
            // 
            this.holidaylabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.holidaylabel.AutoSize = true;
            this.holidaylabel.Location = new System.Drawing.Point(16, 179);
            this.holidaylabel.Name = "holidaylabel";
            this.holidaylabel.Size = new System.Drawing.Size(87, 13);
            this.holidaylabel.TabIndex = 59;
            this.holidaylabel.Text = "Holiday package";
            // 
            // holidayresroomtypecomboBox
            // 
            this.holidayresroomtypecomboBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.holidayresroomtypecomboBox.FormattingEnabled = true;
            this.holidayresroomtypecomboBox.Items.AddRange(new object[] {
            "Single",
            "Double",
            "Family Suite"});
            this.holidayresroomtypecomboBox.Location = new System.Drawing.Point(186, 293);
            this.holidayresroomtypecomboBox.Name = "holidayresroomtypecomboBox";
            this.holidayresroomtypecomboBox.Size = new System.Drawing.Size(275, 21);
            this.holidayresroomtypecomboBox.TabIndex = 58;
            // 
            // holidaypackagecomboBox
            // 
            this.holidaypackagecomboBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.holidaypackagecomboBox.FormattingEnabled = true;
            this.holidaypackagecomboBox.Items.AddRange(new object[] {
            "Langkawi Island Tour (4 days 3 nights) Berjaya Resort",
            "Langkawi Island Tour (4 days 3 nights) Adya Hotel",
            "Cameron Highlands Tour (3 days 2 nights) Cameron Highlands Resort",
            "Cameron Highlands Tour (3 days 2 nights) Century Pines Resort",
            "Tioman Island Tour (5 days 4 nights) Tunamaya Beach & Spa Resort",
            "Tioman Island Tour (5 days 4 nights) Berjaya Resort"});
            this.holidaypackagecomboBox.Location = new System.Drawing.Point(186, 176);
            this.holidaypackagecomboBox.Name = "holidaypackagecomboBox";
            this.holidaypackagecomboBox.Size = new System.Drawing.Size(275, 21);
            this.holidaypackagecomboBox.TabIndex = 57;
            // 
            // label9
            // 
            this.label9.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Modern No. 20", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(102, 9);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(833, 17);
            this.label9.TabIndex = 75;
            this.label9.Text = "This Interface is to insert or update Reservation Information of Customers (Holid" +
    "ay).  All fields need to be filled up.";
            // 
            // holiresdataGridView
            // 
            this.holiresdataGridView.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.holiresdataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.holiresdataGridView.Location = new System.Drawing.Point(478, 58);
            this.holiresdataGridView.Name = "holiresdataGridView";
            this.holiresdataGridView.Size = new System.Drawing.Size(525, 341);
            this.holiresdataGridView.TabIndex = 76;
            // 
            // displayholiresbutton
            // 
            this.displayholiresbutton.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.displayholiresbutton.Location = new System.Drawing.Point(678, 417);
            this.displayholiresbutton.Name = "displayholiresbutton";
            this.displayholiresbutton.Size = new System.Drawing.Size(133, 40);
            this.displayholiresbutton.TabIndex = 77;
            this.displayholiresbutton.Text = "Display Holiday Reservation Table";
            this.displayholiresbutton.UseVisualStyleBackColor = true;
            this.displayholiresbutton.Click += new System.EventHandler(this.displayholiresbutton_Click);
            // 
            // holiresmod
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1015, 469);
            this.Controls.Add(this.displayholiresbutton);
            this.Controls.Add(this.holiresdataGridView);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.amountrescomboBox);
            this.Controls.Add(this.holirenddateTimePicker2);
            this.Controls.Add(this.holirstartdateTimePicker);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.holirescusidtextBox);
            this.Controls.Add(this.holirescusidlabel);
            this.Controls.Add(this.holirestextBox);
            this.Controls.Add(this.hotelresidlabel);
            this.Controls.Add(this.holidayresholidayidtextBox);
            this.Controls.Add(this.holidayresholidayidlabel);
            this.Controls.Add(this.holidaydatereslabel);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.packagepricetextBox);
            this.Controls.Add(this.packagepricelabel);
            this.Controls.Add(this.holidaylabel);
            this.Controls.Add(this.holidayresroomtypecomboBox);
            this.Controls.Add(this.holidaypackagecomboBox);
            this.Controls.Add(this.updatebutton);
            this.Controls.Add(this.backbutton);
            this.Controls.Add(this.resmodmainmenubutton);
            this.Name = "holiresmod";
            this.Text = "Holiday Reservation Modification";
            ((System.ComponentModel.ISupportInitialize)(this.holiresdataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button resmodmainmenubutton;
        private System.Windows.Forms.Button backbutton;
        private System.Windows.Forms.Button updatebutton;
        private System.Windows.Forms.ComboBox amountrescomboBox;
        private System.Windows.Forms.DateTimePicker holirenddateTimePicker2;
        private System.Windows.Forms.DateTimePicker holirstartdateTimePicker;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox holirescusidtextBox;
        private System.Windows.Forms.Label holirescusidlabel;
        private System.Windows.Forms.TextBox holirestextBox;
        private System.Windows.Forms.Label hotelresidlabel;
        private System.Windows.Forms.TextBox holidayresholidayidtextBox;
        private System.Windows.Forms.Label holidayresholidayidlabel;
        private System.Windows.Forms.Label holidaydatereslabel;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox packagepricetextBox;
        private System.Windows.Forms.Label packagepricelabel;
        private System.Windows.Forms.Label holidaylabel;
        private System.Windows.Forms.ComboBox holidayresroomtypecomboBox;
        private System.Windows.Forms.ComboBox holidaypackagecomboBox;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.DataGridView holiresdataGridView;
        private System.Windows.Forms.Button displayholiresbutton;
    }
}