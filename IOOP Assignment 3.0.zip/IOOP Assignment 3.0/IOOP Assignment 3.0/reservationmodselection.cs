﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IOOP_Assignment_3._0
{
    public partial class reservationmodselection : Form
    {
        public reservationmodselection()
        {
            InitializeComponent();
        }

        private void rescancmainmenubutton_Click(object sender, EventArgs e)
        {
            const string message = "Do you want to go to MAIN MENU?";
            const string caption = "MAIN MENU";
            var result = MessageBox.Show(message, caption, MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes) //if user click on "yes", the program would be closed, 
                                            //if not message box would be close
            {
                MainMenu newForm = new MainMenu();
                newForm.Show();
                this.Hide();
            }
        }

        private void proceedbutton_Click(object sender, EventArgs e)
        {
            if (hotelresradioButton.Checked==true&&tourresradioButton.Checked==false&&holidayresradioButton.Checked==false)
            {
                hotelresmod newForm = new hotelresmod();
                newForm.Show();
                this.Hide();
            }
            else if (hotelresradioButton.Checked == false && tourresradioButton.Checked == true && holidayresradioButton.Checked == false)
            {
                tourresmod newForm = new tourresmod();
                newForm.Show();
                this.Hide();
            }
            else if ((hotelresradioButton.Checked == false && tourresradioButton.Checked == false && holidayresradioButton.Checked == true))
            {
                holiresmod newForm = new holiresmod();
                newForm.Show();
                this.Hide();
            }
        }
    }
}
