﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IOOP_Assignment_3._0
{
    class hotel
    {
        private string _hotelname;
        private string _roomtype;
        private double _roomprice;
        private double _dayreserved;
       
        public string hotelname
        {
            get
            {
                return _hotelname;
            }
            set
            {
                _hotelname = value;
            }
        }
        public string roomtype
        {
            get
            {
                return _roomtype;
            }
            set
            {
                _roomtype = value;
            }
        }
        public double roomprice
        {
            get
            {
                return _roomprice;
            }
            set
            {
                _roomprice = value;
            }
        }
        public double dayreserved
        {
            get
            {
                return _dayreserved;
            }
            set
            {
                _dayreserved = value;
            }
        }

       
        
        public hotel(string hn, string rt, double rp, double dr)
        {
            _hotelname = hn;
            _roomtype = rt;
            _roomprice = rp;
            _dayreserved = dr;            
        }

       
        public double price(double dayreserved, double roomprice)
        {
            
            return dayreserved * roomprice;
        }

        
    }
}
