﻿namespace IOOP_Assignment_3._0
{
    partial class HotelRes
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.hotelresmainmenubutton = new System.Windows.Forms.Button();
            this.hotelreshotelnamecomboBox = new System.Windows.Forms.ComboBox();
            this.hotelreshotelidlabel = new System.Windows.Forms.Label();
            this.hotelreshotelnamelabel = new System.Windows.Forms.Label();
            this.hotelreshotelidtextBox = new System.Windows.Forms.TextBox();
            this.hotelreshotelpricelabel = new System.Windows.Forms.Label();
            this.hotelrespricetextBox = new System.Windows.Forms.TextBox();
            this.hoteldatereservedlabel = new System.Windows.Forms.Label();
            this.hotelresconfirmbutton = new System.Windows.Forms.Button();
            this.hotelidexamplelabel = new System.Windows.Forms.Label();
            this.backtoresbutton_hotelres = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.hotelrescusidtextBox = new System.Windows.Forms.TextBox();
            this.hotelresenddateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.hotelresstartdateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.hotelresroomtypelabel = new System.Windows.Forms.Label();
            this.hotelresroomtypecomboBox = new System.Windows.Forms.ComboBox();
            this.amountlabel = new System.Windows.Forms.Label();
            this.amountcomboBox = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.hotelrestextBox = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // hotelresmainmenubutton
            // 
            this.hotelresmainmenubutton.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.hotelresmainmenubutton.Location = new System.Drawing.Point(81, 448);
            this.hotelresmainmenubutton.Name = "hotelresmainmenubutton";
            this.hotelresmainmenubutton.Size = new System.Drawing.Size(131, 23);
            this.hotelresmainmenubutton.TabIndex = 1;
            this.hotelresmainmenubutton.Text = "Back to main menu";
            this.hotelresmainmenubutton.UseVisualStyleBackColor = true;
            this.hotelresmainmenubutton.Click += new System.EventHandler(this.hotelresmainmenubutton_Click);
            // 
            // hotelreshotelnamecomboBox
            // 
            this.hotelreshotelnamecomboBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.hotelreshotelnamecomboBox.FormattingEnabled = true;
            this.hotelreshotelnamecomboBox.Items.AddRange(new object[] {
            "(Cameron Highlands) Cameron Highlands Resort",
            "(Cameron Highlands) Century Pines Resort ",
            "(Langkawi) Berjaya Langkawi Resort",
            "(Langkawi) Adya Hotel Langkawi",
            "(Tioman) Tunamaya Beach & Spa Resort",
            "(Tioman) Berjaya Tioman Resort"});
            this.hotelreshotelnamecomboBox.Location = new System.Drawing.Point(236, 283);
            this.hotelreshotelnamecomboBox.Name = "hotelreshotelnamecomboBox";
            this.hotelreshotelnamecomboBox.Size = new System.Drawing.Size(276, 21);
            this.hotelreshotelnamecomboBox.TabIndex = 2;
            this.hotelreshotelnamecomboBox.SelectedIndexChanged += new System.EventHandler(this.hotelreshotelnamecomboBox_SelectedIndexChanged);
            // 
            // hotelreshotelidlabel
            // 
            this.hotelreshotelidlabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.hotelreshotelidlabel.AutoSize = true;
            this.hotelreshotelidlabel.Location = new System.Drawing.Point(57, 129);
            this.hotelreshotelidlabel.Name = "hotelreshotelidlabel";
            this.hotelreshotelidlabel.Size = new System.Drawing.Size(46, 13);
            this.hotelreshotelidlabel.TabIndex = 3;
            this.hotelreshotelidlabel.Text = "Hotel ID";
            // 
            // hotelreshotelnamelabel
            // 
            this.hotelreshotelnamelabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.hotelreshotelnamelabel.AutoSize = true;
            this.hotelreshotelnamelabel.Location = new System.Drawing.Point(57, 286);
            this.hotelreshotelnamelabel.Name = "hotelreshotelnamelabel";
            this.hotelreshotelnamelabel.Size = new System.Drawing.Size(63, 13);
            this.hotelreshotelnamelabel.TabIndex = 3;
            this.hotelreshotelnamelabel.Text = "Hotel Name";
            // 
            // hotelreshotelidtextBox
            // 
            this.hotelreshotelidtextBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.hotelreshotelidtextBox.Location = new System.Drawing.Point(236, 126);
            this.hotelreshotelidtextBox.Name = "hotelreshotelidtextBox";
            this.hotelreshotelidtextBox.Size = new System.Drawing.Size(276, 20);
            this.hotelreshotelidtextBox.TabIndex = 4;
            // 
            // hotelreshotelpricelabel
            // 
            this.hotelreshotelpricelabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.hotelreshotelpricelabel.AutoSize = true;
            this.hotelreshotelpricelabel.Location = new System.Drawing.Point(57, 414);
            this.hotelreshotelpricelabel.Name = "hotelreshotelpricelabel";
            this.hotelreshotelpricelabel.Size = new System.Drawing.Size(59, 13);
            this.hotelreshotelpricelabel.TabIndex = 5;
            this.hotelreshotelpricelabel.Text = "Hotel Price";
            // 
            // hotelrespricetextBox
            // 
            this.hotelrespricetextBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.hotelrespricetextBox.Location = new System.Drawing.Point(236, 411);
            this.hotelrespricetextBox.Name = "hotelrespricetextBox";
            this.hotelrespricetextBox.Size = new System.Drawing.Size(276, 20);
            this.hotelrespricetextBox.TabIndex = 4;
            // 
            // hoteldatereservedlabel
            // 
            this.hoteldatereservedlabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.hoteldatereservedlabel.AutoSize = true;
            this.hoteldatereservedlabel.Location = new System.Drawing.Point(57, 207);
            this.hoteldatereservedlabel.Name = "hoteldatereservedlabel";
            this.hoteldatereservedlabel.Size = new System.Drawing.Size(110, 13);
            this.hoteldatereservedlabel.TabIndex = 5;
            this.hoteldatereservedlabel.Text = "Date Reserved (Start)";
            // 
            // hotelresconfirmbutton
            // 
            this.hotelresconfirmbutton.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.hotelresconfirmbutton.Location = new System.Drawing.Point(353, 448);
            this.hotelresconfirmbutton.Name = "hotelresconfirmbutton";
            this.hotelresconfirmbutton.Size = new System.Drawing.Size(75, 23);
            this.hotelresconfirmbutton.TabIndex = 6;
            this.hotelresconfirmbutton.Text = "Confirm";
            this.hotelresconfirmbutton.UseVisualStyleBackColor = true;
            this.hotelresconfirmbutton.Click += new System.EventHandler(this.hotelresconfirmbutton_Click);
            // 
            // hotelidexamplelabel
            // 
            this.hotelidexamplelabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.hotelidexamplelabel.AutoSize = true;
            this.hotelidexamplelabel.Font = new System.Drawing.Font("Palatino Linotype", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.hotelidexamplelabel.Location = new System.Drawing.Point(12, 9);
            this.hotelidexamplelabel.Name = "hotelidexamplelabel";
            this.hotelidexamplelabel.Size = new System.Drawing.Size(537, 63);
            this.hotelidexamplelabel.TabIndex = 7;
            this.hotelidexamplelabel.Text = "Hotel ID examples: HBL001 (Langkawi Berjaya), HAL001 (Langkawi Ayda)\r\nHCR001 (Cam" +
    "eron Highlands Resort), HCP001 (Century Pines Resort)\r\nHBT001 (Tioman Berjaya),H" +
    "TT001 (Tioman Tunamaya)\r\n";
            // 
            // backtoresbutton_hotelres
            // 
            this.backtoresbutton_hotelres.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.backtoresbutton_hotelres.Location = new System.Drawing.Point(246, 442);
            this.backtoresbutton_hotelres.Name = "backtoresbutton_hotelres";
            this.backtoresbutton_hotelres.Size = new System.Drawing.Size(75, 35);
            this.backtoresbutton_hotelres.TabIndex = 32;
            this.backtoresbutton_hotelres.Text = "Back to Reservation";
            this.backtoresbutton_hotelres.UseVisualStyleBackColor = true;
            this.backtoresbutton_hotelres.Click += new System.EventHandler(this.backtoresbutton_hotelr_Click);
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(57, 248);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(107, 13);
            this.label1.TabIndex = 5;
            this.label1.Text = "Date Reserved (End)";
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(57, 169);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(153, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Customer IC/ Passport Number";
            // 
            // hotelrescusidtextBox
            // 
            this.hotelrescusidtextBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.hotelrescusidtextBox.Location = new System.Drawing.Point(236, 166);
            this.hotelrescusidtextBox.Name = "hotelrescusidtextBox";
            this.hotelrescusidtextBox.Size = new System.Drawing.Size(276, 20);
            this.hotelrescusidtextBox.TabIndex = 4;
            // 
            // hotelresenddateTimePicker
            // 
            this.hotelresenddateTimePicker.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.hotelresenddateTimePicker.Location = new System.Drawing.Point(236, 242);
            this.hotelresenddateTimePicker.Name = "hotelresenddateTimePicker";
            this.hotelresenddateTimePicker.Size = new System.Drawing.Size(276, 20);
            this.hotelresenddateTimePicker.TabIndex = 33;
            this.hotelresenddateTimePicker.ValueChanged += new System.EventHandler(this.hotelresenddateTimePicker_ValueChanged);
            // 
            // hotelresstartdateTimePicker
            // 
            this.hotelresstartdateTimePicker.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.hotelresstartdateTimePicker.Location = new System.Drawing.Point(236, 207);
            this.hotelresstartdateTimePicker.Name = "hotelresstartdateTimePicker";
            this.hotelresstartdateTimePicker.Size = new System.Drawing.Size(276, 20);
            this.hotelresstartdateTimePicker.TabIndex = 34;
            this.hotelresstartdateTimePicker.ValueChanged += new System.EventHandler(this.hotelresstartdateTimePicker_ValueChanged);
            // 
            // hotelresroomtypelabel
            // 
            this.hotelresroomtypelabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.hotelresroomtypelabel.AutoSize = true;
            this.hotelresroomtypelabel.Location = new System.Drawing.Point(57, 327);
            this.hotelresroomtypelabel.Name = "hotelresroomtypelabel";
            this.hotelresroomtypelabel.Size = new System.Drawing.Size(62, 13);
            this.hotelresroomtypelabel.TabIndex = 3;
            this.hotelresroomtypelabel.Text = "Room Type";
            // 
            // hotelresroomtypecomboBox
            // 
            this.hotelresroomtypecomboBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.hotelresroomtypecomboBox.FormattingEnabled = true;
            this.hotelresroomtypecomboBox.Items.AddRange(new object[] {
            "Single",
            "Double",
            "Family Suite"});
            this.hotelresroomtypecomboBox.Location = new System.Drawing.Point(236, 324);
            this.hotelresroomtypecomboBox.Name = "hotelresroomtypecomboBox";
            this.hotelresroomtypecomboBox.Size = new System.Drawing.Size(276, 21);
            this.hotelresroomtypecomboBox.TabIndex = 2;
            this.hotelresroomtypecomboBox.SelectedIndexChanged += new System.EventHandler(this.hotelresroomtypecomboBox_SelectedIndexChanged);
            // 
            // amountlabel
            // 
            this.amountlabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.amountlabel.AutoSize = true;
            this.amountlabel.Location = new System.Drawing.Point(57, 368);
            this.amountlabel.Name = "amountlabel";
            this.amountlabel.Size = new System.Drawing.Size(133, 13);
            this.amountlabel.TabIndex = 35;
            this.amountlabel.Text = "Amount of rooms (Max: 10)";
            // 
            // amountcomboBox
            // 
            this.amountcomboBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.amountcomboBox.FormattingEnabled = true;
            this.amountcomboBox.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10"});
            this.amountcomboBox.Location = new System.Drawing.Point(236, 365);
            this.amountcomboBox.Name = "amountcomboBox";
            this.amountcomboBox.Size = new System.Drawing.Size(276, 21);
            this.amountcomboBox.TabIndex = 36;
            this.amountcomboBox.SelectedIndexChanged += new System.EventHandler(this.amountcomboBox_SelectedIndexChanged);
            // 
            // label3
            // 
            this.label3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(57, 90);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(78, 13);
            this.label3.TabIndex = 3;
            this.label3.Text = "Reservation ID";
            // 
            // hotelrestextBox
            // 
            this.hotelrestextBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.hotelrestextBox.Location = new System.Drawing.Point(236, 87);
            this.hotelrestextBox.Name = "hotelrestextBox";
            this.hotelrestextBox.Size = new System.Drawing.Size(276, 20);
            this.hotelrestextBox.TabIndex = 4;
            // 
            // HotelRes
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(567, 501);
            this.Controls.Add(this.amountcomboBox);
            this.Controls.Add(this.amountlabel);
            this.Controls.Add(this.hotelresstartdateTimePicker);
            this.Controls.Add(this.hotelresenddateTimePicker);
            this.Controls.Add(this.backtoresbutton_hotelres);
            this.Controls.Add(this.hotelidexamplelabel);
            this.Controls.Add(this.hotelresconfirmbutton);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.hoteldatereservedlabel);
            this.Controls.Add(this.hotelreshotelpricelabel);
            this.Controls.Add(this.hotelrespricetextBox);
            this.Controls.Add(this.hotelrescusidtextBox);
            this.Controls.Add(this.hotelrestextBox);
            this.Controls.Add(this.hotelreshotelidtextBox);
            this.Controls.Add(this.hotelresroomtypelabel);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.hotelreshotelnamelabel);
            this.Controls.Add(this.hotelreshotelidlabel);
            this.Controls.Add(this.hotelresroomtypecomboBox);
            this.Controls.Add(this.hotelreshotelnamecomboBox);
            this.Controls.Add(this.hotelresmainmenubutton);
            this.Name = "HotelRes";
            this.Text = "Hotel Reservation";
            this.Load += new System.EventHandler(this.HotelRes_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button hotelresmainmenubutton;
        private System.Windows.Forms.ComboBox hotelreshotelnamecomboBox;
        private System.Windows.Forms.Label hotelreshotelidlabel;
        private System.Windows.Forms.Label hotelreshotelnamelabel;
        private System.Windows.Forms.TextBox hotelreshotelidtextBox;
        private System.Windows.Forms.Label hotelreshotelpricelabel;
        private System.Windows.Forms.TextBox hotelrespricetextBox;
        private System.Windows.Forms.Label hoteldatereservedlabel;
        private System.Windows.Forms.Button hotelresconfirmbutton;
        private System.Windows.Forms.Label hotelidexamplelabel;
        private System.Windows.Forms.Button backtoresbutton_hotelres;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox hotelrescusidtextBox;
        private System.Windows.Forms.DateTimePicker hotelresenddateTimePicker;
        private System.Windows.Forms.DateTimePicker hotelresstartdateTimePicker;
        private System.Windows.Forms.Label hotelresroomtypelabel;
        private System.Windows.Forms.ComboBox hotelresroomtypecomboBox;
        private System.Windows.Forms.Label amountlabel;
        private System.Windows.Forms.ComboBox amountcomboBox;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox hotelrestextBox;
    }
}