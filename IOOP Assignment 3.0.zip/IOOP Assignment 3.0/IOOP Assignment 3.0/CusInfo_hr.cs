﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace IOOP_Assignment_3._0
{
    public partial class CusInfo_hr : Form
    {
        OleDbConnection cnnOLEDB = new OleDbConnection();
        OleDbCommand cmdInsert = new OleDbCommand();
        OleDbCommand cmdDelete = new OleDbCommand();
        OleDbCommand cmdUpdate = new OleDbCommand();
        OleDbCommand cmdSearch = new OleDbCommand();
        public CusInfo_hr()
        {
            InitializeComponent();
        }

        private void mainmenubutton_hotelr_Click(object sender, EventArgs e)
        {
            const string message = "Do you want to go to MAIN MENU?";
            const string caption = "MAIN MENU";
            var result = MessageBox.Show(message, caption, MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes)
            {
                MainMenu newForm = new MainMenu();
                newForm.Show();
                this.Hide();
            }
        }

        private void backtoresbutton_hotelr_Click(object sender, EventArgs e)
        {
            const string message = "Do you want to go to RESERVATION?";
            const string caption = "RESERVATION";
            var result = MessageBox.Show(message, caption, MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes)
            {
                Reservation newForm = new Reservation();
                newForm.Show();
                this.Hide();
            }
        }

        private void confirmbutton_hotelr_Click(object sender, EventArgs e)
        {
            try
            {

                DateTime bookingdatehotelr = DateTime.Parse(cusinfohotelresdateTimePicker.Text);
                using (OleDbConnection conn = new OleDbConnection())
                {

                    conn.ConnectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source= IOOPDb.accdb";
                    string sql = string.Format("INSERT INTO cusinfohotelr(customerID, customername, address, email, contact, bookingdate) VALUES('{0}','{1}','{2}','{3}','{4}','{5}')", cusidtextBox_hotelr.Text, cusnametextBox_hotelr.Text, cusaddresstextBox_hotelr.Text, emailtextBox_hotelr.Text, cuscontacttextBox_hotelr.Text, bookingdatehotelr);

                    using (OleDbCommand cmd = new OleDbCommand(sql, conn))
                    {
                        conn.Open();
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Insertion successful.");
                        HotelRes  newForm = new HotelRes();
                        newForm.Show();
                        this.Hide();// displays the CustomerInfo window again
                    }

                }
            }
            catch
            {
                MessageBox.Show("Insertion unsuccessful. Make sure all the fields are in the correct format and filled.");
            } //to tell users to input the info accordingly
        }

        private void CusInfo_hr_Load(object sender, EventArgs e)
        {
            cnnOLEDB.ConnectionString = "Provider =Microsoft.ACE.OLEDB.12.0; Data Source = IOOPDb.accdb";
            cnnOLEDB.Open();
        }
    }
}
