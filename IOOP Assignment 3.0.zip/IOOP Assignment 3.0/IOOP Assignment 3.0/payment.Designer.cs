﻿namespace IOOP_Assignment_3._0
{
    partial class payment
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.paymenthotelresbutton = new System.Windows.Forms.Button();
            this.paymenttourresbutton = new System.Windows.Forms.Button();
            this.paymentholiresbutton = new System.Windows.Forms.Button();
            this.mainmenubutton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // paymenthotelresbutton
            // 
            this.paymenthotelresbutton.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.paymenthotelresbutton.Location = new System.Drawing.Point(151, 97);
            this.paymenthotelresbutton.Name = "paymenthotelresbutton";
            this.paymenthotelresbutton.Size = new System.Drawing.Size(135, 23);
            this.paymenthotelresbutton.TabIndex = 0;
            this.paymenthotelresbutton.Text = "Hotel Reservation ";
            this.paymenthotelresbutton.UseVisualStyleBackColor = true;
            this.paymenthotelresbutton.Click += new System.EventHandler(this.paymenthotelresbutton_Click);
            // 
            // paymenttourresbutton
            // 
            this.paymenttourresbutton.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.paymenttourresbutton.Location = new System.Drawing.Point(151, 146);
            this.paymenttourresbutton.Name = "paymenttourresbutton";
            this.paymenttourresbutton.Size = new System.Drawing.Size(135, 23);
            this.paymenttourresbutton.TabIndex = 1;
            this.paymenttourresbutton.Text = "Tour Reservation";
            this.paymenttourresbutton.UseVisualStyleBackColor = true;
            this.paymenttourresbutton.Click += new System.EventHandler(this.paymenttourresbutton_Click);
            // 
            // paymentholiresbutton
            // 
            this.paymentholiresbutton.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.paymentholiresbutton.Location = new System.Drawing.Point(151, 196);
            this.paymentholiresbutton.Name = "paymentholiresbutton";
            this.paymentholiresbutton.Size = new System.Drawing.Size(135, 23);
            this.paymentholiresbutton.TabIndex = 1;
            this.paymentholiresbutton.Text = "Holiday Reservation";
            this.paymentholiresbutton.UseVisualStyleBackColor = true;
            this.paymentholiresbutton.Click += new System.EventHandler(this.paymentholiresbutton_Click);
            // 
            // mainmenubutton
            // 
            this.mainmenubutton.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.mainmenubutton.Location = new System.Drawing.Point(183, 304);
            this.mainmenubutton.Name = "mainmenubutton";
            this.mainmenubutton.Size = new System.Drawing.Size(75, 23);
            this.mainmenubutton.TabIndex = 2;
            this.mainmenubutton.Text = "Main Menu";
            this.mainmenubutton.UseVisualStyleBackColor = true;
            this.mainmenubutton.Click += new System.EventHandler(this.mainmenubutton_Click);
            // 
            // payment
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(444, 364);
            this.Controls.Add(this.mainmenubutton);
            this.Controls.Add(this.paymentholiresbutton);
            this.Controls.Add(this.paymenttourresbutton);
            this.Controls.Add(this.paymenthotelresbutton);
            this.Name = "payment";
            this.Text = "Payment Information";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button paymenthotelresbutton;
        private System.Windows.Forms.Button paymenttourresbutton;
        private System.Windows.Forms.Button paymentholiresbutton;
        private System.Windows.Forms.Button mainmenubutton;
    }
}