﻿namespace IOOP_Assignment_3._0
{
    partial class Reservation
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.reslabel = new System.Windows.Forms.Label();
            this.holidaypackageresbutton = new System.Windows.Forms.Button();
            this.tourpackageresutton = new System.Windows.Forms.Button();
            this.hotelresbutton = new System.Windows.Forms.Button();
            this.mainmenubutton = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // reslabel
            // 
            this.reslabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.reslabel.AutoSize = true;
            this.reslabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.reslabel.Location = new System.Drawing.Point(236, 9);
            this.reslabel.Name = "reslabel";
            this.reslabel.Size = new System.Drawing.Size(105, 20);
            this.reslabel.TabIndex = 20;
            this.reslabel.Text = "Reservation";
            // 
            // holidaypackageresbutton
            // 
            this.holidaypackageresbutton.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.holidaypackageresbutton.Location = new System.Drawing.Point(100, 183);
            this.holidaypackageresbutton.Name = "holidaypackageresbutton";
            this.holidaypackageresbutton.Size = new System.Drawing.Size(193, 48);
            this.holidaypackageresbutton.TabIndex = 19;
            this.holidaypackageresbutton.Text = "Customer Info (Holiday package reservation (Hotel + Tour)";
            this.holidaypackageresbutton.UseVisualStyleBackColor = true;
            this.holidaypackageresbutton.Click += new System.EventHandler(this.holidaypackageresbutton_Click);
            // 
            // tourpackageresutton
            // 
            this.tourpackageresutton.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.tourpackageresutton.Location = new System.Drawing.Point(100, 124);
            this.tourpackageresutton.Name = "tourpackageresutton";
            this.tourpackageresutton.Size = new System.Drawing.Size(193, 39);
            this.tourpackageresutton.TabIndex = 18;
            this.tourpackageresutton.Text = "Customer Info (Tour package reservation)";
            this.tourpackageresutton.UseVisualStyleBackColor = true;
            this.tourpackageresutton.Click += new System.EventHandler(this.tourpackageresutton_Click);
            // 
            // hotelresbutton
            // 
            this.hotelresbutton.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.hotelresbutton.Location = new System.Drawing.Point(100, 68);
            this.hotelresbutton.Name = "hotelresbutton";
            this.hotelresbutton.Size = new System.Drawing.Size(193, 36);
            this.hotelresbutton.TabIndex = 16;
            this.hotelresbutton.Text = "Customer Info (Hotel reservation )";
            this.hotelresbutton.UseVisualStyleBackColor = true;
            this.hotelresbutton.Click += new System.EventHandler(this.hotelresbutton_Click);
            // 
            // mainmenubutton
            // 
            this.mainmenubutton.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.mainmenubutton.Location = new System.Drawing.Point(217, 281);
            this.mainmenubutton.Name = "mainmenubutton";
            this.mainmenubutton.Size = new System.Drawing.Size(124, 22);
            this.mainmenubutton.TabIndex = 17;
            this.mainmenubutton.Text = "Back to Main Menu";
            this.mainmenubutton.UseVisualStyleBackColor = true;
            this.mainmenubutton.Click += new System.EventHandler(this.mainmenubutton_Click);
            // 
            // button1
            // 
            this.button1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button1.Location = new System.Drawing.Point(358, 71);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(121, 31);
            this.button1.TabIndex = 21;
            this.button1.Text = "Hotel Reservation";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button2.Location = new System.Drawing.Point(358, 128);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(121, 31);
            this.button2.TabIndex = 21;
            this.button2.Text = "Tour Reservation";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button3.Location = new System.Drawing.Point(358, 188);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(121, 39);
            this.button3.TabIndex = 21;
            this.button3.Text = "Holiday Package Reservation";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // Reservation
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(573, 315);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.reslabel);
            this.Controls.Add(this.holidaypackageresbutton);
            this.Controls.Add(this.tourpackageresutton);
            this.Controls.Add(this.hotelresbutton);
            this.Controls.Add(this.mainmenubutton);
            this.Name = "Reservation";
            this.Text = "Reservation";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label reslabel;
        private System.Windows.Forms.Button holidaypackageresbutton;
        private System.Windows.Forms.Button tourpackageresutton;
        private System.Windows.Forms.Button hotelresbutton;
        private System.Windows.Forms.Button mainmenubutton;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
    }
}