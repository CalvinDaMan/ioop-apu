﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace IOOP_Assignment_3._0
{
    public partial class HolidayRes : Form
    {
        OleDbConnection cnnOLEDB = new OleDbConnection();
        OleDbCommand cmdInsert = new OleDbCommand();
        OleDbCommand cmdDelete = new OleDbCommand();
        OleDbCommand cmdUpdate = new OleDbCommand();
        OleDbCommand cmdSearch = new OleDbCommand();
        double lt = 960, ct = 640, tt = 800;
        double totalprice;
        public HolidayRes()
        {
            InitializeComponent();
        }
        string holiname;
        double holiprice;
        double hotelp;
        double dayr;
        private void holidayresmainmenubutton_Click(object sender, EventArgs e)
        {
            const string message = "Do you want to go to MAIN MENU?";
            const string caption = "MAIN MENU";
            var result = MessageBox.Show(message, caption, MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes)
            {
                MainMenu newForm = new MainMenu();
                newForm.Show();
                this.Hide();
            }
        }

        private void backtoresbutton_hotelr_Click(object sender, EventArgs e)
        {
            const string message = "Do you want to go to RESERVATION?";
            const string caption = "RESERVATION";
            var result = MessageBox.Show(message, caption, MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes)
            {
                Reservation newForm = new Reservation();
                newForm.Show();
                this.Hide();
            }
        }

        private void backtoresbutton_holidayres_Click(object sender, EventArgs e)
        {
            const string message = "Do you want to go to RESERVATION?";
            const string caption = "RESERVATION";
            var result = MessageBox.Show(message, caption, MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes)
            {
                Reservation newForm = new Reservation();
                newForm.Show();
                this.Hide();
            }
        }

        private void HolidayRes_Load(object sender, EventArgs e)
        {

            cnnOLEDB.ConnectionString = "Provider =Microsoft.ACE.OLEDB.12.0; Data Source = IOOPDb.accdb";
            cnnOLEDB.Open();
        }

        private void holirenddateTimePicker2_ValueChanged(object sender, EventArgs e)
        {
            //Display a messagebox to show whether the dates are inputted correctly. Put at end date of reservation.
            DateTime todaydate = DateTime.Today;// this line of code is to get today's date (current date).
            DateTime startreserveddateholires = DateTime.Parse(holirstartdateTimePicker.Text);
            DateTime endreserveddateholires = DateTime.Parse(holirenddateTimePicker2.Text);
            if (endreserveddateholires < startreserveddateholires)
            {
                MessageBox.Show("Please ensure the dates are correct. Date will be resetted to current date.");
                holirstartdateTimePicker.ResetText();
                holirenddateTimePicker2.ResetText();//reset to current date, order matters reset startdate before enddate
            }
            else if (endreserveddateholires < todaydate)//to notify users that they picked a date before current date.
            {
                MessageBox.Show("You cannot reserve a date before today. Date will be resetted to current date.");
                holirenddateTimePicker2.ResetText();//reset to current date 
            }
            else if (endreserveddateholires > startreserveddateholires)//only run if enddate is after startdate.
            {
                if (holidaypackagecomboBox.SelectedIndex == 0)
                {
                    DateTime start = endreserveddateholires.AddDays(-4);//-4 days from enddate to get startdate
                    holirstartdateTimePicker.Text = start.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 1)
                {
                    DateTime start = endreserveddateholires.AddDays(-4);
                    holirstartdateTimePicker.Text = start.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 2)
                {
                    DateTime start = endreserveddateholires.AddDays(-3);//-3 days from enddate to get startdate
                    holirstartdateTimePicker.Text = start.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 3)
                {
                    DateTime start = endreserveddateholires.AddDays(-3);
                    holirstartdateTimePicker.Text = start.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 4)
                {
                    DateTime start = endreserveddateholires.AddDays(-5);//-5 days from enddate to get startdate
                    holirstartdateTimePicker.Text = start.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 5)
                {
                    DateTime start = endreserveddateholires.AddDays(-5);
                    holirstartdateTimePicker.Text = start.ToLongDateString();
                }

            }

        }

        private void holidaypackagecomboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            DateTime startreserveddateholires = DateTime.Parse(holirstartdateTimePicker.Text);
            DateTime endreserveddateholires = DateTime.Parse(holirenddateTimePicker2.Text);
            dayr = (endreserveddateholires - startreserveddateholires).TotalDays;
            if (startreserveddateholires < endreserveddateholires)
            {
                if (holidaypackagecomboBox.SelectedIndex == 0 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 0) //LB single 1
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = NoOfDays * 160 + lt;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(4);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 0 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 1) //LB single 2
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 160 + lt) * 2;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(4);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 0 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 2) //LB single 3
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 160 + lt) * 3;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(4);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 0 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 3) //LB single 4
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 160 + lt) * 4;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(4);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 0 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 4) //LB single 5
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 160 + lt) * 5;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(4);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 0 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 5) //LB single 6
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 160 + lt) * 6;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(4);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 0 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 6) //LB single 7
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 160 + lt) * 7;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(4);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 0 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 7) //LB single 8
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 160 + lt) * 8;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(4);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 0 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 8) //LB single 9
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 160 + lt) * 9;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(4);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 0 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 9) //LB single 10
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 160 + lt) * 10;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(4);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 0 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 0) //LB double 1
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = NoOfDays * 304 + lt;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(4);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 0 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 1) //LB double 2
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 304 + lt) * 2;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(4);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 0 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 2) //LB double 3
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 304 + lt) * 3;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(4);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 0 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 3) //LB double 4
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 304 + lt) * 4;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(4);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 0 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 4) //LB double 5
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 304 + lt) * 5;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(4);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 0 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 5) //LB double 6
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 304 + lt) * 6;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(4);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 0 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 6) //LB double 7
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 304 + lt) * 7;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(4);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 0 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 7) //LB double 8
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 304 + lt) * 8;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(4);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 0 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 8) //LB double 9
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 304 + lt) * 9;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(4);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 0 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 9) //LB double 10
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 304 + lt) * 10;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(4);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 0 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 0) //LB fs 1
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = NoOfDays * 480 + lt;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(4);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 0 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 1) //LB fs 2
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 480 + lt) * 2;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(4);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 0 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 2) //LB fs 3
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 480 + lt) * 3;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(4);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 0 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 3) //LB fs 4
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 480 + lt) * 4;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(4);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 0 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 4) //LB fs 5
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 480 + lt) * 5;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(4);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 0 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 5) //LB fs 6
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 480 + lt) * 6;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(4);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 0 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 6) //LB fs 7
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 480 + lt) * 7;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(4);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 0 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 7) //LB fs 8
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 480 + lt) * 8;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(4);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 0 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 8) //LB fs 9
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 480 + lt) * 9;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(4);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 0 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 9) //LB fs 10
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 480 + lt) * 10;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(4);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 1 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 0) //LA Single 1
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 144 + lt);
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(4);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 1 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 1) //LA Single 2
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 144 + lt) * 2;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(4);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 1 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 2) //LA Single 3
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 144 + lt) * 3;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(4);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 1 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 3) //LA Single 4
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 144 + lt) * 4;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(4);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 1 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 4) //LA Single 5
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 144 + lt) * 5;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(4);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 1 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 5) //LA Single 6
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 144 + lt) * 6;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(4);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 1 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 6) //LA Single 7
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 144 + lt) * 7;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(4);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 1 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 7) //LA Single 8
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 144 + lt) * 8;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(4);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 1 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 8) //LA Single 9
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 144 + lt) * 9;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(4);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 1 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 9) //LA Single 10
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 144 + lt) * 10;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(4);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 1 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 0) //LA Double 1
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 192 + lt);
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(4);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 1 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 1) //LA Double 2
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 192 + lt) * 2;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(4);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 1 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 2) //LA Double 3
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 192 + lt) * 3;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(4);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 1 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 3) //LA Double 4
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 192 + lt) * 4;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(4);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 1 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 4) //LA Double 5
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 192 + lt) * 5;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(4);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 1 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 5) //LA Double 6
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 192 + lt) * 6;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(4);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 1 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 6) //LA Double 7
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 192 + lt) * 7;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(4);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 1 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 7) //LA Double 8
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 192 + lt) * 8;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(4);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 1 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 8) //LA Double 9
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 192 + lt) * 9;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(4);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 1 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 9) //LA Double 10
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 192 + lt) * 10;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(4);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 1 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 0) //LA fs 1
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = NoOfDays * 320 + lt;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(4);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 1 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 1) //LA fs 2
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 320 + lt) * 2;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(4);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 1 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 2) //LA fs 3
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 320 + lt) * 3;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(4);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 1 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 3) //LA fs 4
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 320 + lt) * 4;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(4);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 1 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 4) //LA fs 5
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 320 + lt) * 5;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(4);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 1 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 5) //LA fs 6
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 320 + lt) * 6;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(4);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 1 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 6) //LA fs 7
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 320 + lt) * 7;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(4);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 1 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 7) //LA fs 8
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 320 + lt) * 8;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(4);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 1 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 8) //LA fs 9
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 320 + lt) * 9;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(4);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 1 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 9) //LA fs 10
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 320 + lt) * 10;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(4);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 2 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 0) //CH single 1
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = NoOfDays * 144 + ct;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(3);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 2 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 1) //CH single 2
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 144 + ct) * 2;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(3);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 2 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 2) //CH single 3
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 144 + ct) * 3;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(3);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 2 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 3) //CH single 4
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 144 + ct) * 4;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(3);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 2 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 4) //CH single 5
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 144 + ct) * 5;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(3);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 2 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 5) //CH single 6
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 144 + ct) * 6;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(3);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 2 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 6) //CH single 7
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 144 + ct) * 7;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(3);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 2 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 7) //CH single 8
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 144 + ct) * 8;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(3);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 2 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 8) //CH single 9
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 144 + ct) * 9;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(3);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 2 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 9) //CH single 10
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 144 + ct) * 10;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(3);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 2 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 0) //CH double 1
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = NoOfDays * 280 + ct;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(3);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 2 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 1) //CH double 2
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 280 + ct) * 2;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(3);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 2 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 2) //CH double 3
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 280 + ct) * 3;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(3);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 2 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 3) //CH double 4
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 280 + ct) * 4;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(3);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 2 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 4) //CH double 5
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 280 + ct) * 5;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(3);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 2 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 5) //CH double 6
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 280 + ct) * 6;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(3);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 2 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 6) //CH double 7
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 280 + ct) * 7;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(3);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 2 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 7) //CH double 8
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 280 + ct) * 8;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(3);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 2 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 8) //CH double 9
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 280 + ct) * 9;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(3);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 2 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 9) //CH double 10
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 280 + ct) * 10;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(3);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 2 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 0) //CH fs 1
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = NoOfDays * 400 + ct;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(3);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 2 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 1) //CH fs 2
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 400 + ct) * 2;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(3);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 2 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 2) //CH fs 3
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 400 + ct) * 3;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(3);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 2 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 3) //CH fs 4
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 400 + ct) * 4;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(3);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 2 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 4) //CH fs 5
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 400 + ct) * 5;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(3);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 2 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 5) //CH fs 6
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 400 + ct) * 6;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(3);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 2 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 6) //CH fs 7
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 400 + ct) * 7;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(3);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 2 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 7) //CH fs 8
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 400 + ct) * 8;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(3);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 2 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 8) //CH fs 9
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 400 + ct) * 9;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(3);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 2 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 9) //CH fs 10
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 400 + ct) * 10;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(3);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 3 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 0) //CP single 1
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = NoOfDays * 160 + ct;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(3);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 3 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 1) //CP single 2
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 160 + ct) * 2;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(3);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 3 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 2) //CP single 3
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 160 + ct) * 3;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(3);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 3 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 3) //CP single 4
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 160 + ct) * 4;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(3);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 3 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 4) //CP single 5
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 160 + ct) * 5;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(3);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 3 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 5) //CP single 6
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 160 + ct) * 6;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(3);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 3 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 6) //CP single 7
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 160 + ct) * 7;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(3);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 3 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 7) //CP single 8
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 160 + ct) * 8;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(3);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 3 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 8) //CP single 9
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 160 + ct) * 9;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(3);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 3 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 9) //CP single 10
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 160 + ct) * 10;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(3);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 3 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 0) //CP double 1
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = NoOfDays * 288 + ct;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(3);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 3 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 1) //CP double 2
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 288 + ct) * 2;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(3);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 3 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 2) //CP double 3
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 288 + ct) * 3;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(3);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 3 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 3) //CP double 4
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 288 + ct) * 4;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(3);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 3 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 4) //CP double 5
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 288 + ct) * 5;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(3);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 3 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 5) //CP double 6
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 288 + ct) * 6;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(3);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 3 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 6) //CP double 7
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 288 + ct) * 7;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(3);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 3 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 7) //CP double 8
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 288 + ct) * 8;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(3);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 3 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 8) //CP double 9
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 288 + ct) * 9;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(3);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 3 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 9) //CP double 10
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 288 + ct) * 10;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(3);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 3 && holidayresroomtypecomboBox.SelectedIndex == 2) //CP family suite
                {
                    packagepricetextBox.Text = "Unavailable.";
                }
                else if (holidaypackagecomboBox.SelectedIndex == 4 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 0) //TT single 1
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = NoOfDays * 176 + tt;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(5);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 4 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 1) //TT single 2
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 176 + tt) * 2;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(5);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 4 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 2) //TT single 3
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 176 + tt) * 3;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(5);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 4 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 3) //TT single 4
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 176 + tt) * 4;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(5);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 4 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 4) //TT single 5
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 176 + tt) * 5;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(5);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 4 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 5) //TT single 6
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 176 + tt) * 6;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(5);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 4 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 6) //TT single 7
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 176 + tt) * 7;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(5);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 4 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 7) //TT single 8
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 176 + tt) * 8;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(5);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 4 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 8) //TT single 9
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 176 + tt) * 9;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(5);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 4 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 9) //TT single 10
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 176 + tt) * 10;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(5);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 4 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 0) //TT double 1
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = NoOfDays * 280 + tt;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(5);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 4 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 1) //TT double 2
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 280 + tt) * 2;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(5);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 4 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 2) //TT double 3
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 280 + tt) * 3;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(5);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 4 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 3) //TT double 4
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 280 + tt) * 4;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(5);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 4 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 4) //TT double 5
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 280 + tt) * 5;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(5);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 4 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 5) //TT double 6
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 280 + tt) * 6;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(5);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 4 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 6) //TT double 7
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 280 + tt) * 7;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(5);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 4 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 7) //TT double 8
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 280 + tt) * 8;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(5);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 4 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 8) //TT double 9
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 280 + tt) * 9;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(5);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 4 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 9) //TT double 10
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 280 + tt) * 10;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(5);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 4 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 0) //TT fs 1
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = NoOfDays * 384 + tt;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(5);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 4 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 1) //TT fs 2
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 384 + tt) * 2;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(5);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 4 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 2) //TT fs 3
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 384 + tt) * 3;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(5);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 4 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 3) //TT fs 4
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 384 + tt) * 4;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(5);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 4 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 4) //TT fs 5
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 384 + lt) * 5;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(5);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 4 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 5) //TT fs 6
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 384 + tt) * 6;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(5);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 4 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 6) //TT fs 7
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 384 + tt) * 7;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(5);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 4 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 7) //TT fs 8
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 384 + tt) * 8;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(5);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 4 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 8) //TT fs 9
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 384 + tt) * 9;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(5);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 4 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 9) //TT fs 10
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 384 + tt) * 10;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(5);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 5 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 0) //TB single 1
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = NoOfDays * 200 + tt;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(5);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 5 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 1) //TB single 2
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 200 + tt) * 2;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(5);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 5 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 2) //TB single 3
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 200 + tt) * 3;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(5);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 5 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 3) //TB single 4
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 200 + tt) * 4;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(5);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 5 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 4) //TB single 5
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 200 + tt) * 5;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(5);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 5 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 5) //TB single 6
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 200 + tt) * 6;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(5);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 5 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 6) //TB single 7
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 200 + tt) * 7;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(5);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 5 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 7) //TB single 8
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 200 + tt) * 8;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(5);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 5 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 8) //TB single 9
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 200 + tt) * 9;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(5);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 5 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 9) //TB single 10
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 200 + tt) * 10;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(5);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 5 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 0) //TB double 1
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = NoOfDays * 304 + tt;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(5);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 5 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 1) //TB double 2
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 304 + tt) * 2;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(5);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 5 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 2) //TB double 3
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 304 + tt) * 3;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(5);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 5 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 3) //TB double 4
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 304 + tt) * 4;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(5);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 5 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 4) //TB double 5
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 304 + tt) * 5;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(5);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 5 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 5) //TB double 6
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 304 + tt) * 6;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(5);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 5 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 6) //TB double 7
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 304 + tt) * 7;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(5);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 5 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 7) //TB double 8
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 304 + tt) * 8;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(5);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 5 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 8) //TB double 9
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 304 + tt) * 9;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(5);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 5 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 9) //TB double 10
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 304 + tt) * 10;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(5);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 5 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 0) //TB fs 1
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = NoOfDays * 416 + tt;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(5);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 5 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 1) //TB fs 2
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 416 + tt) * 2;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(5);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 5 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 2) //TB fs 3
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 416 + tt) * 3;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(5);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 5 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 3) //TB fs 4
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 416 + tt) * 4;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(5);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 5 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 4) //TB fs 5
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 416 + tt) * 5;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(5);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 5 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 5) //TB fs 6
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 416 + tt) * 6;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(5);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 5 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 6) //TB fs 7
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 416 + tt) * 7;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(5);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 5 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 7) //TB fs 8
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 416 + tt) * 8;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(5);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 5 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 8) //TB fs 9
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 416 + tt) * 9;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(5);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 5 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 9) //TB fs 10
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 416 + tt) * 10;
                    packagepricetextBox.Text = amount.ToString();
                    DateTime end = startreserveddateholires.AddDays(5);
                    holirenddateTimePicker2.Text = end.ToLongDateString();
                }
            }

        }

        private void holirstartdateTimePicker_ValueChanged(object sender, EventArgs e)
        {
            DateTime startreserveddateholires = DateTime.Parse(holirstartdateTimePicker.Text);
            DateTime todaydate = DateTime.Today;
            if (startreserveddateholires >= todaydate)
            {
                if (holidaypackagecomboBox.SelectedIndex == 0)//selecteditem is langkawi tour (4d3n)
                {
                    DateTime holiresend = startreserveddateholires.AddDays(4);
                    holirenddateTimePicker2.Text = holiresend.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 1)//selecteditem is langkawi tour (4d3n)
                {
                    DateTime tourresend = startreserveddateholires.AddDays(4);
                    holirenddateTimePicker2.Text = tourresend.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 2)//selecteditem is ch tour (3d2n)
                {
                    DateTime tourresend = startreserveddateholires.AddDays(3);
                    holirenddateTimePicker2.Text = tourresend.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 3)//selecteditem is ch tour (3d2n)
                {
                    DateTime tourresend = startreserveddateholires.AddDays(3);
                    holirenddateTimePicker2.Text = tourresend.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 4)//selecteditem is tioman tour (5d4n)
                {
                    DateTime tourresend = startreserveddateholires.AddDays(5);
                    holirenddateTimePicker2.Text = tourresend.ToLongDateString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 5)//selecteditem is tioman tour (5d4n)
                {
                    DateTime tourresend = startreserveddateholires.AddDays(5);
                    holirenddateTimePicker2.Text = tourresend.ToLongDateString();
                }
            }
            else
            {
                MessageBox.Show("You cannot reserve a date before today. Date will be resetted to current date.");
                holirstartdateTimePicker.ResetText();//reset to current date      
            }
        }

        private void amountrescomboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            DateTime startreserveddateholires = DateTime.Parse(holirstartdateTimePicker.Text);
            DateTime endreserveddateholires = DateTime.Parse(holirenddateTimePicker2.Text);
            if (holidaypackagecomboBox.SelectedIndex == 0 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 0) //LB single 1
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = NoOfDays * 160 + lt;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 0 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 1) //LB single 2
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 160 + lt) * 2;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 0 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 2) //LB single 3
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 160 + lt) * 3;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 0 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 3) //LB single 4
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 160 + lt) * 4;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 0 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 4) //LB single 5
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 160 + lt) * 5;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 0 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 5) //LB single 6
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 160 + lt) * 6;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 0 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 6) //LB single 7
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 160 + lt) * 7;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 0 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 7) //LB single 8
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 160 + lt) * 8;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 0 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 8) //LB single 9
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 160 + lt) * 9;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 0 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 9) //LB single 10
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 160 + lt) * 10;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 0 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 0) //LB double 1
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = NoOfDays * 304 + lt;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 0 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 1) //LB double 2
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 304 + lt) * 2;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 0 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 2) //LB double 3
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 304 + lt) * 3;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 0 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 3) //LB double 4
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 304 + lt) * 4;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 0 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 4) //LB double 5
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 304 + lt) * 5;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 0 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 5) //LB double 6
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 304 + lt) * 6;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 0 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 6) //LB double 7
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 304 + lt) * 7;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 0 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 7) //LB double 8
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 304 + lt) * 8;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 0 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 8) //LB double 9
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 304 + lt) * 9;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 0 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 9) //LB double 10
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 304 + lt) * 10;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 0 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 0) //LB fs 1
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = NoOfDays * 480 + lt;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 0 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 1) //LB fs 2
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 480 + lt) * 2;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 0 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 2) //LB fs 3
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 480 + lt) * 3;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 0 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 3) //LB fs 4
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 480 + lt) * 4;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 0 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 4) //LB fs 5
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 480 + lt) * 5;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 0 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 5) //LB fs 6
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 480 + lt) * 6;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 0 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 6) //LB fs 7
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 480 + lt) * 7;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 0 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 7) //LB fs 8
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 480 + lt) * 8;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 0 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 8) //LB fs 9
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 480 + lt) * 9;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 0 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 9) //LB fs 10
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 480 + lt) * 10;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 1 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 0) //LA Single 1
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 144 + lt);
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 1 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 1) //LA Single 2
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 144 + lt) * 2;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 1 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 2) //LA Single 3
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 144 + lt) * 3;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 1 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 3) //LA Single 4
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 144 + lt) * 4;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 1 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 4) //LA Single 5
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 144 + lt) * 5;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 1 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 5) //LA Single 6
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 144 + lt) * 6;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 1 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 6) //LA Single 7
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 144 + lt) * 7;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 1 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 7) //LA Single 8
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 144 + lt) * 8;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 1 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 8) //LA Single 9
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 144 + lt) * 9;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 1 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 9) //LA Single 10
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 144 + lt) * 10;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 1 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 0) //LA Double 1
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 192 + lt);
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 1 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 1) //LA Double 2
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 192 + lt) * 2;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 1 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 2) //LA Double 3
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 192 + lt) * 3;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 1 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 3) //LA Double 4
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 192 + lt) * 4;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 1 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 4) //LA Double 5
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 192 + lt) * 5;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 1 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 5) //LA Double 6
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 192 + lt) * 6;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 1 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 6) //LA Double 7
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 192 + lt) * 7;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 1 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 7) //LA Double 8
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 192 + lt) * 8;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 1 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 8) //LA Double 9
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 192 + lt) * 9;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 1 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 9) //LA Double 10
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 192 + lt) * 10;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 1 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 0) //LA fs 1
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = NoOfDays * 320 + lt;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 1 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 1) //LA fs 2
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 320 + lt) * 2;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 1 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 2) //LA fs 3
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 320 + lt) * 3;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 1 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 3) //LA fs 4
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 320 + lt) * 4;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 1 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 4) //LA fs 5
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 320 + lt) * 5;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 1 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 5) //LA fs 6
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 320 + lt) * 6;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 1 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 6) //LA fs 7
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 320 + lt) * 7;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 1 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 7) //LA fs 8
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 320 + lt) * 8;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 1 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 8) //LA fs 9
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 320 + lt) * 9;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 1 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 9) //LA fs 10
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 320 + lt) * 10;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 2 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 0) //CH single 1
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = NoOfDays * 144 + ct;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 2 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 1) //CH single 2
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 144 + ct) * 2;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 2 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 2) //CH single 3
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 144 + ct) * 3;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 2 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 3) //CH single 4
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 144 + ct) * 4;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 2 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 4) //CH single 5
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 144 + ct) * 5;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 2 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 5) //CH single 6
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 144 + ct) * 6;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 2 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 6) //CH single 7
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 144 + ct) * 7;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 2 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 7) //CH single 8
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 144 + ct) * 8;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 2 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 8) //CH single 9
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 144 + ct) * 9;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 2 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 9) //CH single 10
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 144 + ct) * 10;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 2 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 0) //CH double 1
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = NoOfDays * 280 + ct;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 2 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 1) //CH double 2
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 280 + ct) * 2;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 2 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 2) //CH double 3
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 280 + ct) * 3;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 2 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 3) //CH double 4
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays *280 + ct) * 4;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 2 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 4) //CH double 5
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 280 + ct) * 5;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 2 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 5) //CH double 6
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 280 + ct) * 6;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 2 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 6) //CH double 7
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 280 + ct) * 7;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 2 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 7) //CH double 8
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 280 + ct) * 8;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 2 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 8) //CH double 9
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 280 + ct) * 9;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 2 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 9) //CH double 10
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 280 + ct) * 10;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 2 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 0) //CH fs 1
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = NoOfDays * 400 + ct;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 2 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 1) //CH fs 2
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 400 + ct)*2;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 2 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 2) //CH fs 3
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 400 + ct)*3;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 2 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 3) //CH fs 4
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 400 + ct)*4;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 2 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 4) //CH fs 5
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 400 + ct)*5;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 2 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 5) //CH fs 6
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 400 + ct)*6;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 2 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 6) //CH fs 7
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 400 + ct) * 7;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 2 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 7) //CH fs 8
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 400 + ct) * 8;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 2 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 8) //CH fs 9
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 400 + ct) * 9;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 2 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 9) //CH fs 10
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 400 + ct) * 10;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 3 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 0) //CP single 1
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = NoOfDays * 160 + ct;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 3 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 1) //CP single 2
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 160 + ct)*2;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 3 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 2) //CP single 3
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 160 + ct) * 3;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 3 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 3) //CP single 4
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 160 + ct) * 4;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 3 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 4) //CP single 5
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 160 + ct) * 5;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 3 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 5) //CP single 6
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 160 + ct) * 6;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 3 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 6) //CP single 7
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 160 + ct) * 7;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 3 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 7) //CP single 8
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 160 + ct) * 8;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 3 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 8) //CP single 9
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 160 + ct) * 9;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 3 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 9) //CP single 10
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 160 + ct) * 10;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 3 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 0) //CP double 1
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = NoOfDays * 288 + ct;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 3 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 1) //CP double 2
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 288 + ct)*2;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 3 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 2) //CP double 3
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 288 + ct)*3;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 3 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 3) //CP double 4
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 288 + ct) * 4;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 3 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 4) //CP double 5
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 288 + ct) * 5;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 3 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 5) //CP double 6
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 288 + ct) * 6;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 3 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 6) //CP double 7
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 288 + ct) * 7;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 3 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 7) //CP double 8
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 288 + ct) * 8;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 3 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 8) //CP double 9
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 288 + ct) * 9;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 3 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 9) //CP double 10
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 288 + ct) * 10;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 3 && holidayresroomtypecomboBox.SelectedIndex == 2) //CP family suite
            {
                packagepricetextBox.Text = "Unavailable.";
            }
            else if (holidaypackagecomboBox.SelectedIndex==4 && holidayresroomtypecomboBox.SelectedIndex==0 && amountrescomboBox.SelectedIndex==0) //TT single 1
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = NoOfDays * 176 + tt;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 4 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 1) //TT single 2
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 176 + tt)*2;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 4 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 2) //TT single 3
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 176 + tt) * 3;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 4 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 3) //TT single 4
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 176 + tt) * 4;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 4 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 4) //TT single 5
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 176 + tt) * 5;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 4 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 5) //TT single 6
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 176 + tt) * 6;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 4 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 6) //TT single 7
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 176 + tt) * 7;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 4 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 7) //TT single 8
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 176 + tt) * 8;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 4 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 8) //TT single 9
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 176 + tt) * 9;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 4 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 9) //TT single 10
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 176 + tt) * 10;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 4 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 0) //TT double 1
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = NoOfDays * 280 + tt;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 4 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 1) //TT double 2
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 280 + tt) * 2;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 4 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 2) //TT double 3
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 280 + tt) * 3;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 4 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 3) //TT double 4
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 280 + tt) * 4;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 4 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 4) //TT double 5
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 280 + tt) * 5;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 4 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 5) //TT double 6
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 280 + tt) * 6;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 4 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 6) //TT double 7
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 280 + tt) * 7;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 4 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 7) //TT double 8
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 280 + tt) * 8;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 4 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 8) //TT double 9
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 280 + tt) * 9;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 4 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 9) //TT double 10
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 280 + tt) * 10;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 4 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 0) //TT fs 1
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = NoOfDays * 384 + tt;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 4 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 1) //TT fs 2
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 384 + tt) * 2;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 4 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 2) //TT fs 3
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 384 + tt) * 3;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 4 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 3) //TT fs 4
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 384 + tt) * 4;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 4 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 4) //TT fs 5
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 384 + lt) * 5;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 4 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 5) //TT fs 6
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 384 + tt) * 6;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 4 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 6) //TT fs 7
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 384 + tt) * 7;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 4 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 7) //TT fs 8
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 384 + tt) * 8;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 4 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 8) //TT fs 9
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 384 + tt) * 9;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 4 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 9) //TT fs 10
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 384 + tt) * 10;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 5 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 0) //TB single 1
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = NoOfDays * 200 + tt;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 5 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 1) //TB single 2
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 200 + tt)*2;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 5 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 2) //TB single 3
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 200 + tt)*3;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 5 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 3) //TB single 4
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 200 + tt) * 4;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 5 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 4) //TB single 5
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 200 + tt) * 5;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 5 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 5) //TB single 6
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 200 + tt) * 6;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 5 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 6) //TB single 7
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 200 + tt) * 7;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 5 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 7) //TB single 8
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 200 + tt) * 8;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 5 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 8) //TB single 9
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 200 + tt) * 9;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 5 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 9) //TB single 10
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 200 + tt) * 10;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 5 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 0) //TB double 1
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = NoOfDays * 304 + tt;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 5 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 1) //TB double 2
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 304 + tt)*2;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 5 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 2) //TB double 3
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 304 + tt) * 3;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 5 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 3) //TB double 4
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 304 + tt) * 4;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 5 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 4) //TB double 5
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 304 + tt) * 5;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 5 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 5) //TB double 6
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 304 + tt) * 6;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 5 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 6) //TB double 7
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 304 + tt) * 7;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 5 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 7) //TB double 8
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 304 + tt) * 8;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 5 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 8) //TB double 9
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 304 + tt) * 9;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 5 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 9) //TB double 10
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 304 + tt) * 10;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 5 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 0) //TB fs 1
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = NoOfDays * 416 + tt;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 5 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 1) //TB fs 2
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 416 + tt)*2;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 5 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 2) //TB fs 3
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 416 + tt)*3;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 5 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 3) //TB fs 4
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 416 + tt) * 4;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 5 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 4) //TB fs 5
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 416 + tt) * 5;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 5 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 5) //TB fs 6
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 416 + tt) * 6;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 5 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 6) //TB fs 7
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 416 + tt) * 7;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 5 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 7) //TB fs 8
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 416 + tt) * 8;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 5 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 8) //TB fs 9
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 416 + tt) * 9;
                packagepricetextBox.Text = amount.ToString();
            }
            else if (holidaypackagecomboBox.SelectedIndex == 5 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 9) //TB fs 10
            {
                double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                double amount = (NoOfDays * 416 + tt) * 10;
                packagepricetextBox.Text = amount.ToString();
            }
        }   

        private void holidayresconfirmbutton_Click(object sender, EventArgs e)
        {
            DateTime todaydate = DateTime.Today;
            DateTime startreserveddateholires = DateTime.Parse(holirstartdateTimePicker.Text);
            DateTime endreserveddateholires = DateTime.Parse(holirenddateTimePicker2.Text);
            try// prevent program from having errors when users do not fill in the fields and click "confirm".
            {
                if (startreserveddateholires >=todaydate && endreserveddateholires > todaydate && amountrescomboBox.SelectedIndex>-1)//amountrescomboBox.SelectedIndex>-1, default is -1
                {                                                                                                                   //if combobox is selected,selectedindex would be 0 or above
                    if (startreserveddateholires < endreserveddateholires && holidayresholidayidtextBox.Text != "" && holirescusidtextBox.Text != "")
                    {
                        using (OleDbConnection conn = new OleDbConnection())
                        {

                            conn.ConnectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=IOOPDb.accdb";
                            string sql = string.Format("INSERT INTO holidayres(holireservationID, holidayID, holidayname, roomtype, amountholiday, holidayprice, datereservedstart, datereservedend, customerid) VALUES('{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}','{8}')", holirestextBox.Text ,holidayresholidayidtextBox.Text, holidaypackagecomboBox.SelectedItem, holidayresroomtypecomboBox.SelectedItem, amountrescomboBox.Text, packagepricetextBox.Text, startreserveddateholires, endreserveddateholires, holirescusidtextBox.Text);

                            using (OleDbCommand cmd = new OleDbCommand(sql, conn))
                            {
                                conn.Open();
                                cmd.ExecuteNonQuery();
                                MessageBox.Show("Insertion successful.");
                                HolidayRes newForm = new HolidayRes();
                                newForm.Show();
                                this.Hide();
                            }
                        }
                    }
                    else
                    {
                        MessageBox.Show("Insertion unsuccessful. Please ensure that all dates are correct, room type is not 'unavailable' and DO NOT leave any fields empty.");
                    }
                }
                else
                {
                    MessageBox.Show("Insertion unsuccessful. Please ensure that the ending date is after current date. Dates will be resetted to the current date.");
                    holirstartdateTimePicker.ResetText();//reset to current date 
                    holirenddateTimePicker2.ResetText();
                }
            }
            catch
            {
                MessageBox.Show("Insertion unsuccessful. Please do not leave any fields empty.");
            }
        }

        private void holidayresroomtypecomboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            DateTime startreserveddateholires = DateTime.Parse(holirstartdateTimePicker.Text);
            DateTime endreserveddateholires = DateTime.Parse(holirenddateTimePicker2.Text);
            if (startreserveddateholires <endreserveddateholires)
            {
                if (holidaypackagecomboBox.SelectedIndex == 0 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 0) //LB single 1
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = NoOfDays * 160 + lt;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 0 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 1) //LB single 2
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 160 + lt) * 2;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 0 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 2) //LB single 3
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 160 + lt) * 3;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 0 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 3) //LB single 4
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 160 + lt) * 4;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 0 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 4) //LB single 5
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 160 + lt) * 5;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 0 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 5) //LB single 6
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 160 + lt) * 6;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 0 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 6) //LB single 7
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 160 + lt) * 7;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 0 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 7) //LB single 8
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 160 + lt) * 8;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 0 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 8) //LB single 9
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 160 + lt) * 9;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 0 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 9) //LB single 10
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 160 + lt) * 10;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 0 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 0) //LB double 1
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = NoOfDays * 304 + lt;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 0 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 1) //LB double 2
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 304 + lt) * 2;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 0 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 2) //LB double 3
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 304 + lt) * 3;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 0 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 3) //LB double 4
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 304 + lt) * 4;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 0 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 4) //LB double 5
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 304 + lt) * 5;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 0 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 5) //LB double 6
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 304 + lt) * 6;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 0 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 6) //LB double 7
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 304 + lt) * 7;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 0 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 7) //LB double 8
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 304 + lt) * 8;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 0 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 8) //LB double 9
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 304 + lt) * 9;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 0 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 9) //LB double 10
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 304 + lt) * 10;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 0 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 0) //LB fs 1
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = NoOfDays * 480 + lt;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 0 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 1) //LB fs 2
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 480 + lt) * 2;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 0 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 2) //LB fs 3
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 480 + lt) * 3;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 0 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 3) //LB fs 4
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 480 + lt) * 4;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 0 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 4) //LB fs 5
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 480 + lt) * 5;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 0 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 5) //LB fs 6
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 480 + lt) * 6;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 0 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 6) //LB fs 7
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 480 + lt) * 7;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 0 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 7) //LB fs 8
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 480 + lt) * 8;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 0 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 8) //LB fs 9
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 480 + lt) * 9;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 0 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 9) //LB fs 10
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 480 + lt) * 10;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 1 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 0) //LA Single 1
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 144 + lt);
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 1 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 1) //LA Single 2
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 144 + lt) * 2;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 1 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 2) //LA Single 3
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 144 + lt) * 3;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 1 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 3) //LA Single 4
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 144 + lt) * 4;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 1 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 4) //LA Single 5
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 144 + lt) * 5;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 1 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 5) //LA Single 6
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 144 + lt) * 6;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 1 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 6) //LA Single 7
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 144 + lt) * 7;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 1 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 7) //LA Single 8
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 144 + lt) * 8;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 1 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 8) //LA Single 9
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 144 + lt) * 9;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 1 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 9) //LA Single 10
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 144 + lt) * 10;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 1 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 0) //LA Double 1
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 192 + lt);
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 1 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 1) //LA Double 2
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 192 + lt) * 2;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 1 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 2) //LA Double 3
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 192 + lt) * 3;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 1 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 3) //LA Double 4
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 192 + lt) * 4;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 1 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 4) //LA Double 5
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 192 + lt) * 5;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 1 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 5) //LA Double 6
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 192 + lt) * 6;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 1 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 6) //LA Double 7
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 192 + lt) * 7;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 1 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 7) //LA Double 8
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 192 + lt) * 8;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 1 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 8) //LA Double 9
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 192 + lt) * 9;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 1 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 9) //LA Double 10
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 192 + lt) * 10;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 1 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 0) //LA fs 1
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = NoOfDays * 320 + lt;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 1 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 1) //LA fs 2
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 320 + lt) * 2;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 1 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 2) //LA fs 3
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 320 + lt) * 3;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 1 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 3) //LA fs 4
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 320 + lt) * 4;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 1 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 4) //LA fs 5
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 320 + lt) * 5;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 1 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 5) //LA fs 6
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 320 + lt) * 6;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 1 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 6) //LA fs 7
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 320 + lt) * 7;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 1 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 7) //LA fs 8
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 320 + lt) * 8;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 1 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 8) //LA fs 9
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 320 + lt) * 9;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 1 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 9) //LA fs 10
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 320 + lt) * 10;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 2 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 0) //CH single 1
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = NoOfDays * 144 + ct;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 2 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 1) //CH single 2
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 144 + ct) * 2;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 2 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 2) //CH single 3
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 144 + ct) * 3;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 2 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 3) //CH single 4
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 144 + ct) * 4;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 2 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 4) //CH single 5
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 144 + ct) * 5;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 2 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 5) //CH single 6
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 144 + ct) * 6;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 2 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 6) //CH single 7
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 144 + ct) * 7;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 2 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 7) //CH single 8
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 144 + ct) * 8;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 2 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 8) //CH single 9
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 144 + ct) * 9;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 2 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 9) //CH single 10
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 144 + ct) * 10;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 2 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 0) //CH double 1
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = NoOfDays * 280 + ct;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 2 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 1) //CH double 2
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 280 + ct) * 2;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 2 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 2) //CH double 3
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 280 + ct) * 3;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 2 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 3) //CH double 4
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 280 + ct) * 4;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 2 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 4) //CH double 5
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 280 + ct) * 5;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 2 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 5) //CH double 6
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 280 + ct) * 6;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 2 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 6) //CH double 7
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 280 + ct) * 7;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 2 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 7) //CH double 8
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 280 + ct) * 8;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 2 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 8) //CH double 9
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 280 + ct) * 9;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 2 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 9) //CH double 10
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 280 + ct) * 10;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 2 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 0) //CH fs 1
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = NoOfDays * 400 + ct;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 2 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 1) //CH fs 2
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 400 + ct) * 2;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 2 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 2) //CH fs 3
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 400 + ct) * 3;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 2 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 3) //CH fs 4
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 400 + ct) * 4;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 2 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 4) //CH fs 5
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 400 + ct) * 5;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 2 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 5) //CH fs 6
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 400 + ct) * 6;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 2 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 6) //CH fs 7
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 400 + ct) * 7;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 2 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 7) //CH fs 8
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 400 + ct) * 8;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 2 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 8) //CH fs 9
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 400 + ct) * 9;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 2 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 9) //CH fs 10
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 400 + ct) * 10;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 3 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 0) //CP single 1
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = NoOfDays * 160 + ct;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 3 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 1) //CP single 2
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 160 + ct) * 2;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 3 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 2) //CP single 3
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 160 + ct) * 3;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 3 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 3) //CP single 4
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 160 + ct) * 4;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 3 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 4) //CP single 5
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 160 + ct) * 5;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 3 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 5) //CP single 6
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 160 + ct) * 6;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 3 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 6) //CP single 7
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 160 + ct) * 7;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 3 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 7) //CP single 8
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 160 + ct) * 8;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 3 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 8) //CP single 9
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 160 + ct) * 9;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 3 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 9) //CP single 10
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 160 + ct) * 10;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 3 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 0) //CP double 1
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = NoOfDays * 288 + ct;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 3 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 1) //CP double 2
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 288 + ct) * 2;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 3 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 2) //CP double 3
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 288 + ct) * 3;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 3 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 3) //CP double 4
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 288 + ct) * 4;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 3 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 4) //CP double 5
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 288 + ct) * 5;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 3 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 5) //CP double 6
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 288 + ct) * 6;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 3 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 6) //CP double 7
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 288 + ct) * 7;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 3 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 7) //CP double 8
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 288 + ct) * 8;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 3 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 8) //CP double 9
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 288 + ct) * 9;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 3 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 9) //CP double 10
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 288 + ct) * 10;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 3 && holidayresroomtypecomboBox.SelectedIndex == 2) //CP family suite
                {
                    packagepricetextBox.Text = "Unavailable.";
                }
                else if (holidaypackagecomboBox.SelectedIndex == 4 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 0) //TT single 1
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = NoOfDays * 176 + tt;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 4 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 1) //TT single 2
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 176 + tt) * 2;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 4 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 2) //TT single 3
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 176 + tt) * 3;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 4 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 3) //TT single 4
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 176 + tt) * 4;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 4 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 4) //TT single 5
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 176 + tt) * 5;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 4 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 5) //TT single 6
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 176 + tt) * 6;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 4 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 6) //TT single 7
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 176 + tt) * 7;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 4 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 7) //TT single 8
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 176 + tt) * 8;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 4 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 8) //TT single 9
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 176 + tt) * 9;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 4 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 9) //TT single 10
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 176 + tt) * 10;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 4 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 0) //TT double 1
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = NoOfDays * 280 + tt;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 4 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 1) //TT double 2
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 280 + tt) * 2;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 4 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 2) //TT double 3
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 280 + tt) * 3;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 4 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 3) //TT double 4
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 280 + tt) * 4;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 4 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 4) //TT double 5
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 280 + tt) * 5;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 4 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 5) //TT double 6
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 280 + tt) * 6;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 4 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 6) //TT double 7
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 280 + tt) * 7;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 4 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 7) //TT double 8
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 280 + tt) * 8;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 4 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 8) //TT double 9
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 280 + tt) * 9;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 4 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 9) //TT double 10
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 280 + tt) * 10;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 4 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 0) //TT fs 1
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = NoOfDays * 384 + tt;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 4 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 1) //TT fs 2
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 384 + tt) * 2;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 4 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 2) //TT fs 3
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 384 + tt) * 3;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 4 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 3) //TT fs 4
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 384 + tt) * 4;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 4 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 4) //TT fs 5
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 384 + lt) * 5;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 4 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 5) //TT fs 6
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 384 + tt) * 6;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 4 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 6) //TT fs 7
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 384 + tt) * 7;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 4 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 7) //TT fs 8
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 384 + tt) * 8;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 4 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 8) //TT fs 9
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 384 + tt) * 9;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 4 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 9) //TT fs 10
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 384 + tt) * 10;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 5 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 0) //TB single 1
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = NoOfDays * 200 + tt;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 5 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 1) //TB single 2
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 200 + tt) * 2;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 5 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 2) //TB single 3
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 200 + tt) * 3;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 5 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 3) //TB single 4
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 200 + tt) * 4;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 5 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 4) //TB single 5
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 200 + tt) * 5;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 5 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 5) //TB single 6
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 200 + tt) * 6;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 5 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 6) //TB single 7
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 200 + tt) * 7;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 5 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 7) //TB single 8
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 200 + tt) * 8;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 5 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 8) //TB single 9
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 200 + tt) * 9;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 5 && holidayresroomtypecomboBox.SelectedIndex == 0 && amountrescomboBox.SelectedIndex == 9) //TB single 10
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 200 + tt) * 10;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 5 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 0) //TB double 1
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = NoOfDays * 304 + tt;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 5 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 1) //TB double 2
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 304 + tt) * 2;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 5 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 2) //TB double 3
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 304 + tt) * 3;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 5 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 3) //TB double 4
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 304 + tt) * 4;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 5 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 4) //TB double 5
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 304 + tt) * 5;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 5 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 5) //TB double 6
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 304 + tt) * 6;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 5 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 6) //TB double 7
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 304 + tt) * 7;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 5 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 7) //TB double 8
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 304 + tt) * 8;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 5 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 8) //TB double 9
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 304 + tt) * 9;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 5 && holidayresroomtypecomboBox.SelectedIndex == 1 && amountrescomboBox.SelectedIndex == 9) //TB double 10
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 304 + tt) * 10;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 5 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 0) //TB fs 1
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = NoOfDays * 416 + tt;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 5 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 1) //TB fs 2
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 416 + tt) * 2;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 5 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 2) //TB fs 3
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 416 + tt) * 3;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 5 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 3) //TB fs 4
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 416 + tt) * 4;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 5 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 4) //TB fs 5
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 416 + tt) * 5;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 5 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 5) //TB fs 6
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 416 + tt) * 6;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 5 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 6) //TB fs 7
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 416 + tt) * 7;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 5 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 7) //TB fs 8
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 416 + tt) * 8;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 5 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 8) //TB fs 9
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 416 + tt) * 9;
                    packagepricetextBox.Text = amount.ToString();
                }
                else if (holidaypackagecomboBox.SelectedIndex == 5 && holidayresroomtypecomboBox.SelectedIndex == 2 && amountrescomboBox.SelectedIndex == 9) //TB fs 10
                {
                    double NoOfDays = (endreserveddateholires - startreserveddateholires).TotalDays;
                    double amount = (NoOfDays * 416 + tt) * 10;
                    packagepricetextBox.Text = amount.ToString();
                }
            }
            else
            {
                MessageBox.Show("Please ensure the dates are correct.");
            }
            
        }

    }
}
