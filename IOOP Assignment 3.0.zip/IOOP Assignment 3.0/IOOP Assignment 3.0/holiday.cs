﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IOOP_Assignment_3._0
{
    class holiday
    {
        private string _holidaypname;
        private double _holidaypprice;
        private double _hotelprice;
        private double _dayreserved;
        public string holidaypname
        {
            get
            {
                return _holidaypname;
            }
            set
            {
                _holidaypname = value;
            }
        }
        public double holidaypprice
        {
            get
            {
                return _holidaypprice;
            }
            set
            {
                _holidaypprice = value;
            }
        }
        public double hotelprice
        {
            get
            {
                return _hotelprice;
            }
            set
            {
                _hotelprice = value;
            }
        }
        public double dayreserved
        {
            get
            {
                return _dayreserved;
            }
            set
            {
                _dayreserved = value;
            }
        }
        public holiday(string holiname, double holiprice, double hotelp, double dayr)
        {
            holiname = _holidaypname;
            holiprice = _holidaypprice;
            hotelp = _hotelprice;
            dayr = _dayreserved;
        }

        public double holidayresprice(double dayreserved, double holidaypprice, double hotelprice)
        {
            return (dayreserved * hotelprice) + holidaypprice;
        }
    }
   
}
